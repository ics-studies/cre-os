from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .measurement import METRIC_METHODS
from .serialization import to_jsonable
from .version import SemVer


@dataclass(frozen=True)
class MetricSpec:
    metric_id: str
    label: str
    metric_version: str
    dimensions: tuple[str, ...]
    output_modes: tuple[str, ...]
    calibration_status: str
    calibration_ref: str | None
    claim_boundary: str

    def __post_init__(self) -> None:
        SemVer.parse(self.metric_version)
        if not self.dimensions:
            raise ValueError(f"{self.metric_id}: dimensions are required")
        if not self.output_modes:
            raise ValueError(f"{self.metric_id}: output modes are required")
        if not self.claim_boundary.strip():
            raise ValueError(f"{self.metric_id}: claim boundary is required")


@dataclass(frozen=True)
class SubsystemSpec:
    subsystem_id: str
    label: str
    implementation_ref: str
    validation_ref: str
    status: str = "implemented"


@dataclass(frozen=True)
class PlatformStatus:
    platform_version: str
    structural_complete: bool
    six_metrics_complete: bool
    evidence_contract_complete: bool
    portable_record_complete: bool
    measurement_complete: bool
    uncertainty_complete: bool
    cr_csp_complete: bool
    ndss_complete: bool
    sstp_complete: bool
    vgt_complete: bool
    scientific_complete: bool
    output_modes_complete: bool
    commercial_release_allowed: bool
    release_state: str
    calibrated_metrics: tuple[str, ...]
    provisional_metrics: tuple[str, ...]
    uncalibrated_metrics: tuple[str, ...]
    missing_requirements: tuple[str, ...]
    claim_boundary: str

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


_CALIBRATION_LABELS = {
    "uncalibrated": "uncalibrated",
    "provisional": "provisional_source_adjudicated_20_case",
    "calibrated": "calibrated",
    "externally_validated": "externally_validated",
}

METRIC_SPECS: dict[str, MetricSpec] = {
    metric_id: MetricSpec(
        metric_id=method.metric_id,
        label=method.label,
        metric_version=method.method_version,
        dimensions=method.dimensions,
        output_modes=method.output_modes,
        calibration_status=_CALIBRATION_LABELS[method.calibration_status.value],
        calibration_ref=method.calibration_ref,
        claim_boundary=method.claim_boundary,
    )
    for metric_id, method in METRIC_METHODS.items()
}


SUBSYSTEM_SPECS: dict[str, SubsystemSpec] = {
    "semver": SubsystemSpec(
        subsystem_id="semver",
        label="Strict SemVer 2.0",
        implementation_ref="ics_cre_os.version.SemVer",
        validation_ref="tests/test_ics_cre_os.py",
    ),
    "evidence_gate": SubsystemSpec(
        subsystem_id="evidence_gate",
        label="Evidence-linked metric gate",
        implementation_ref="ics_cre_os.evidence_assessment",
        validation_ref="tests/test_ics_cre_os_evidence.py",
    ),
    "measurement_kernel": SubsystemSpec(
        subsystem_id="measurement_kernel",
        label="Evidence-gated measurement kernel",
        implementation_ref="ics_cre_os.measurement.measure",
        validation_ref="tests/test_ics_cre_os_measurement.py",
    ),
    "uncertainty_engine": SubsystemSpec(
        subsystem_id="uncertainty_engine",
        label="Risk, Knightian and deep-uncertainty engine",
        implementation_ref="ics_cre_os.uncertainty",
        validation_ref="tests/test_ics_cre_os_uncertainty.py",
    ),
    "cr_csp": SubsystemSpec(
        subsystem_id="cr_csp",
        label="Finite-action CR-CSP solver",
        implementation_ref="ics_cre_os.crcsp.CRCSPSolver",
        validation_ref="validation/cre_os_crcsp_scale_2026-11-25.json",
    ),
    "ndss": SubsystemSpec(
        subsystem_id="ndss",
        label="NDSS decision-support report",
        implementation_ref="ics_cre_os.ndss.NDSS",
        validation_ref="tests/test_ics_cre_os_ndss_sstp.py",
    ),
    "sstp": SubsystemSpec(
        subsystem_id="sstp",
        label="SSTP scenario and quality engine",
        implementation_ref="ics_cre_os.sstp.StressTestEngine",
        validation_ref="validation/cre_os_sstp_quality_2026-11-25.json",
    ),
    "vgt": SubsystemSpec(
        subsystem_id="vgt",
        label="Version Governance Topology",
        implementation_ref="ics_cre_os.vgt",
        validation_ref="tests/test_ics_cre_os_vgt.py",
    ),
    "portable_audit_record": SubsystemSpec(
        subsystem_id="portable_audit_record",
        label="Portable audit record",
        implementation_ref="ics_cre_os.audit.PortableAuditRecord",
        validation_ref="tests/test_ics_cre_os_acceptance.py",
    ),
}


REQUIRED_SUBSYSTEMS = (
    "evidence_gate",
    "portable_audit_record",
    "measurement_kernel",
    "uncertainty_engine",
    "cr_csp",
    "ndss",
    "sstp",
    "vgt",
)
CALIBRATED_STATUSES = {"calibrated", "externally_validated"}
PROVISIONAL_STATUSES = {"provisional_source_adjudicated_20_case"}
PLATFORM_VERSION = "1.0.0"


def evaluate_platform_status() -> PlatformStatus:
    metric_ids = set(METRIC_SPECS)
    required_metric_ids = {"UCS", "RFD", "CRV", "CDI", "MBCL", "CSIA"}
    missing_metrics = tuple(sorted(required_metric_ids - metric_ids))
    missing_subsystems = tuple(
        subsystem_id
        for subsystem_id in REQUIRED_SUBSYSTEMS
        if subsystem_id not in SUBSYSTEM_SPECS
        or SUBSYSTEM_SPECS[subsystem_id].status != "implemented"
    )
    calibrated_metrics = tuple(
        metric_id
        for metric_id, spec in METRIC_SPECS.items()
        if spec.calibration_status in CALIBRATED_STATUSES
    )
    provisional_metrics = tuple(
        metric_id
        for metric_id, spec in METRIC_SPECS.items()
        if spec.calibration_status in PROVISIONAL_STATUSES
    )
    uncalibrated_metrics = tuple(
        metric_id
        for metric_id, spec in METRIC_SPECS.items()
        if spec.calibration_status not in CALIBRATED_STATUSES
        and spec.calibration_status not in PROVISIONAL_STATUSES
    )
    six_metrics_complete = not missing_metrics
    evidence_contract_complete = "evidence_gate" not in missing_subsystems
    portable_record_complete = "portable_audit_record" not in missing_subsystems
    measurement_complete = "measurement_kernel" not in missing_subsystems
    uncertainty_complete = "uncertainty_engine" not in missing_subsystems
    cr_csp_complete = "cr_csp" not in missing_subsystems
    ndss_complete = "ndss" not in missing_subsystems
    sstp_complete = "sstp" not in missing_subsystems
    vgt_complete = "vgt" not in missing_subsystems
    output_modes_complete = all(
        "structured_vector" in spec.output_modes
        for spec in METRIC_SPECS.values()
        if spec.metric_id == "UCS"
    )
    structural_complete = all(
        (
            six_metrics_complete,
            evidence_contract_complete,
            portable_record_complete,
            measurement_complete,
            uncertainty_complete,
            cr_csp_complete,
            ndss_complete,
            sstp_complete,
            vgt_complete,
            output_modes_complete,
        )
    )
    missing_requirements = (
        *(f"metric:{item}" for item in missing_metrics),
        *(f"subsystem:{item}" for item in missing_subsystems),
    )
    return PlatformStatus(
        platform_version=PLATFORM_VERSION,
        structural_complete=structural_complete,
        six_metrics_complete=six_metrics_complete,
        evidence_contract_complete=evidence_contract_complete,
        portable_record_complete=portable_record_complete,
        measurement_complete=measurement_complete,
        uncertainty_complete=uncertainty_complete,
        cr_csp_complete=cr_csp_complete,
        ndss_complete=ndss_complete,
        sstp_complete=sstp_complete,
        vgt_complete=vgt_complete,
        scientific_complete=not uncalibrated_metrics and not provisional_metrics,
        output_modes_complete=output_modes_complete,
        commercial_release_allowed=False,
        release_state="frozen_until_portfolio_complete",
        calibrated_metrics=calibrated_metrics,
        provisional_metrics=provisional_metrics,
        uncalibrated_metrics=uncalibrated_metrics,
        missing_requirements=missing_requirements,
        claim_boundary=(
            "Structural completion means the canonical evidence gate, portable "
            "audit record, measurement kernel, uncertainty engine, six metric "
            "contracts, CR-CSP, NDSS, SSTP and VGT are present and mutually "
            "usable. All six metrics have provisional source-adjudicated "
            "twenty-case benchmarks. This does not mean independent construct "
            "validation, external validation, production security, or "
            "commercial release approval."
        ),
    )
