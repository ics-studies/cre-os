from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from .serialization import to_jsonable
from .version import SemVer


@dataclass(frozen=True)
class SourceRef:
    """A stable reference into the ratified normative source hierarchy."""

    volume: int
    chapter: str
    section: str | None = None
    locator: str | None = None
    version: str | None = "2.0.0"
    ruling: str | None = None
    work: str = "ICS-2027"

    def __post_init__(self) -> None:
        if self.volume < 0:
            raise ValueError("volume must be non-negative")
        if not self.chapter.strip():
            raise ValueError("chapter is required")
        if self.version is not None:
            SemVer.parse(self.version)
        elif self.work == "ICS-2027":
            raise ValueError("ICS-2027 source references require a SemVer")

    def label(self) -> str:
        if self.work != "ICS-2027":
            parts = [self.work, f"Ch.{self.chapter}"]
            if self.section:
                parts.append(f"§{self.section}")
            if self.locator:
                parts.append(self.locator)
            return " ".join(parts)
        parts = [f"V{self.volume}", f"Ch.{self.chapter}"]
        if self.section:
            parts.append(f"§{self.section}")
        if self.locator:
            parts.append(self.locator)
        return " ".join(parts)


class EvidenceGrade(str, Enum):
    ABSENT = "absent"
    ASSERTED = "asserted"
    DOCUMENTED = "documented"
    OPERATIONALLY_EVIDENCED = "operationally_evidenced"
    INDEPENDENTLY_VERIFIED = "independently_verified"
    CONTRADICTED = "contradicted"
    NOT_ASSESSABLE = "not_assessable"


@dataclass(frozen=True)
class UncertaintyInterval:
    lower: float
    upper: float

    def __post_init__(self) -> None:
        if self.lower > self.upper:
            raise ValueError("lower bound must not exceed upper bound")

    def contains(self, value: float) -> bool:
        return self.lower <= value <= self.upper


@dataclass(frozen=True)
class EvidenceSpan:
    evidence_id: str
    source: SourceRef
    locator: str
    quote: str | None = None
    sha256: str | None = None


@dataclass
class EvidenceRecord:
    claim: str
    grade: EvidenceGrade = EvidenceGrade.NOT_ASSESSABLE
    spans: list[EvidenceSpan] = field(default_factory=list)
    human_confirmed: bool = False
    notes: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.spans = list(self.spans)
        self.notes = list(self.notes)

    def validate(self) -> None:
        positive = {
            EvidenceGrade.DOCUMENTED,
            EvidenceGrade.OPERATIONALLY_EVIDENCED,
            EvidenceGrade.INDEPENDENTLY_VERIFIED,
        }
        if self.grade in positive and not self.spans:
            raise ValueError(
                "positive evidence grades require at least one source span"
            )
        if (
            self.grade
            in {
                EvidenceGrade.OPERATIONALLY_EVIDENCED,
                EvidenceGrade.INDEPENDENTLY_VERIFIED,
            }
            and not self.human_confirmed
        ):
            raise ValueError("E3/E4 evidence requires explicit human confirmation")

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


@dataclass
class MetricResult:
    metric: str
    metric_version: str
    dimensions: dict[str, float]
    score: float | None = None
    interval: UncertaintyInterval | None = None
    evidence: list[EvidenceRecord] = field(default_factory=list)
    sources: list[SourceRef] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    claim_boundary: str = ""
    status: str = "calculated"
    uncertainty_kind: str = "unspecified"
    possible_levels: tuple[int, ...] = ()

    def __post_init__(self) -> None:
        self.dimensions = dict(self.dimensions)
        self.evidence = list(self.evidence)
        self.sources = list(self.sources)
        self.warnings = list(self.warnings)
        self.possible_levels = tuple(self.possible_levels)

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)
