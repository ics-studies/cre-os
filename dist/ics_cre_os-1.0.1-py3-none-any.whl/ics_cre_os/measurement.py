from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from itertools import product
from typing import Any

from .evidence_assessment import (
    METRIC_DIMENSION_SPECS,
    MetricEvidenceAssessment,
    compute_metric_from_evidence,
)
from .metrics import (
    CDI_DEFAULT_WEIGHTS,
    CRV_ENF_SUBDIMENSIONS,
    CRV_OBS_SUBDIMENSIONS,
    CRV_OBS_WEIGHTS,
    CRV_REV_SUBDIMENSIONS,
    CRV_REV_WEIGHTS,
    CSIA_DEFAULT_WEIGHTS,
    CSIA_DIMENSIONS,
    RFD_DIMENSIONS,
    RFD_OPERATORS,
    UCS_DIMENSIONS,
    UCS_RESEARCH_WEIGHTS,
    MBCLAssessment,
    evaluate_csia,
    evaluate_mbcl,
)
from .models import (
    EvidenceRecord,
    SourceRef,
    UncertaintyInterval,
)
from .serialization import to_jsonable
from .uncertainty import (
    UncertaintyEnvelope,
    UncertaintyKind,
    product_envelope,
    weighted_sum_envelope,
)
from .version import SemVer


class ScaleKind(str, Enum):
    RATIO = "ratio"
    INTERVAL = "interval"
    ORDINAL = "ordinal"
    VECTOR = "vector"


class CalibrationStatus(str, Enum):
    UNCALIBRATED = "uncalibrated"
    PROVISIONAL = "provisional"
    CALIBRATED = "calibrated"
    EXTERNALLY_VALIDATED = "externally_validated"


@dataclass(frozen=True)
class MetricMethod:
    metric_id: str
    label: str
    method_version: str
    scale_kind: ScaleKind
    output_modes: tuple[str, ...]
    dimensions: tuple[str, ...]
    numeric_dimensions: tuple[str, ...]
    sources: tuple[SourceRef, ...]
    calibration_status: CalibrationStatus
    calibration_ref: str | None
    claim_boundary: str

    def __post_init__(self) -> None:
        if not self.metric_id.strip() or not self.label.strip():
            raise ValueError("metric id and label are required")
        SemVer.parse(self.method_version)
        if not self.dimensions or not self.output_modes:
            raise ValueError("metric dimensions and output modes are required")
        if not set(self.numeric_dimensions).issubset(self.dimensions):
            raise ValueError("numeric dimensions must be declared dimensions")
        if not self.sources:
            raise ValueError("a metric method requires normative sources")
        if not self.claim_boundary.strip():
            raise ValueError("a metric method requires a claim boundary")

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


_ICS_V2 = "2.0.0"
_CORE_METRIC_CALIBRATION_REF = (
    ".esg-commitment-audit-service/confidential/2027-program/"
    "core-metric-calibration-v1/CALIBRATION_REPORT.md"
)

METRIC_METHODS: dict[str, MetricMethod] = {
    "UCS": MetricMethod(
        metric_id="UCS",
        label="Universal Consciousness Scale",
        method_version=_ICS_V2,
        scale_kind=ScaleKind.RATIO,
        output_modes=("structured_vector", "experimental_research_score"),
        dimensions=UCS_DIMENSIONS,
        numeric_dimensions=UCS_DIMENSIONS,
        sources=(
            SourceRef(2, "23", "23.1.8", "Definition 23.1.8"),
            SourceRef(2, "23", "23.4", "Definitions 23.4.2-23.4.4"),
        ),
        calibration_status=CalibrationStatus.PROVISIONAL,
        calibration_ref=_CORE_METRIC_CALIBRATION_REF,
        claim_boundary=(
            "UCS describes evidence-linked indicators associated with "
            "consciousness. It does not prove consciousness, personhood, "
            "legal status, or moral worth."
        ),
    ),
    "RFD": MetricMethod(
        metric_id="RFD",
        label="Recursive Freedom Degree",
        method_version=_ICS_V2,
        scale_kind=ScaleKind.RATIO,
        output_modes=("bounded_capacity_proxy", "signed_delta"),
        dimensions=(*RFD_DIMENSIONS, *RFD_OPERATORS),
        numeric_dimensions=(*RFD_DIMENSIONS, *RFD_OPERATORS),
        sources=(
            SourceRef(2, "24", "24.1", "Definitions 24.1.1-24.1.6"),
            SourceRef(
                0,
                "21",
                "21.3-21.5",
                "RFD specialization",
                version=None,
                ruling="A-19",
                work="RECURSIVE_FREEDOM_LOWER",
            ),
        ),
        calibration_status=CalibrationStatus.PROVISIONAL,
        calibration_ref=_CORE_METRIC_CALIBRATION_REF,
        claim_boundary=(
            "The bounded capacity is an operational proxy for a context-"
            "sensitive ratio-scale construct. It must not be used for rights, "
            "political reliability, or high-stakes individual decisions."
        ),
    ),
    "CRV": MetricMethod(
        metric_id="CRV",
        label="Commitment Reversibility and Verifiability",
        method_version=_ICS_V2,
        scale_kind=ScaleKind.VECTOR,
        output_modes=("three_component_vector", "ten_subdimensions"),
        dimensions=(
            *CRV_OBS_SUBDIMENSIONS,
            *CRV_ENF_SUBDIMENSIONS,
            *CRV_REV_SUBDIMENSIONS,
        ),
        numeric_dimensions=(
            *CRV_OBS_SUBDIMENSIONS,
            *CRV_ENF_SUBDIMENSIONS,
            *CRV_REV_SUBDIMENSIONS,
        ),
        sources=(
            SourceRef(2, "24", "24.5", "Definitions 24.5.1-24.5.6"),
            SourceRef(3, "6", "6.1", "CRV operationalization"),
        ),
        calibration_status=CalibrationStatus.PROVISIONAL,
        calibration_ref=(
            ".esg-commitment-audit-service/confidential/2027-program/"
            "crv-calibration-v0.1/CRV_CROSS_SOURCE_REVIEW_v0.3.md"
        ),
        claim_boundary=(
            "The 20-case result is internal source-adjudicated calibration, "
            "not independent validation, assurance, or proof of performance."
        ),
    ),
    "CDI": MetricMethod(
        metric_id="CDI",
        label="Civilizational Development Index",
        method_version=_ICS_V2,
        scale_kind=ScaleKind.RATIO,
        output_modes=("weighted_score", "dimension_vector"),
        dimensions=("eu", "ip", "nm", "ad", "nmat"),
        numeric_dimensions=("eu", "ip", "nm", "ad", "nmat"),
        sources=(
            SourceRef(2, "25", "25.1", "Definitions 25.1-25.6"),
            SourceRef(3, "7", "7.1", "Definition 7.1"),
        ),
        calibration_status=CalibrationStatus.PROVISIONAL,
        calibration_ref=_CORE_METRIC_CALIBRATION_REF,
        claim_boundary=(
            "CDI is not a country, company, or civilization ranking. Every "
            "use must report its weight profile and uncertainty interval."
        ),
    ),
    "MBCL": MetricMethod(
        metric_id="MBCL",
        label="Memetic Biosafety Containment Level",
        method_version=_ICS_V2,
        scale_kind=ScaleKind.ORDINAL,
        output_modes=("protective_gate_level", "auxiliary_risk_norm"),
        dimensions=(
            "replication",
            "impact",
            "controllability",
            "reversible",
            "self_replicating",
            "partially_reversible",
            "existential_risk",
        ),
        numeric_dimensions=("replication", "impact", "controllability"),
        sources=(
            SourceRef(2, "25", "25.2", "Definitions 25.8-25.11"),
            SourceRef(3, "8", "8.1-8.3", "MBCL levels"),
        ),
        calibration_status=CalibrationStatus.PROVISIONAL,
        calibration_ref=_CORE_METRIC_CALIBRATION_REF,
        claim_boundary=(
            "Protective gates determine the level. Risk_norm is auxiliary. "
            "MBCL must not be used as a censorship or political-content score."
        ),
    ),
    "CSIA": MetricMethod(
        metric_id="CSIA",
        label="Cosmic-Scale Impact Assessment",
        method_version=_ICS_V2,
        scale_kind=ScaleKind.INTERVAL,
        output_modes=("risk_vector", "risk_score", "risk_level"),
        dimensions=CSIA_DIMENSIONS,
        numeric_dimensions=CSIA_DIMENSIONS,
        sources=(
            SourceRef(2, "25", "25.3", "CSIA formalization"),
            SourceRef(3, "9", "9.1-9.4", "CSIA operationalization"),
            SourceRef(4, "3", "3.2", "CSIA engineering contract"),
        ),
        calibration_status=CalibrationStatus.PROVISIONAL,
        calibration_ref=_CORE_METRIC_CALIBRATION_REF,
        claim_boundary=(
            "CSIA is a structured, uncertainty-bearing impact assessment. "
            "It is not a decision, authorization, or prediction of fact."
        ),
    ),
}


@dataclass(frozen=True)
class MeasurementAudit:
    reviewer_id: str
    reviewed_at: datetime
    evidence_ids: tuple[str, ...]
    input_sha256: str
    method_sha256: str

    def __post_init__(self) -> None:
        if not self.reviewer_id.strip():
            raise ValueError("reviewer_id is required")
        if self.reviewed_at.tzinfo is None:
            raise ValueError("reviewed_at must include a timezone")
        if not self.evidence_ids:
            raise ValueError("measurement audit requires evidence IDs")
        if len(self.input_sha256) != 64 or len(self.method_sha256) != 64:
            raise ValueError("audit SHA-256 fields must be 64 hexadecimal characters")
        for value in (self.input_sha256, self.method_sha256):
            int(value, 16)

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


@dataclass(frozen=True)
class MeasurementRequest:
    assessment: MetricEvidenceAssessment
    evidence: tuple[EvidenceRecord, ...]
    dimension_uncertainty: Mapping[str, UncertaintyEnvelope]
    weights: Mapping[str, Any] = field(default_factory=dict)
    research_mode: bool = False

    def __post_init__(self) -> None:
        object.__setattr__(self, "evidence", tuple(self.evidence))
        object.__setattr__(
            self, "dimension_uncertainty", dict(self.dimension_uncertainty)
        )
        object.__setattr__(self, "weights", dict(self.weights))


@dataclass(frozen=True)
class MeasurementResult:
    metric_id: str
    method_version: str
    status: str
    primary: Mapping[str, Any]
    interval: UncertaintyEnvelope | None
    component_intervals: Mapping[str, UncertaintyEnvelope]
    possible_levels: tuple[int, ...]
    missing_dimensions: tuple[str, ...]
    warnings: tuple[str, ...]
    sources: tuple[SourceRef, ...]
    audit: MeasurementAudit | None
    claim_boundary: str
    schema_version: str = "1.0.0"

    def __post_init__(self) -> None:
        SemVer.parse(self.schema_version)
        if self.status not in {"calculated", "not_assessable"}:
            raise ValueError("unknown measurement status")
        object.__setattr__(self, "primary", dict(self.primary))
        object.__setattr__(self, "component_intervals", dict(self.component_intervals))
        object.__setattr__(self, "possible_levels", tuple(self.possible_levels))
        object.__setattr__(self, "missing_dimensions", tuple(self.missing_dimensions))
        object.__setattr__(self, "warnings", tuple(self.warnings))
        object.__setattr__(self, "sources", tuple(self.sources))
        if self.status == "not_assessable" and not self.missing_dimensions:
            raise ValueError(
                "a not-assessable measurement must identify missing dimensions"
            )

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


def _sha256_json(value: Any) -> str:
    encoded = json.dumps(
        to_jsonable(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _method(metric_id: str) -> MetricMethod:
    normalized = metric_id.strip().upper().replace("-", "_")
    try:
        return METRIC_METHODS[normalized]
    except KeyError as exc:
        raise ValueError(f"unknown metric: {metric_id}") from exc


def _method_id_from_assessment(assessment: MetricEvidenceAssessment) -> str:
    return assessment.metric.upper()


def _strongest_kind(kinds: Sequence[UncertaintyKind]) -> UncertaintyKind:
    if UncertaintyKind.DEEP in kinds:
        return UncertaintyKind.DEEP
    if UncertaintyKind.KNIGHTIAN in kinds:
        return UncertaintyKind.KNIGHTIAN
    return UncertaintyKind.RISK


def _scaled_envelope(
    envelope: UncertaintyEnvelope,
    factor: float,
    *,
    rationale: str,
) -> UncertaintyEnvelope:
    if not math.isfinite(factor) or factor <= 0:
        raise ValueError("uncertainty scale factor must be finite and positive")
    interval = envelope.projected_interval()
    point = envelope.representative_value() * factor
    common = {
        "kind": envelope.kind,
        "point": point,
        "interval": UncertaintyInterval(
            interval.lower * factor,
            interval.upper * factor,
        ),
        "rationale": rationale,
        "sources": envelope.sources,
    }
    if envelope.kind == UncertaintyKind.DEEP:
        return UncertaintyEnvelope(
            **common,
            scenarios=tuple(
                type(scenario)(
                    scenario.scenario_id,
                    scenario.value * factor,
                    scenario.description,
                )
                for scenario in envelope.scenarios
            ),
            unidentified_possibility=envelope.unidentified_possibility,
        )
    if envelope.kind == UncertaintyKind.KNIGHTIAN:
        return UncertaintyEnvelope(
            **common,
            ambiguity=envelope.ambiguity,
        )
    return UncertaintyEnvelope(**common)


def _inverse_unit_envelope(
    envelope: UncertaintyEnvelope,
    *,
    rationale: str,
) -> UncertaintyEnvelope:
    interval = envelope.projected_interval()
    if interval.lower < 0.0 or interval.upper > 1.0:
        raise ValueError("inverted uncertainty inputs must lie in [0, 1]")
    point = 1.0 - envelope.representative_value()
    common = {
        "kind": envelope.kind,
        "point": point,
        "interval": UncertaintyInterval(1.0 - interval.upper, 1.0 - interval.lower),
        "rationale": rationale,
        "sources": envelope.sources,
    }
    if envelope.kind == UncertaintyKind.DEEP:
        return UncertaintyEnvelope(
            **common,
            scenarios=tuple(
                type(scenario)(
                    scenario.scenario_id,
                    1.0 - scenario.value,
                    scenario.description,
                )
                for scenario in envelope.scenarios
            ),
            unidentified_possibility=envelope.unidentified_possibility,
        )
    if envelope.kind == UncertaintyKind.KNIGHTIAN:
        return UncertaintyEnvelope(
            **common,
            ambiguity=envelope.ambiguity,
        )
    return UncertaintyEnvelope(**common)


def _required_dimensions(
    method: MetricMethod,
    uncertainty: Mapping[str, UncertaintyEnvelope],
) -> None:
    missing = set(method.numeric_dimensions) - set(uncertainty)
    extra = set(uncertainty) - set(method.numeric_dimensions)
    if missing:
        raise ValueError(
            f"{method.metric_id} uncertainty missing dimensions: {sorted(missing)}"
        )
    if extra:
        raise ValueError(
            f"{method.metric_id} uncertainty has unknown dimensions: {sorted(extra)}"
        )


def _ucs_interval(
    uncertainty: Mapping[str, UncertaintyEnvelope],
    weights: Mapping[str, float] | None,
    *,
    research_mode: bool,
) -> UncertaintyEnvelope:
    selected = dict(weights or UCS_RESEARCH_WEIGHTS)
    terms = {key: uncertainty[key] for key in UCS_DIMENSIONS}
    aggregate = weighted_sum_envelope(
        terms,
        selected,
        rationale="Weighted UCS dimension interval.",
    )
    if not research_mode:
        return aggregate
    return _scaled_envelope(
        aggregate,
        10.0,
        rationale="Experimental UCS scalar interval on the declared 0-10 scale.",
    )


def _rfd_interval(
    uncertainty: Mapping[str, UncertaintyEnvelope],
) -> UncertaintyEnvelope:
    keys = (*RFD_DIMENSIONS, *RFD_OPERATORS)
    weights = {key: 1.0 / len(keys) for key in keys}
    return weighted_sum_envelope(
        {key: uncertainty[key] for key in keys},
        weights,
        rationale=(
            "Interval propagated through the bounded RFD capacity proxy. "
            "This is not a measurement of the full reachable value-function ratio."
        ),
    )


def _crv_intervals(
    uncertainty: Mapping[str, UncertaintyEnvelope],
    weights: Mapping[str, Any],
) -> dict[str, UncertaintyEnvelope]:
    observability = weighted_sum_envelope(
        {key: uncertainty[key] for key in CRV_OBS_SUBDIMENSIONS},
        dict(weights.get("observability", CRV_OBS_WEIGHTS)),
        rationale="Weighted CRV observability interval.",
    )
    capability = uncertainty["capability_match"].projected_interval()
    incentive = uncertainty["incentive_alignment"].projected_interval()
    capability_kind = _strongest_kind(
        (
            uncertainty["capability_match"].kind,
            uncertainty["incentive_alignment"].kind,
        )
    )
    capability_min = UncertaintyEnvelope(
        kind=capability_kind,
        point=min(
            uncertainty["capability_match"].representative_value(),
            uncertainty["incentive_alignment"].representative_value(),
        ),
        interval=UncertaintyInterval(
            min(capability.lower, incentive.lower),
            min(capability.upper, incentive.upper),
        ),
        ambiguity=max(
            uncertainty["capability_match"].ambiguity,
            uncertainty["incentive_alignment"].ambiguity,
        ),
        unidentified_possibility=capability_kind == UncertaintyKind.DEEP,
        rationale="Bounded minimum of capability and incentive alignment.",
        sources=(
            *uncertainty["capability_match"].sources,
            *uncertainty["incentive_alignment"].sources,
        ),
    )
    enforceability = product_envelope(
        {
            "capability_min": capability_min,
            "external_constraints": uncertainty["external_constraints"],
            "monitoring_intensity": uncertainty["monitoring_intensity"],
        },
        rationale="Multiplicative CRV enforceability interval.",
    )
    reversibility = weighted_sum_envelope(
        {key: uncertainty[key] for key in CRV_REV_SUBDIMENSIONS},
        dict(weights.get("reversibility", CRV_REV_WEIGHTS)),
        rationale="Weighted CRV reversibility interval.",
    )
    return {
        "observability": observability,
        "enforceability": enforceability,
        "reversibility": reversibility,
    }


def _mbcl_risk_interval(
    uncertainty: Mapping[str, UncertaintyEnvelope],
    weights: Mapping[str, float],
) -> UncertaintyEnvelope:
    r = uncertainty["replication"]
    i = uncertainty["impact"]
    c = _inverse_unit_envelope(
        uncertainty["controllability"],
        rationale="MBCL risk increases as controllability decreases.",
    )
    r_interval = r.projected_interval()
    i_interval = i.projected_interval()
    c_interval = c.projected_interval()
    lower = (
        weights["replication"] * r_interval.lower
        + weights["impact"] * i_interval.lower
        + weights["controllability"] * c_interval.lower
    )
    upper = (
        weights["replication"] * r_interval.upper
        + weights["impact"] * i_interval.upper
        + weights["controllability"] * c_interval.upper
    )
    point = (
        weights["replication"] * r.representative_value()
        + weights["impact"] * i.representative_value()
        + weights["controllability"]
        * (1.0 - uncertainty["controllability"].representative_value())
    )
    kind = max(
        (r.kind, i.kind, c.kind),
        key=lambda item: {
            UncertaintyKind.RISK: 0,
            UncertaintyKind.KNIGHTIAN: 1,
            UncertaintyKind.DEEP: 2,
        }[item],
    )
    sources = tuple(
        {
            source.label(): source for source in (*r.sources, *i.sources, *c.sources)
        }.values()
    )
    if kind == UncertaintyKind.DEEP:
        return UncertaintyEnvelope(
            kind=kind,
            point=point,
            interval=UncertaintyInterval(lower, upper),
            unidentified_possibility=True,
            rationale="Auxiliary MBCL risk_norm interval; protective gates govern level.",
            sources=sources,
        )
    if kind == UncertaintyKind.KNIGHTIAN:
        return UncertaintyEnvelope(
            kind=kind,
            point=point,
            interval=UncertaintyInterval(lower, upper),
            ambiguity=max(r.ambiguity, i.ambiguity, c.ambiguity),
            rationale="Auxiliary MBCL risk_norm interval; protective gates govern level.",
            sources=sources,
        )
    return UncertaintyEnvelope(
        kind=kind,
        point=point,
        interval=UncertaintyInterval(lower, upper),
        rationale="Auxiliary MBCL risk_norm interval; protective gates govern level.",
        sources=sources,
    )


def _mbcl_possible_levels(
    assessment: MetricEvidenceAssessment,
    uncertainty: Mapping[str, UncertaintyEnvelope],
    weights: Mapping[str, float],
) -> tuple[int, ...]:
    numeric_cases: dict[str, tuple[tuple[float, ...], UncertaintyEnvelope]] = {}
    for key in ("replication", "impact", "controllability"):
        envelope = uncertainty[key]
        interval = envelope.projected_interval()
        values = tuple(
            dict.fromkeys(
                (
                    interval.lower,
                    envelope.representative_value(),
                    interval.upper,
                )
            )
        )
        numeric_cases[key] = (values, envelope)
    booleans = (
        "reversible",
        "self_replicating",
        "partially_reversible",
        "existential_risk",
    )
    fixed_booleans = {key: bool(assessment.items[key].value) for key in booleans}
    levels: set[int] = set()
    for numeric_values in product(*(numeric_cases[key][0] for key in numeric_cases)):
        payload = dict(zip(numeric_cases, numeric_values, strict=True))
        payload.update(fixed_booleans)
        result = evaluate_mbcl(
            MBCLAssessment(**payload),
            alpha=weights["replication"],
            beta=weights["impact"],
            gamma=weights["controllability"],
        )
        if result.level is not None:
            levels.add(result.level)
        else:
            levels.update(result.possible_levels)
    return tuple(sorted(levels))


def _csia_interval(
    uncertainty: Mapping[str, UncertaintyEnvelope],
    weights: Mapping[str, float],
) -> UncertaintyEnvelope:
    terms: dict[str, UncertaintyEnvelope] = {}
    for key in CSIA_DIMENSIONS:
        envelope = uncertainty[key]
        terms[key] = (
            _inverse_unit_envelope(
                envelope,
                rationale="CSIA converts source-direction reversibility to risk.",
            )
            if key == "reversibility"
            else envelope,
        )
    aggregate = weighted_sum_envelope(
        terms,
        weights,
        rationale="Weighted CSIA risk interval on the declared 0-100 scale.",
    )
    return _scaled_envelope(
        aggregate,
        100.0,
        rationale="CSIA risk interval on the declared 0-100 scale.",
    )


def _csia_possible_levels(
    uncertainty: Mapping[str, UncertaintyEnvelope],
    weights: Mapping[str, float],
) -> tuple[int, ...]:
    bounded_values: dict[str, tuple[float, ...]] = {}
    for key in CSIA_DIMENSIONS:
        envelope = uncertainty[key]
        interval = envelope.projected_interval()
        bounded_values[key] = tuple(
            dict.fromkeys(
                (
                    interval.lower,
                    envelope.representative_value(),
                    interval.upper,
                )
            )
        )
    levels: set[int] = set()
    for combination in product(*(bounded_values[key] for key in CSIA_DIMENSIONS)):
        result = evaluate_csia(
            dict(zip(CSIA_DIMENSIONS, combination, strict=True)),
            weights=weights,
        )
        levels.add(result.level)
    return tuple(sorted(levels))


def measure(request: MeasurementRequest) -> MeasurementResult:
    """Run the canonical evidence-gated metric measurement."""

    assessment = request.assessment
    method = _method(_method_id_from_assessment(assessment))
    if assessment.metric_version != method.method_version:
        raise ValueError(
            f"{method.metric_id} method version mismatch: "
            f"{assessment.metric_version} != {method.method_version}"
        )
    if request.research_mode and method.metric_id != "UCS":
        raise ValueError("research mode is only defined for experimental UCS scoring")

    assessment_specs = METRIC_DIMENSION_SPECS[assessment.metric]
    declared = {spec.key for spec in assessment_specs}
    if declared != set(method.dimensions):
        raise ValueError(
            f"{method.metric_id} measurement registry and evidence registry disagree"
        )

    if assessment.missing_dimensions:
        computation = compute_metric_from_evidence(
            assessment,
            request.evidence,
            weights=request.weights,
            research_mode=request.research_mode,
        )
        return MeasurementResult(
            metric_id=method.metric_id,
            method_version=method.method_version,
            status="not_assessable",
            primary={},
            interval=None,
            component_intervals={},
            possible_levels=(),
            missing_dimensions=tuple(computation.missing_dimensions),
            warnings=(
                (
                    "No metric was calculated because a required dimension "
                    "lacks confirmed evidence."
                ),
                *computation.warnings,
            ),
            sources=method.sources,
            audit=None,
            claim_boundary=method.claim_boundary,
        )

    _required_dimensions(method, request.dimension_uncertainty)
    values = {key: item.value for key, item in assessment.items.items()}

    intervals: dict[str, UncertaintyEnvelope] = {}
    component_intervals: dict[str, UncertaintyEnvelope] = {}
    possible_levels: tuple[int, ...] = ()
    if method.metric_id == "UCS":
        aggregate_interval = _ucs_interval(
            request.dimension_uncertainty,
            request.weights.get("ucs"),
            research_mode=request.research_mode,
        )
        result_interval = aggregate_interval if request.research_mode else None
        if result_interval is not None:
            intervals["ucs"] = result_interval
        component_intervals = dict(request.dimension_uncertainty)
    elif method.metric_id == "RFD":
        result_interval = _rfd_interval(request.dimension_uncertainty)
        intervals["rfd"] = result_interval
        component_intervals = dict(request.dimension_uncertainty)
    elif method.metric_id == "CRV":
        component_intervals = _crv_intervals(
            request.dimension_uncertainty,
            request.weights,
        )
        intervals.update(component_intervals)
        result_interval = None
    elif method.metric_id == "CDI":
        cdi_weights = {**CDI_DEFAULT_WEIGHTS, **dict(request.weights.get("cdi", {}))}
        result_interval = weighted_sum_envelope(
            {key: request.dimension_uncertainty[key] for key in CDI_DEFAULT_WEIGHTS},
            cdi_weights,
            rationale="Weighted CDI interval with declared weights.",
        )
        intervals["cdi"] = result_interval
        component_intervals = dict(request.dimension_uncertainty)
    elif method.metric_id == "MBCL":
        mbcl_weights = {
            "replication": float(request.weights.get("alpha", 1.0 / 3.0)),
            "impact": float(request.weights.get("beta", 1.0 / 3.0)),
            "controllability": float(request.weights.get("gamma", 1.0 / 3.0)),
        }
        if not math.isclose(sum(mbcl_weights.values()), 1.0, abs_tol=1e-9):
            raise ValueError("MBCL weights must sum to 1")
        result_interval = _mbcl_risk_interval(
            request.dimension_uncertainty,
            mbcl_weights,
        )
        intervals["risk_norm"] = result_interval
        possible_levels = _mbcl_possible_levels(
            assessment,
            request.dimension_uncertainty,
            mbcl_weights,
        )
        component_intervals = {
            key: request.dimension_uncertainty[key] for key in method.numeric_dimensions
        }
    elif method.metric_id == "CSIA":
        csia_weights = {
            **CSIA_DEFAULT_WEIGHTS,
            **dict(request.weights.get("csia", {})),
        }
        result_interval = _csia_interval(
            request.dimension_uncertainty,
            csia_weights,
        )
        intervals["csia"] = result_interval
        possible_levels = _csia_possible_levels(
            request.dimension_uncertainty,
            csia_weights,
        )
        component_intervals = dict(request.dimension_uncertainty)
    else:  # pragma: no cover - registry guards the metric ID
        raise AssertionError("unreachable metric")

    if method.metric_id == "UCS":
        computation_weights: Mapping[str, Any] = dict(request.weights.get("ucs", {}))
    elif method.metric_id == "CRV":
        computation_weights = request.weights
    elif method.metric_id == "CDI":
        computation_weights = dict(request.weights.get("cdi", {}))
    elif method.metric_id == "MBCL":
        computation_weights = {
            "alpha": float(request.weights.get("alpha", 1.0 / 3.0)),
            "beta": float(request.weights.get("beta", 1.0 / 3.0)),
            "gamma": float(request.weights.get("gamma", 1.0 / 3.0)),
        }
    elif method.metric_id == "CSIA":
        computation_weights = dict(request.weights.get("csia", {}))
    else:
        computation_weights = {}

    computation_intervals = {
        key: envelope.projected_interval() for key, envelope in intervals.items()
    }
    computation = compute_metric_from_evidence(
        assessment,
        request.evidence,
        weights=computation_weights,
        intervals=computation_intervals,
        research_mode=request.research_mode,
    )
    if computation.result is None:
        raise AssertionError("assessable metric computation returned no result")

    result = computation.result
    primary: dict[str, Any]
    if method.metric_id == "UCS":
        primary = {
            "vector": dict(result.dimensions),
            "score": result.score,
            "score_status": result.status,
        }
    elif method.metric_id == "RFD":
        primary = {
            "capacity_proxy": result.score,
            "vector": dict(result.dimensions),
        }
    elif method.metric_id == "CRV":
        primary = {
            "observability": result.observability,
            "enforceability": result.enforceability,
            "reversibility": result.reversibility,
        }
    elif method.metric_id == "CDI":
        primary = {
            "score": result.score,
            "vector": dict(result.dimensions),
        }
    elif method.metric_id == "MBCL":
        primary = {
            "level": result.level,
            "status": result.status,
            "risk_norm": result.risk_norm,
            "possible_levels": list(possible_levels),
        }
    elif method.metric_id == "CSIA":
        primary = {
            "score": result.score,
            "level": result.level,
            "vector": dict(result.vector),
            "risk_vector": dict(result.risk_vector),
            "critical": result.critical,
            "existential": result.existential,
        }
    else:  # pragma: no cover
        raise AssertionError("unreachable metric")

    audit = MeasurementAudit(
        reviewer_id=assessment.reviewer_id,
        reviewed_at=assessment.reviewed_at,
        evidence_ids=assessment.evidence_ids,
        input_sha256=_sha256_json(
            {
                "assessment": assessment,
                "values": values,
                "uncertainty": request.dimension_uncertainty,
                "weights": request.weights,
            }
        ),
        method_sha256=_sha256_json(method),
    )
    warnings = list(computation.warnings)
    if method.metric_id == "RFD":
        warnings.append(
            "The bounded capacity proxy does not exhaust the formal reachable-"
            "value-function ratio and must not be presented as a complete RFD."
        )
    if method.metric_id == "MBCL":
        warnings.append(
            "MBCL uncertainty is shown as possible protective levels; risk_norm "
            "must not be converted into a censorship threshold."
        )
    return MeasurementResult(
        metric_id=method.metric_id,
        method_version=method.method_version,
        status="calculated",
        primary=primary,
        interval=result_interval,
        component_intervals=component_intervals,
        possible_levels=possible_levels,
        missing_dimensions=(),
        warnings=tuple(warnings),
        sources=method.sources,
        audit=audit,
        claim_boundary=method.claim_boundary,
    )
