from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from enum import Enum

from .models import EvidenceGrade
from .serialization import to_jsonable
from .version import SemVer


@dataclass(frozen=True)
class ControlFinding:
    key: str
    label: str
    dimension: str
    grade: EvidenceGrade
    evidence_ids: tuple[str, ...] = ()
    human_confirmed: bool = False
    required_artifacts: tuple[str, ...] = ()
    recommendation: str = ""

    @classmethod
    def from_dict(cls, payload: dict[str, object]) -> ControlFinding:
        return cls(
            key=str(payload["key"]),
            label=str(payload["label"]),
            dimension=str(payload["dimension"]),
            grade=EvidenceGrade(str(payload["grade"])),
            evidence_ids=tuple(str(item) for item in payload.get("evidence_ids", ())),
            human_confirmed=bool(payload.get("human_confirmed", False)),
            required_artifacts=tuple(
                str(item) for item in payload.get("required_artifacts", ())
            ),
            recommendation=str(payload.get("recommendation", "")),
        )

    def validate(self) -> None:
        if (
            self.grade
            in {
                EvidenceGrade.DOCUMENTED,
                EvidenceGrade.OPERATIONALLY_EVIDENCED,
                EvidenceGrade.INDEPENDENTLY_VERIFIED,
            }
            and not self.evidence_ids
        ):
            raise ValueError(f"{self.key}: positive grade requires evidence")
        if (
            self.grade
            in {
                EvidenceGrade.OPERATIONALLY_EVIDENCED,
                EvidenceGrade.INDEPENDENTLY_VERIFIED,
            }
            and not self.human_confirmed
        ):
            raise ValueError(f"{self.key}: E3/E4 requires human confirmation")


@dataclass(frozen=True)
class PortableAuditRecord:
    product_id: str
    product_version: str
    methodology_version: str
    mode: str
    profile: str
    generated_at: datetime
    subject_sha256: str
    controls: tuple[ControlFinding, ...]
    warnings: tuple[str, ...] = ()
    claim_boundary: str = ""
    schema_version: str = "1.0.0"

    def __post_init__(self) -> None:
        SemVer.parse(self.product_version)
        SemVer.parse(self.schema_version)
        if not self.product_id.strip():
            raise ValueError("product_id is required")
        if not self.controls:
            raise ValueError("at least one control finding is required")
        for control in self.controls:
            control.validate()

    def to_dict(self) -> dict[str, object]:
        return to_jsonable(self)

    @classmethod
    def from_dict(cls, payload: dict[str, object]) -> PortableAuditRecord:
        controls_raw = payload.get("controls", ())
        if not isinstance(controls_raw, list):
            raise TypeError("controls must be a list")
        return cls(
            product_id=str(payload["product_id"]),
            product_version=str(payload["product_version"]),
            methodology_version=str(payload["methodology_version"]),
            mode=str(payload["mode"]),
            profile=str(payload["profile"]),
            generated_at=datetime.fromisoformat(str(payload["generated_at"])),
            subject_sha256=str(payload["subject_sha256"]),
            controls=tuple(
                ControlFinding.from_dict(control)
                for control in controls_raw
                if isinstance(control, dict)
            ),
            warnings=tuple(str(item) for item in payload.get("warnings", ())),
            claim_boundary=str(payload.get("claim_boundary", "")),
            schema_version=str(payload.get("schema_version", "1.0.0")),
        )


class ChangeType(str, Enum):
    ADDED = "added"
    REMOVED = "removed"
    MODIFIED = "modified"


class ChangeDirection(str, Enum):
    IMPROVED = "improved"
    UNCHANGED = "unchanged"
    REGRESSED = "regressed"
    INCOMPARABLE = "incomparable"


@dataclass(frozen=True)
class ControlChange:
    key: str
    change_type: ChangeType
    previous_grade: EvidenceGrade | None
    current_grade: EvidenceGrade | None
    direction: ChangeDirection
    evidence_added: tuple[str, ...] = ()
    evidence_removed: tuple[str, ...] = ()


@dataclass(frozen=True)
class AuditChangeReport:
    product_id: str
    previous_version: str
    current_version: str
    changes: tuple[ControlChange, ...]

    def to_dict(self) -> dict[str, object]:
        return to_jsonable(self)

    @property
    def improved_count(self) -> int:
        return sum(
            change.direction == ChangeDirection.IMPROVED for change in self.changes
        )

    @property
    def regressed_count(self) -> int:
        return sum(
            change.direction == ChangeDirection.REGRESSED for change in self.changes
        )

    @property
    def added_count(self) -> int:
        return sum(change.change_type == ChangeType.ADDED for change in self.changes)

    @property
    def removed_count(self) -> int:
        return sum(change.change_type == ChangeType.REMOVED for change in self.changes)


_GRADE_RANK = {
    EvidenceGrade.CONTRADICTED: 0,
    EvidenceGrade.ABSENT: 1,
    EvidenceGrade.NOT_ASSESSABLE: 2,
    EvidenceGrade.ASSERTED: 3,
    EvidenceGrade.DOCUMENTED: 4,
    EvidenceGrade.OPERATIONALLY_EVIDENCED: 5,
    EvidenceGrade.INDEPENDENTLY_VERIFIED: 6,
}


def compare_audits(
    previous: PortableAuditRecord,
    current: PortableAuditRecord,
) -> AuditChangeReport:
    if previous.product_id != current.product_id:
        raise ValueError("cannot compare different products")
    if current.generated_at < previous.generated_at:
        raise ValueError("current audit predates previous audit")

    old = {control.key: control for control in previous.controls}
    new = {control.key: control for control in current.controls}
    changes: list[ControlChange] = []
    for key in sorted(set(old) | set(new)):
        before = old.get(key)
        after = new.get(key)
        if before is None:
            changes.append(
                ControlChange(
                    key=key,
                    change_type=ChangeType.ADDED,
                    previous_grade=None,
                    current_grade=after.grade,
                    direction=ChangeDirection.INCOMPARABLE,
                    evidence_added=after.evidence_ids,
                )
            )
            continue
        if after is None:
            changes.append(
                ControlChange(
                    key=key,
                    change_type=ChangeType.REMOVED,
                    previous_grade=before.grade,
                    current_grade=None,
                    direction=ChangeDirection.INCOMPARABLE,
                    evidence_removed=before.evidence_ids,
                )
            )
            continue
        if before.grade == after.grade and before.evidence_ids == after.evidence_ids:
            continue
        previous_rank = _GRADE_RANK[before.grade]
        current_rank = _GRADE_RANK[after.grade]
        direction = (
            ChangeDirection.IMPROVED
            if current_rank > previous_rank
            else ChangeDirection.REGRESSED
            if current_rank < previous_rank
            else ChangeDirection.UNCHANGED
        )
        before_ids = set(before.evidence_ids)
        after_ids = set(after.evidence_ids)
        changes.append(
            ControlChange(
                key=key,
                change_type=ChangeType.MODIFIED,
                previous_grade=before.grade,
                current_grade=after.grade,
                direction=direction,
                evidence_added=tuple(sorted(after_ids - before_ids)),
                evidence_removed=tuple(sorted(before_ids - after_ids)),
            )
        )
    return AuditChangeReport(
        product_id=current.product_id,
        previous_version=previous.product_version,
        current_version=current.product_version,
        changes=tuple(changes),
    )
