from __future__ import annotations

import math
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime
from typing import Any

from .metrics import (
    CDI_DIMENSIONS,
    CRV_ENF_SUBDIMENSIONS,
    CRV_OBS_SUBDIMENSIONS,
    CRV_REV_SUBDIMENSIONS,
    CSIA_DIMENSIONS,
    RFD_DIMENSIONS,
    RFD_OPERATORS,
    UCS_DIMENSIONS,
    MBCLAssessment,
    evaluate_cdi,
    evaluate_crv,
    evaluate_csia,
    evaluate_mbcl,
    evaluate_rfd_capacity,
    evaluate_ucs_research_score,
    evaluate_ucs_structured,
)
from .models import EvidenceRecord, SourceRef, UncertaintyInterval
from .rules import INDICATORS
from .serialization import to_jsonable
from .version import SemVer


@dataclass(frozen=True)
class DimensionSpec:
    key: str
    value_kind: str


_METRIC_ALIASES = {
    "ucs": "ucs",
    "rfd": "rfd",
    "rfd_capacity": "rfd",
    "crv": "crv",
    "cdi": "cdi",
    "mbcl": "mbcl",
    "csia": "csia",
}

_METRIC_NAMES = {
    "ucs": "UCS",
    "rfd": "RFD_capacity",
    "crv": "CRV",
    "cdi": "CDI",
    "mbcl": "MBCL",
    "csia": "CSIA",
}

_INDICATOR_IDS = {
    "ucs": "UCS",
    "rfd": "RFD",
    "crv": "CRV",
    "cdi": "CDI",
    "mbcl": "MBCL",
    "csia": "CSIA",
}

METRIC_DIMENSION_SPECS: dict[str, tuple[DimensionSpec, ...]] = {
    "ucs": tuple(DimensionSpec(key, "number") for key in UCS_DIMENSIONS),
    "rfd": (
        *(DimensionSpec(key, "number") for key in RFD_DIMENSIONS),
        *(DimensionSpec(key, "number") for key in RFD_OPERATORS),
    ),
    "crv": (
        *(DimensionSpec(key, "number") for key in CRV_OBS_SUBDIMENSIONS),
        *(DimensionSpec(key, "number") for key in CRV_ENF_SUBDIMENSIONS),
        *(DimensionSpec(key, "number") for key in CRV_REV_SUBDIMENSIONS),
    ),
    "cdi": tuple(DimensionSpec(key, "number") for key in CDI_DIMENSIONS),
    "mbcl": (
        DimensionSpec("replication", "number"),
        DimensionSpec("impact", "number"),
        DimensionSpec("controllability", "number"),
        DimensionSpec("reversible", "boolean"),
        DimensionSpec("self_replicating", "boolean"),
        DimensionSpec("partially_reversible", "boolean"),
        DimensionSpec("existential_risk", "boolean"),
    ),
    "csia": tuple(DimensionSpec(key, "number") for key in CSIA_DIMENSIONS),
}

_CRV_GROUPS = {
    "observability": CRV_OBS_SUBDIMENSIONS,
    "enforceability": CRV_ENF_SUBDIMENSIONS,
    "reversibility": CRV_REV_SUBDIMENSIONS,
}


def _normalize_metric(metric: str) -> str:
    normalized = metric.strip().lower().replace("-", "_").replace(" ", "_")
    try:
        return _METRIC_ALIASES[normalized]
    except KeyError as exc:
        raise ValueError(f"unknown metric: {metric}") from exc


def _validate_numeric_value(value: float, key: str) -> float:
    number = float(value)
    if not math.isfinite(number) or not 0.0 <= number <= 1.0:
        raise ValueError(f"{key} must be a finite number in [0, 1]")
    return number


@dataclass
class DimensionAssessment:
    """A reviewer's evidence-linked judgment for one required dimension."""

    key: str
    value: float | bool | None
    evidence_ids: tuple[str, ...] = ()
    rubric_id: str = ""
    rationale: str = ""
    missing_evidence: tuple[str, ...] = ()
    uncertainty: UncertaintyInterval | None = None

    def __post_init__(self) -> None:
        self.evidence_ids = tuple(str(item) for item in self.evidence_ids)
        self.missing_evidence = tuple(str(item) for item in self.missing_evidence)
        if not self.key.strip():
            raise ValueError("dimension key is required")
        if len(set(self.evidence_ids)) != len(self.evidence_ids):
            raise ValueError(f"{self.key}: evidence_ids must be unique")
        if any(not item.strip() for item in self.evidence_ids):
            raise ValueError(f"{self.key}: evidence_ids must not be blank")
        if any(not item.strip() for item in self.missing_evidence):
            raise ValueError(f"{self.key}: missing_evidence must not be blank")

    @property
    def assessable(self) -> bool:
        return self.value is not None

    def validate(self, spec: DimensionSpec) -> None:
        if not self.assessable:
            if self.uncertainty is not None:
                raise ValueError(
                    f"{self.key}: an unassessed dimension cannot carry an interval"
                )
            if not self.missing_evidence and not self.rationale.strip():
                raise ValueError(
                    f"{self.key}: explain what evidence is missing or why it "
                    "cannot be assessed"
                )
            return

        if not self.evidence_ids:
            raise ValueError(f"{self.key}: assessed dimensions require evidence")
        if not self.rubric_id.strip():
            raise ValueError(f"{self.key}: rubric_id is required")
        if not self.rationale.strip():
            raise ValueError(f"{self.key}: rationale is required")

        if spec.value_kind == "boolean":
            if not isinstance(self.value, bool):
                raise TypeError(f"{self.key} must be boolean")
            if self.uncertainty is not None:
                raise ValueError(
                    f"{self.key}: Boolean dimensions cannot carry intervals"
                )
            return

        if isinstance(self.value, bool):
            raise TypeError(f"{self.key} must be numeric, not boolean")
        number = _validate_numeric_value(float(self.value), self.key)
        if self.uncertainty is not None:
            if not (0.0 <= self.uncertainty.lower <= self.uncertainty.upper <= 1.0):
                raise ValueError(f"{self.key}: interval must be within [0, 1]")
            if not self.uncertainty.contains(number):
                raise ValueError(f"{self.key}: value must lie inside its interval")


@dataclass
class MetricEvidenceAssessment:
    """The complete review record required before a metric can be calculated."""

    metric: str
    items: Mapping[str, DimensionAssessment]
    reviewer_id: str
    reviewed_at: datetime
    confirmed: bool = False
    metric_version: str = "2.0.0"

    def __post_init__(self) -> None:
        self.metric = _normalize_metric(self.metric)
        self.items = dict(self.items)

    def validate(self) -> None:
        SemVer.parse(self.metric_version)
        if not self.confirmed:
            raise ValueError(
                "metric evidence assessment requires explicit confirmation"
            )
        if not self.reviewer_id.strip():
            raise ValueError("reviewer_id is required")
        if self.reviewed_at.tzinfo is None:
            raise ValueError("reviewed_at must include a timezone")

        specs = {spec.key: spec for spec in METRIC_DIMENSION_SPECS[self.metric]}
        missing = set(specs) - set(self.items)
        extra = set(self.items) - set(specs)
        if missing:
            raise ValueError(
                f"{self.metric} assessment missing dimensions: {sorted(missing)}"
            )
        if extra:
            raise ValueError(
                f"{self.metric} assessment has unknown dimensions: {sorted(extra)}"
            )
        for key, spec in specs.items():
            item = self.items[key]
            if item.key != key:
                raise ValueError(
                    f"assessment key mismatch: mapping[{key!r}] contains {item.key!r}"
                )
            item.validate(spec)

    @property
    def missing_dimensions(self) -> tuple[str, ...]:
        return tuple(key for key, item in self.items.items() if not item.assessable)

    @property
    def evidence_ids(self) -> tuple[str, ...]:
        return tuple(
            dict.fromkeys(
                evidence_id
                for item in self.items.values()
                for evidence_id in item.evidence_ids
            )
        )


class EvidenceCatalog:
    """Index evidence spans by stable IDs and validate referenced records."""

    def __init__(self, records: Iterable[EvidenceRecord]) -> None:
        self._records_by_span: dict[str, EvidenceRecord] = {}
        self._records: list[EvidenceRecord] = []
        for record in records:
            record.validate()
            self._records.append(record)
            for span in record.spans:
                if span.evidence_id in self._records_by_span:
                    raise ValueError(f"duplicate evidence_id: {span.evidence_id}")
                self._records_by_span[span.evidence_id] = record

    def records_for(self, evidence_ids: Iterable[str]) -> tuple[EvidenceRecord, ...]:
        records: list[EvidenceRecord] = []
        seen: set[int] = set()
        for evidence_id in evidence_ids:
            try:
                record = self._records_by_span[evidence_id]
            except KeyError as exc:
                raise ValueError(f"unknown evidence_id: {evidence_id}") from exc
            identity = id(record)
            if identity not in seen:
                records.append(record)
                seen.add(identity)
        return tuple(records)


@dataclass
class MetricComputation:
    """A calculated metric or a traceable not-assessable result."""

    metric: str
    metric_version: str
    status: str
    result: Any | None
    reviewer_id: str
    reviewed_at: datetime
    evidence_ids: tuple[str, ...] = ()
    evidence: tuple[EvidenceRecord, ...] = ()
    dimension_trace: tuple[DimensionAssessment, ...] = ()
    sources: tuple[SourceRef, ...] = ()
    missing_dimensions: tuple[str, ...] = ()
    warnings: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if self.status not in {"calculated", "not_assessable"}:
            raise ValueError(f"unknown computation status: {self.status}")
        self.evidence_ids = tuple(self.evidence_ids)
        self.evidence = tuple(self.evidence)
        self.dimension_trace = tuple(self.dimension_trace)
        self.sources = tuple(self.sources)
        self.missing_dimensions = tuple(self.missing_dimensions)
        self.warnings = tuple(self.warnings)
        if self.status == "not_assessable" and self.result is not None:
            raise ValueError(
                "a not-assessable computation cannot carry a metric result"
            )
        if self.status == "not_assessable" and not self.missing_dimensions:
            raise ValueError(
                "a not-assessable computation must name missing dimensions"
            )

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


def _values(assessment: MetricEvidenceAssessment) -> dict[str, Any]:
    return {key: item.value for key, item in assessment.items.items()}


def _metric_interval(
    intervals: Mapping[str, UncertaintyInterval] | None,
    key: str,
) -> UncertaintyInterval | None:
    return None if intervals is None else intervals.get(key)


def compute_metric_from_evidence(
    assessment: MetricEvidenceAssessment,
    evidence_records: Iterable[EvidenceRecord],
    *,
    weights: Mapping[str, Any] | None = None,
    intervals: Mapping[str, UncertaintyInterval] | None = None,
    research_mode: bool = False,
) -> MetricComputation:
    """Calculate a metric only after every required dimension has evidence.

    CRV weights are keyed by ``observability`` and ``reversibility``. Other
    metrics accept the weight mapping used by their corresponding calculator.
    This function records reviewer judgment; it does not turn evidence into a
    score automatically.
    """

    assessment.validate()
    catalog = EvidenceCatalog(evidence_records)
    evidence = catalog.records_for(assessment.evidence_ids)

    if assessment.missing_dimensions:
        return MetricComputation(
            metric=_METRIC_NAMES[assessment.metric],
            metric_version=assessment.metric_version,
            status="not_assessable",
            result=None,
            reviewer_id=assessment.reviewer_id,
            reviewed_at=assessment.reviewed_at,
            evidence_ids=assessment.evidence_ids,
            evidence=evidence,
            dimension_trace=tuple(assessment.items.values()),
            sources=INDICATORS[_INDICATOR_IDS[assessment.metric]].sources,
            missing_dimensions=assessment.missing_dimensions,
            warnings=(
                (
                    "No metric was calculated because at least one required "
                    "dimension is not assessable."
                ),
            ),
        )

    values = _values(assessment)
    result: Any
    if assessment.metric == "ucs":
        interval = _metric_interval(intervals, "ucs")
        result = (
            evaluate_ucs_research_score(values, weights, interval=interval)
            if research_mode
            else evaluate_ucs_structured(values, interval=interval)
        )
    elif assessment.metric == "rfd":
        result = evaluate_rfd_capacity(
            {key: values[key] for key in RFD_DIMENSIONS},
            {key: values[key] for key in RFD_OPERATORS},
            interval=_metric_interval(intervals, "rfd"),
        )
    elif assessment.metric == "crv":
        crv_weights = weights or {}
        unknown_weight_groups = set(crv_weights) - set(_CRV_GROUPS)
        if unknown_weight_groups:
            raise ValueError(
                f"unknown CRV weight groups: {sorted(unknown_weight_groups)}"
            )
        result = evaluate_crv(
            {key: values[key] for key in CRV_OBS_SUBDIMENSIONS},
            {key: values[key] for key in CRV_ENF_SUBDIMENSIONS},
            {key: values[key] for key in CRV_REV_SUBDIMENSIONS},
            crv_weights.get("observability"),
            crv_weights.get("reversibility"),
            intervals=intervals,
        )
    elif assessment.metric == "cdi":
        result = evaluate_cdi(
            {key: values[key] for key in CDI_DIMENSIONS},
            weights,
            interval=_metric_interval(intervals, "cdi"),
        )
    elif assessment.metric == "mbcl":
        mbcl_weights = dict(weights or {})
        unknown_mbcl_weights = set(mbcl_weights) - {"alpha", "beta", "gamma"}
        if unknown_mbcl_weights:
            raise ValueError(f"unknown MBCL weights: {sorted(unknown_mbcl_weights)}")
        result = evaluate_mbcl(
            MBCLAssessment(**values),
            alpha=float(mbcl_weights.get("alpha", 1.0 / 3.0)),
            beta=float(mbcl_weights.get("beta", 1.0 / 3.0)),
            gamma=float(mbcl_weights.get("gamma", 1.0 / 3.0)),
            risk_interval=_metric_interval(intervals, "risk_norm"),
        )
    elif assessment.metric == "csia":
        result = evaluate_csia(
            {key: values[key] for key in CSIA_DIMENSIONS},
            weights,
            interval=_metric_interval(intervals, "csia"),
        )
    else:  # pragma: no cover - guarded by validation
        raise AssertionError("unreachable metric")

    if hasattr(result, "evidence"):
        result.evidence = list(evidence)

    return MetricComputation(
        metric=_METRIC_NAMES[assessment.metric],
        metric_version=assessment.metric_version,
        status="calculated",
        result=result,
        reviewer_id=assessment.reviewer_id,
        reviewed_at=assessment.reviewed_at,
        evidence_ids=assessment.evidence_ids,
        evidence=evidence,
        dimension_trace=tuple(assessment.items.values()),
        sources=INDICATORS[_INDICATOR_IDS[assessment.metric]].sources,
        warnings=(
            (
                "Dimension values are confirmed reviewer judgments linked to "
                "evidence; they are not inferred automatically from text."
            ),
        ),
    )
