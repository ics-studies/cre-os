from __future__ import annotations

import re
from dataclasses import dataclass
from functools import total_ordering

SEMVER_PATTERN = re.compile(
    r"^(0|[1-9]\d*)\."
    r"(0|[1-9]\d*)\."
    r"(0|[1-9]\d*)"
    r"(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?"
    r"(?:\+([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?$"
)


@total_ordering
@dataclass(frozen=True)
class SemVer:
    major: int
    minor: int
    patch: int
    prerelease: str | None = None
    build: str | None = None

    def __post_init__(self) -> None:
        if min(self.major, self.minor, self.patch) < 0:
            raise ValueError("SemVer components must be non-negative")
        for label, value in (
            ("prerelease", self.prerelease),
            ("build", self.build),
        ):
            if value is None:
                continue
            if not value or not re.fullmatch(
                r"[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*", value
            ):
                raise ValueError(f"invalid SemVer {label}: {value!r}")
        if self.prerelease:
            for identifier in self.prerelease.split("."):
                if identifier.isdigit() and identifier != str(int(identifier)):
                    raise ValueError(
                        "numeric prerelease identifiers must not contain leading zeros"
                    )

    @classmethod
    def parse(cls, value: str) -> SemVer:
        match = SEMVER_PATTERN.fullmatch(value)
        if not match:
            raise ValueError(f"not a valid SemVer 2.0 version: {value!r}")
        major, minor, patch, prerelease, build = match.groups()
        return cls(
            major=int(major),
            minor=int(minor),
            patch=int(patch),
            prerelease=prerelease,
            build=build,
        )

    @property
    def core(self) -> tuple[int, int, int]:
        return (self.major, self.minor, self.patch)

    def __str__(self) -> str:
        value = f"{self.major}.{self.minor}.{self.patch}"
        if self.prerelease:
            value += f"-{self.prerelease}"
        if self.build:
            value += f"+{self.build}"
        return value

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, SemVer):
            return NotImplemented
        return self.core == other.core and self.prerelease == other.prerelease

    def __hash__(self) -> int:
        return hash((self.core, self.prerelease))

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, SemVer):
            return NotImplemented
        if self.core != other.core:
            return self.core < other.core
        if self.prerelease is None:
            return False
        if other.prerelease is None:
            return True
        return _prerelease_key(self.prerelease) < _prerelease_key(other.prerelease)

    def bump_major(self) -> SemVer:
        return SemVer(self.major + 1, 0, 0)

    def bump_minor(self) -> SemVer:
        return SemVer(self.major, self.minor + 1, 0)

    def bump_patch(self) -> SemVer:
        return SemVer(self.major, self.minor, self.patch + 1)


def _prerelease_key(value: str) -> tuple[tuple[int, object], ...]:
    parts: list[tuple[int, object]] = []
    for identifier in value.split("."):
        if identifier.isdigit():
            parts.append((0, int(identifier)))
        else:
            parts.append((1, identifier))
    return tuple(parts)
