from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .models import SourceRef
from .version import SemVer


class RuleStatus(str, Enum):
    ACTIVE = "active"
    PENDING_AUTHOR = "pending_author"
    LEGACY = "legacy"
    DEPRECATED = "deprecated"
    CONFLICT = "conflict"


@dataclass(frozen=True)
class RuleDefinition:
    rule_id: str
    version: SemVer
    status: RuleStatus
    statement: str
    sources: tuple[SourceRef, ...]
    compatibility_note: str = ""

    def __post_init__(self) -> None:
        if not self.rule_id.strip():
            raise ValueError("rule_id is required")
        if not self.statement.strip():
            raise ValueError("statement is required")
        if not self.sources:
            raise ValueError("a rule must have at least one source")


@dataclass(frozen=True)
class IndicatorDescriptor:
    indicator_id: str
    version: SemVer
    output_kind: str
    dimensions: tuple[str, ...]
    default_weights: tuple[tuple[str, float], ...] = ()
    sources: tuple[SourceRef, ...] = ()
    claim_boundary: str = ""

    def __post_init__(self) -> None:
        if not self.sources:
            raise ValueError("an indicator must have at least one source")
        if not self.dimensions:
            raise ValueError("an indicator must declare its dimensions")
        keys = [key for key, _ in self.default_weights]
        if keys and set(keys) != set(self.dimensions):
            raise ValueError("default weights must match declared dimensions")
        if keys:
            total = sum(weight for _, weight in self.default_weights)
            if abs(total - 1.0) > 1e-9:
                raise ValueError("default weights must sum to 1")


class RuleRegistry:
    def __init__(self) -> None:
        self._rules: dict[str, RuleDefinition] = {}

    def add(self, rule: RuleDefinition) -> None:
        if rule.rule_id in self._rules:
            raise ValueError(f"duplicate rule: {rule.rule_id}")
        self._rules[rule.rule_id] = rule

    def get(self, rule_id: str) -> RuleDefinition:
        try:
            return self._rules[rule_id]
        except KeyError as exc:
            raise KeyError(f"unknown rule: {rule_id}") from exc

    def list(self, status: RuleStatus | None = None) -> tuple[RuleDefinition, ...]:
        if status is None:
            return tuple(self._rules.values())
        return tuple(rule for rule in self._rules.values() if rule.status == status)


INDICATORS: dict[str, IndicatorDescriptor] = {
    "UCS": IndicatorDescriptor(
        "UCS",
        SemVer.parse("2.0.0"),
        "structured_vector",
        (
            "information_integration",
            "time_depth",
            "reflexivity",
            "value_sensitivity",
            "sociality",
        ),
        sources=(SourceRef(2, "23", "23.1-23.4"), SourceRef(5, "14", "14.4")),
        claim_boundary="UCS does not prove consciousness or legal personhood.",
    ),
    "RFD": IndicatorDescriptor(
        "RFD",
        SemVer.parse("2.0.0"),
        "capacity_vector",
        (
            "cognitive",
            "volitional",
            "structural",
            "relational",
            "perception",
            "evaluation",
            "decision",
            "execution",
        ),
        sources=(
            SourceRef(2, "24", "24.1"),
            SourceRef(
                0,
                "21",
                "21.3-21.5",
                version=None,
                work="RECURSIVE_FREEDOM_LOWER",
            ),
        ),
        claim_boundary="RFD may not be used for rights or political reliability.",
    ),
    "CRV": IndicatorDescriptor(
        "CRV",
        SemVer.parse("2.0.0"),
        "three_dimensional_vector",
        (
            "signal_clarity",
            "verification_cost",
            "time_delay",
            "capability_match",
            "incentive_alignment",
            "external_constraints",
            "monitoring_intensity",
            "physical_reversibility",
            "institutional_reversibility",
            "cognitive_reversibility",
        ),
        sources=(SourceRef(2, "24", "24.5"), SourceRef(3, "6", "6.1")),
        claim_boundary="CRV assesses commitment structure, not truth or compliance.",
    ),
    "CDI": IndicatorDescriptor(
        "CDI",
        SemVer.parse("2.0.0"),
        "interval_index",
        ("eu", "ip", "nm", "ad", "nmat"),
        (
            ("eu", 0.20),
            ("ip", 0.20),
            ("nm", 0.25),
            ("ad", 0.15),
            ("nmat", 0.20),
        ),
        sources=(SourceRef(2, "25", "25.1"), SourceRef(3, "7", "7.1-7.4")),
        claim_boundary="CDI is not a ranking tool.",
    ),
    "MBCL": IndicatorDescriptor(
        "MBCL",
        SemVer.parse("2.0.0"),
        "ordinal_level",
        (
            "replication",
            "impact",
            "controllability",
            "reversible",
            "self_replicating",
            "partially_reversible",
            "existential_risk",
        ),
        sources=(SourceRef(2, "25", "25.2"), SourceRef(3, "8", "8.1-8.3")),
        claim_boundary=(
            "MBCL is not a censorship or political-content classification tool."
        ),
    ),
    "CSIA": IndicatorDescriptor(
        "CSIA",
        SemVer.parse("2.0.0"),
        "six_dimensional_vector",
        (
            "scope",
            "temporal_depth",
            "severity",
            "reversibility",
            "uncertainty",
            "cascade",
        ),
        (
            ("scope", 0.15),
            ("temporal_depth", 0.15),
            ("severity", 0.20),
            ("reversibility", 0.20),
            ("uncertainty", 0.15),
            ("cascade", 0.15),
        ),
        sources=(
            SourceRef(2, "25", "25.3"),
            SourceRef(3, "9", "9.1-9.4"),
        ),
        claim_boundary="CSIA supports structured impact assessment.",
    ),
}
