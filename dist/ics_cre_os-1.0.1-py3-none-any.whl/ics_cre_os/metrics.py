from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import dataclass

from .models import MetricResult, SourceRef, UncertaintyInterval

UCS_DIMENSIONS = (
    "information_integration",
    "time_depth",
    "reflexivity",
    "value_sensitivity",
    "sociality",
)

UCS_RESEARCH_WEIGHTS = {
    "information_integration": 0.30,
    "time_depth": 0.20,
    "reflexivity": 0.20,
    "value_sensitivity": 0.15,
    "sociality": 0.15,
}

RFD_DIMENSIONS = ("cognitive", "volitional", "structural", "relational")
RFD_OPERATORS = ("perception", "evaluation", "decision", "execution")

CSIA_DIMENSIONS = (
    "scope",
    "temporal_depth",
    "severity",
    "reversibility",
    "uncertainty",
    "cascade",
)

CSIA_DEFAULT_WEIGHTS = {
    "scope": 0.15,
    "temporal_depth": 0.15,
    "severity": 0.20,
    "reversibility": 0.20,
    "uncertainty": 0.15,
    "cascade": 0.15,
}

CDI_DIMENSIONS = ("eu", "ip", "nm", "ad", "nmat")

CDI_DEFAULT_WEIGHTS = {
    "eu": 0.20,
    "ip": 0.20,
    "nm": 0.25,
    "ad": 0.15,
    "nmat": 0.20,
}


def _bounded(value: float, name: str) -> float:
    number = float(value)
    if not math.isfinite(number) or not 0.0 <= number <= 1.0:
        raise ValueError(f"{name} must be a finite number in [0, 1]")
    return number


def _validate_vector(
    values: Mapping[str, float],
    required: tuple[str, ...],
    label: str,
) -> dict[str, float]:
    missing = set(required) - set(values)
    extra = set(values) - set(required)
    if missing:
        raise ValueError(f"{label} missing dimensions: {sorted(missing)}")
    if extra:
        raise ValueError(f"{label} has unknown dimensions: {sorted(extra)}")
    return {key: _bounded(values[key], f"{label}.{key}") for key in required}


def _normalized_weights(
    weights: Mapping[str, float],
    required: tuple[str, ...],
    label: str,
) -> dict[str, float]:
    missing = set(required) - set(weights)
    extra = set(weights) - set(required)
    if missing or extra:
        raise ValueError(
            f"{label} weights mismatch; missing={sorted(missing)}, extra={sorted(extra)}"
        )
    result = {}
    for key in required:
        value = float(weights[key])
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{label}.{key} must be finite and non-negative")
        result[key] = value
    total = sum(result.values())
    if not math.isclose(total, 1.0, abs_tol=1e-9):
        raise ValueError(f"{label} weights must sum to 1, got {total}")
    return result


def evaluate_ucs_structured(
    dimensions: Mapping[str, float],
    interval: UncertaintyInterval | None = None,
) -> MetricResult:
    vector = _validate_vector(dimensions, UCS_DIMENSIONS, "UCS")
    return MetricResult(
        metric="UCS",
        metric_version="2.0.0",
        dimensions=vector,
        score=None,
        interval=interval,
        sources=[
            SourceRef(2, "23", "23.1-23.4"),
            SourceRef(5, "14", "14.4"),
        ],
        warnings=[
            "UCS is a structured assessment by default; no scalar score is generated."
        ],
        claim_boundary=(
            "UCS measures documented indicators associated with consciousness. "
            "It does not prove consciousness, personhood, or legal status."
        ),
    )


def evaluate_ucs_research_score(
    dimensions: Mapping[str, float],
    weights: Mapping[str, float] | None = None,
    interval: UncertaintyInterval | None = None,
) -> MetricResult:
    result = evaluate_ucs_structured(dimensions, interval=interval)
    selected = _normalized_weights(
        weights or UCS_RESEARCH_WEIGHTS,
        UCS_DIMENSIONS,
        "UCS",
    )
    raw = sum(selected[key] * result.dimensions[key] for key in UCS_DIMENSIONS)
    result.score = round(raw * 10.0, 6)
    result.status = "experimental"
    result.warnings.append(
        "(Reference) Experimental single score; not validated for high-stakes use."
    )
    return result


def evaluate_rfd_capacity(
    dimensions: Mapping[str, float],
    operators: Mapping[str, float],
    interval: UncertaintyInterval | None = None,
) -> MetricResult:
    dm = _validate_vector(dimensions, RFD_DIMENSIONS, "RFD dimensions")
    op = _validate_vector(operators, RFD_OPERATORS, "RFD operators")
    dimension_score = sum(dm.values()) / len(dm)
    operator_score = sum(op.values()) / len(op)
    score = (dimension_score + operator_score) / 2.0
    vector = {
        **{f"dimension.{key}": value for key, value in dm.items()},
        **{f"operator.{key}": value for key, value in op.items()},
    }
    return MetricResult(
        metric="RFD_capacity",
        metric_version="2.0.0",
        dimensions=vector,
        score=round(score, 6),
        interval=interval,
        sources=[
            SourceRef(2, "24", "24.1"),
            SourceRef(
                0,
                "21",
                "21.3-21.5",
                version=None,
                ruling="A-19",
                work="RECURSIVE_FREEDOM_LOWER",
            ),
        ],
        warnings=[
            "RFD is a converging construct, not a physical quantity with one true value.",
            (
                "The bounded capacity is a proxy; the formal reachable-value-"
                "function ratio is computed separately when closure data are "
                "available."
            ),
        ],
        claim_boundary=(
            "RFD capacity assessments are context-sensitive and may not be used "
            "for rights, safety clearance, political reliability, or other "
            "high-stakes individual decisions."
        ),
    )


def evaluate_rfd_ratio(
    reachable_value_functions: int,
    closure_size: int,
    *,
    achieved_recursion_layer: int,
) -> MetricResult:
    """Evaluate the lower-volume RFD ratio for a finite closure sample.

    The full formal RFD is the measure of non-trivially reachable value
    functions divided by the measure of the entire value-function closure.
    A complete recursive-freedom claim requires at least recursive layer two.
    """

    if closure_size < 1:
        raise ValueError("closure_size must be positive")
    if not 0 <= reachable_value_functions <= closure_size:
        raise ValueError(
            "reachable_value_functions must be between zero and closure_size"
        )
    if achieved_recursion_layer < 0:
        raise ValueError("achieved_recursion_layer must be non-negative")
    score = round(reachable_value_functions / closure_size, 6)
    return MetricResult(
        metric="RFD_reachability",
        metric_version="2.0.0",
        dimensions={
            "reachable_value_functions": float(reachable_value_functions),
            "closure_size": float(closure_size),
            "achieved_recursion_layer": float(achieved_recursion_layer),
        },
        score=score,
        sources=[
            SourceRef(
                0,
                "19",
                "19.7.1",
                "Definition 19.15",
                version=None,
                ruling="A-19",
                work="RECURSIVE_FREEDOM_LOWER",
            ),
            SourceRef(
                0,
                "19",
                "19.7.2",
                "Definition 19.16",
                version=None,
                ruling="A-19",
                work="RECURSIVE_FREEDOM_LOWER",
            ),
        ],
        warnings=(
            ()
            if achieved_recursion_layer >= 2
            else (
                (
                    "The reachable ratio is below recursive layer two and "
                    "therefore does not establish full recursive freedom."
                ),
            )
        ),
        status=(
            "calculated" if achieved_recursion_layer >= 2 else "below_recursive_layer"
        ),
        claim_boundary=(
            "This finite closure sample is an operational estimate of RFD. "
            "It does not justify rights, political reliability, or high-stakes "
            "individual decisions."
        ),
    )


def rfd_delta(
    before_capacity: float,
    after_capacity: float,
) -> float:
    before = _bounded(before_capacity, "before_capacity")
    after = _bounded(after_capacity, "after_capacity")
    return round(after - before, 6)


CRV_OBS_SUBDIMENSIONS = ("signal_clarity", "verification_cost", "time_delay")
CRV_ENF_SUBDIMENSIONS = (
    "capability_match",
    "incentive_alignment",
    "external_constraints",
    "monitoring_intensity",
)
CRV_REV_SUBDIMENSIONS = (
    "physical_reversibility",
    "institutional_reversibility",
    "cognitive_reversibility",
)
CRV_OBS_WEIGHTS = {
    "signal_clarity": 0.50,
    "verification_cost": 0.30,
    "time_delay": 0.20,
}
CRV_REV_WEIGHTS = {
    "physical_reversibility": 0.40,
    "institutional_reversibility": 0.30,
    "cognitive_reversibility": 0.30,
}


@dataclass(frozen=True)
class CRVVector:
    observability: float
    enforceability: float
    reversibility: float
    observability_interval: UncertaintyInterval | None = None
    enforceability_interval: UncertaintyInterval | None = None
    reversibility_interval: UncertaintyInterval | None = None


def evaluate_crv(
    observability: Mapping[str, float],
    enforceability: Mapping[str, float],
    reversibility: Mapping[str, float],
    observability_weights: Mapping[str, float] | None = None,
    reversibility_weights: Mapping[str, float] | None = None,
    intervals: Mapping[str, UncertaintyInterval] | None = None,
) -> CRVVector:
    obs = _validate_vector(observability, CRV_OBS_SUBDIMENSIONS, "CRV observability")
    enf = _validate_vector(enforceability, CRV_ENF_SUBDIMENSIONS, "CRV enforceability")
    rev = _validate_vector(reversibility, CRV_REV_SUBDIMENSIONS, "CRV reversibility")

    obs_w = _normalized_weights(
        observability_weights or CRV_OBS_WEIGHTS,
        CRV_OBS_SUBDIMENSIONS,
        "CRV observability",
    )
    rev_w = _normalized_weights(
        reversibility_weights or CRV_REV_WEIGHTS,
        CRV_REV_SUBDIMENSIONS,
        "CRV reversibility",
    )

    observability_score = sum(obs_w[key] * obs[key] for key in CRV_OBS_SUBDIMENSIONS)
    enforceability_score = (
        min(enf["capability_match"], enf["incentive_alignment"])
        * enf["external_constraints"]
        * enf["monitoring_intensity"]
    )
    reversibility_score = sum(rev_w[key] * rev[key] for key in CRV_REV_SUBDIMENSIONS)
    interval_map = dict(intervals or {})
    unknown_intervals = set(interval_map) - {
        "observability",
        "enforceability",
        "reversibility",
    }
    if unknown_intervals:
        raise ValueError(f"unknown CRV interval keys: {sorted(unknown_intervals)}")
    return CRVVector(
        observability=round(observability_score, 6),
        enforceability=round(enforceability_score, 6),
        reversibility=round(reversibility_score, 6),
        observability_interval=interval_map.get("observability"),
        enforceability_interval=interval_map.get("enforceability"),
        reversibility_interval=interval_map.get("reversibility"),
    )


def log_ratio_dimension(
    value: float,
    reference: float,
    maximum: float,
) -> float:
    value = float(value)
    if value <= 0 or reference <= 0 or maximum <= reference:
        raise ValueError("value and reference must be positive; maximum > reference")
    scaled = (math.log10(value) - math.log10(reference)) / (
        math.log10(maximum) - math.log10(reference)
    )
    return round(min(1.0, max(0.0, scaled)), 6)


def energy_utilization(power_watts: float) -> float:
    return log_ratio_dimension(power_watts, 1e13, 1e26)


def information_processing(flops: float) -> float:
    return log_ratio_dimension(flops, 1e18, 1e51)


def agency_diversity(proportions: Mapping[str, float] | list[float]) -> float:
    values = (
        list(proportions.values()) if isinstance(proportions, Mapping) else proportions
    )
    values = [float(value) for value in values if float(value) > 0]
    if not values:
        return 0.0
    if len(values) == 1:
        return 0.0
    total = sum(values)
    probabilities = [value / total for value in values]
    entropy = -sum(p * math.log(p) for p in probabilities)
    return round(min(1.0, entropy / math.log(len(probabilities))), 6)


def evaluate_cdi(
    dimensions: Mapping[str, float],
    weights: Mapping[str, float] | None = None,
    interval: UncertaintyInterval | None = None,
) -> MetricResult:
    vector = _validate_vector(dimensions, CDI_DIMENSIONS, "CDI")
    selected = _normalized_weights(
        weights or CDI_DEFAULT_WEIGHTS,
        CDI_DIMENSIONS,
        "CDI",
    )
    score = sum(selected[key] * vector[key] for key in CDI_DIMENSIONS)
    return MetricResult(
        metric="CDI",
        metric_version="2.0.0",
        dimensions=vector,
        score=round(score, 6),
        interval=interval,
        sources=[SourceRef(2, "25", "25.1"), SourceRef(3, "7", "7.1-7.4")],
        warnings=[
            "CDI is not a ranking tool and must report its weight profile and uncertainty."
        ],
        claim_boundary=(
            "CDI assesses documented dimensions of civilizational development; "
            "it is not a country or organization ranking."
        ),
    )


@dataclass(frozen=True)
class MBCLAssessment:
    replication: float
    impact: float
    controllability: float
    reversible: bool
    self_replicating: bool
    partially_reversible: bool = False
    existential_risk: bool = False


@dataclass(frozen=True)
class MBCLResult:
    level: int | None
    status: str
    risk_norm: float
    possible_levels: tuple[int, ...]
    reasons: tuple[str, ...]
    risk_interval: UncertaintyInterval | None = None


def _mbcl_band(value: float) -> int:
    value = _bounded(value, "MBCL dimension")
    if value < 0.2:
        return 1
    if value < 0.5:
        return 2
    if value < 0.8:
        return 3
    return 4


def _controllability_band(value: float) -> int:
    value = _bounded(value, "MBCL controllability")
    if value > 0.8:
        return 1
    if value > 0.5:
        return 2
    if value > 0.2:
        return 3
    return 4


def evaluate_mbcl(
    assessment: MBCLAssessment,
    alpha: float = 1.0 / 3.0,
    beta: float = 1.0 / 3.0,
    gamma: float = 1.0 / 3.0,
    risk_interval: UncertaintyInterval | None = None,
) -> MBCLResult:
    r = _bounded(assessment.replication, "MBCL replication")
    i = _bounded(assessment.impact, "MBCL impact")
    c = _bounded(assessment.controllability, "MBCL controllability")
    if min(alpha, beta, gamma) < 0 or not math.isclose(
        alpha + beta + gamma, 1.0, abs_tol=1e-9
    ):
        raise ValueError("MBCL weights must be non-negative and sum to 1")
    risk_norm = round(alpha * r + beta * i + gamma * (1.0 - c), 6)

    if assessment.existential_risk:
        return MBCLResult(
            level=4,
            status="classified",
            risk_norm=risk_norm,
            possible_levels=(4,),
            reasons=("existential_risk_gate",),
            risk_interval=risk_interval,
        )
    if assessment.reversible and assessment.self_replicating:
        return MBCLResult(
            level=None,
            status="contradictory",
            risk_norm=risk_norm,
            possible_levels=(),
            reasons=(
                "rule conflict: reversibility caps level at 2; self-replication floors it at 3",
            ),
            risk_interval=risk_interval,
        )

    bands = {
        _mbcl_band(r),
        _mbcl_band(i),
        _controllability_band(c),
    }
    if len(bands) == 1:
        level = bands.pop()
        if level == 1 and not assessment.reversible:
            return MBCLResult(
                level=None,
                status="undetermined",
                risk_norm=risk_norm,
                possible_levels=(2, 3, 4),
                reasons=("MBCL-1 requires full reversibility",),
                risk_interval=risk_interval,
            )
        if level == 2 and not (
            assessment.reversible or assessment.partially_reversible
        ):
            return MBCLResult(
                level=None,
                status="undetermined",
                risk_norm=risk_norm,
                possible_levels=(3, 4),
                reasons=("MBCL-2 requires reversible or partially reversible impact",),
                risk_interval=risk_interval,
            )
        if level == 3 and not (
            assessment.self_replicating or not assessment.reversible
        ):
            return MBCLResult(
                level=None,
                status="undetermined",
                risk_norm=risk_norm,
                possible_levels=(1, 2),
                reasons=("MBCL-3 requires self-replication or irreversibility",),
                risk_interval=risk_interval,
            )
        if level == 4 and not assessment.existential_risk:
            return MBCLResult(
                level=None,
                status="undetermined",
                risk_norm=risk_norm,
                possible_levels=(),
                reasons=("MBCL-4 requires an existential-risk determination",),
                risk_interval=risk_interval,
            )
        if assessment.reversible and level > 2:
            return MBCLResult(
                level=None,
                status="undetermined",
                risk_norm=risk_norm,
                possible_levels=(1, 2),
                reasons=("reversibility_cap", "mixed rule inputs"),
                risk_interval=risk_interval,
            )
        if assessment.self_replicating and level < 3:
            return MBCLResult(
                level=None,
                status="undetermined",
                risk_norm=risk_norm,
                possible_levels=(3, 4),
                reasons=("self_replication_floor", "mixed rule inputs"),
                risk_interval=risk_interval,
            )
        return MBCLResult(
            level=level,
            status="classified",
            risk_norm=risk_norm,
            possible_levels=(level,),
            reasons=("all dimension bands agree",),
            risk_interval=risk_interval,
        )

    possible = (1, 2, 3, 4)
    reasons = ["dimension bands do not agree"]
    if assessment.reversible:
        possible = tuple(level for level in possible if level <= 2)
        reasons.append("reversibility caps level at 2")
    if assessment.self_replicating:
        possible = tuple(level for level in possible if level >= 3)
        reasons.append("self-replication floors level at 3")
    return MBCLResult(
        level=None,
        status="undetermined",
        risk_norm=risk_norm,
        possible_levels=possible,
        reasons=tuple(reasons),
        risk_interval=risk_interval,
    )


@dataclass(frozen=True)
class CSIAResult:
    vector: dict[str, float]
    score: float
    level: int
    risk_vector: dict[str, float]
    interval: UncertaintyInterval | None = None
    critical: bool = False
    existential: bool = False


def evaluate_csia(
    dimensions: Mapping[str, float],
    weights: Mapping[str, float] | None = None,
    interval: UncertaintyInterval | None = None,
) -> CSIAResult:
    vector = _validate_vector(dimensions, CSIA_DIMENSIONS, "CSIA")
    selected = _normalized_weights(
        weights or CSIA_DEFAULT_WEIGHTS,
        CSIA_DIMENSIONS,
        "CSIA",
    )
    risk_vector = dict(vector)
    risk_vector["reversibility"] = round(1.0 - vector["reversibility"], 6)
    score = 100.0 * sum(selected[key] * risk_vector[key] for key in CSIA_DIMENSIONS)
    score = round(score, 6)
    critical = bool(
        risk_vector["scope"] > 0.8
        or risk_vector["severity"] > 0.8
        or (risk_vector["reversibility"] > 0.8 and risk_vector["uncertainty"] > 0.7)
    )
    existential = bool(
        risk_vector["severity"] > 0.9
        and risk_vector["scope"] > 0.9
        and risk_vector["reversibility"] > 0.9
    )
    if existential or score >= 75:
        level = 4
    elif critical or score >= 50:
        level = 3
    elif score >= 25:
        level = 2
    else:
        level = 1
    return CSIAResult(
        vector=vector,
        score=score,
        level=level,
        risk_vector=risk_vector,
        interval=interval,
        critical=critical,
        existential=existential,
    )
