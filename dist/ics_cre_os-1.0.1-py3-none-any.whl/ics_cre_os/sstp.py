from __future__ import annotations

import random
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass, field
from enum import Enum
from math import isfinite
from typing import Any

from .models import SourceRef
from .serialization import to_jsonable
from .version import SemVer


class ScenarioType(str, Enum):
    AAF = "AGI_ABRUPT_FAILURE"
    ECC = "EXTRATERRESTRIAL_CIVILIZATION_CONTACT"
    EC = "EXISTENTIAL_CATASTROPHE"
    CTB = "CIVILIZATIONAL_TECHNOLOGY_BREAKTHROUGH"


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    scenario_type: ScenarioType
    version: SemVer
    seed: int
    parameters: Mapping[str, Any]
    source: SourceRef

    def __post_init__(self) -> None:
        if not self.scenario_id.strip():
            raise ValueError("scenario_id is required")
        if not isinstance(self.version, SemVer):
            raise TypeError("scenario version must be a SemVer")
        if not self.parameters:
            raise ValueError("scenario parameters are required")
        if not isinstance(self.seed, int):
            raise TypeError("scenario seed must be an integer")


@dataclass(frozen=True)
class TaskQualityCheck:
    check_id: str
    passed: bool
    detail: str

    def __post_init__(self) -> None:
        if not self.check_id.strip():
            raise ValueError("quality check_id is required")
        if not self.detail.strip():
            raise ValueError("quality check detail is required")


@dataclass(frozen=True)
class TaskQualityReport:
    scenario_id: str
    policy_version: str
    checks: tuple[TaskQualityCheck, ...]

    def __post_init__(self) -> None:
        if not self.scenario_id.strip():
            raise ValueError("quality report scenario_id is required")
        SemVer.parse(self.policy_version)
        if not self.checks:
            raise ValueError("quality report requires at least one check")

    @property
    def passed(self) -> bool:
        return bool(self.checks) and all(check.passed for check in self.checks)


@dataclass(frozen=True)
class TaskQualityPolicy:
    policy_version: str = "1.0.0"
    require_metrics: bool = True
    require_failure_modes_on_failure: bool = True
    require_reproducibility_trace: bool = True

    def __post_init__(self) -> None:
        SemVer.parse(self.policy_version)


class ScenarioQualityError(ValueError):
    def __init__(self, report: TaskQualityReport) -> None:
        failed = ", ".join(
            check.check_id for check in report.checks if not check.passed
        )
        super().__init__(
            f"scenario {report.scenario_id} failed task-quality checks: {failed}"
        )
        self.report = report


@dataclass(frozen=True)
class ScenarioResult:
    scenario_id: str
    scenario_type: ScenarioType
    seed: int
    passed: bool
    findings: tuple[str, ...]
    failure_modes: tuple[str, ...]
    metrics: Mapping[str, float]
    quality: TaskQualityReport
    trace: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


Evaluator = Callable[[Scenario, random.Random], Mapping[str, Any]]


def _string_tuple(value: Any, label: str) -> tuple[str, ...]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
        raise TypeError(f"scenario {label} must be an iterable of strings")
    return tuple(str(item) for item in value)


class StressTestEngine:
    def __init__(self, policy: TaskQualityPolicy | None = None) -> None:
        self.policy = policy or TaskQualityPolicy()

    def run(self, scenario: Scenario, evaluator: Evaluator) -> ScenarioResult:
        rng = random.Random(scenario.seed)
        raw = evaluator(scenario, rng)
        if not isinstance(raw, Mapping):
            raise TypeError("scenario evaluator must return a mapping")
        passed_value = raw.get("passed")
        passed_is_explicit = isinstance(passed_value, bool)
        passed = passed_value if passed_is_explicit else False

        raw_metrics = raw.get("metrics", {})
        if not isinstance(raw_metrics, Mapping):
            raise TypeError("scenario metrics must be a mapping")
        metrics = {str(key): float(value) for key, value in raw_metrics.items()}
        if any(not isfinite(value) for value in metrics.values()):
            raise ValueError("scenario metrics must be finite")

        findings = _string_tuple(raw.get("findings", ()), "findings")
        failure_modes = _string_tuple(raw.get("failure_modes", ()), "failure_modes")
        findings_are_nonblank = all(item.strip() for item in findings)
        failure_modes_are_nonblank = all(item.strip() for item in failure_modes)

        raw_trace = raw.get("trace", {})
        if not isinstance(raw_trace, Mapping):
            raise TypeError("scenario trace must be a mapping")
        reproducibility_trace = {
            "scenario_id": scenario.scenario_id,
            "scenario_type": scenario.scenario_type.value,
            "scenario_version": str(scenario.version),
            "seed": scenario.seed,
            "scenario_parameters": to_jsonable(scenario.parameters),
        }
        overridden = set(raw_trace) & set(reproducibility_trace)
        if overridden:
            raise ValueError(
                f"scenario trace cannot override reserved keys: {sorted(overridden)}"
            )
        trace = {**reproducibility_trace, **dict(raw_trace)}

        checks = (
            TaskQualityCheck(
                "explicit_pass_status",
                passed_is_explicit,
                "passed must be an explicit Boolean",
            ),
            TaskQualityCheck(
                "finite_metrics",
                bool(metrics) or not self.policy.require_metrics,
                "at least one finite metric is required",
            ),
            TaskQualityCheck(
                "failure_attribution",
                bool(passed)
                or bool(failure_modes)
                or not self.policy.require_failure_modes_on_failure,
                "a failed scenario must identify at least one failure mode",
            ),
            TaskQualityCheck(
                "reproducibility_trace",
                bool(trace) or not self.policy.require_reproducibility_trace,
                "scenario identity, version, seed and parameters must be traced",
            ),
            TaskQualityCheck(
                "nonblank_findings",
                findings_are_nonblank and failure_modes_are_nonblank,
                "findings and failure modes must not contain blank strings",
            ),
        )
        quality = TaskQualityReport(
            scenario_id=scenario.scenario_id,
            policy_version=self.policy.policy_version,
            checks=checks,
        )
        if not quality.passed:
            raise ScenarioQualityError(quality)

        return ScenarioResult(
            scenario_id=scenario.scenario_id,
            scenario_type=scenario.scenario_type,
            seed=scenario.seed,
            passed=passed,
            findings=findings,
            failure_modes=failure_modes,
            metrics=metrics,
            quality=quality,
            trace=trace,
        )

    def run_suite(
        self,
        scenarios: list[Scenario],
        evaluator: Evaluator,
    ) -> tuple[ScenarioResult, ...]:
        return tuple(self.run(scenario, evaluator) for scenario in scenarios)


class ScenarioRegistry:
    def __init__(self) -> None:
        self._scenarios: dict[str, Scenario] = {}

    def add(self, scenario: Scenario) -> None:
        if scenario.scenario_id in self._scenarios:
            raise ValueError(f"duplicate scenario: {scenario.scenario_id}")
        self._scenarios[scenario.scenario_id] = scenario

    def get(self, scenario_id: str) -> Scenario:
        try:
            return self._scenarios[scenario_id]
        except KeyError as exc:
            raise KeyError(f"unknown scenario: {scenario_id}") from exc

    def list(self) -> tuple[Scenario, ...]:
        return tuple(self._scenarios.values())


def standard_scenarios() -> ScenarioRegistry:
    """Return minimum deterministic harnesses, not empirical predictions."""

    registry = ScenarioRegistry()
    templates = (
        (
            "aaf-baseline",
            ScenarioType.AAF,
            2027001,
            {
                "capability_jump": 0.8,
                "detection_latency_days": 30,
                "reversibility": 0.4,
            },
            SourceRef(5, "2"),
        ),
        (
            "ecc-baseline",
            ScenarioType.ECC,
            2027002,
            {
                "signal_confidence": 0.75,
                "contact_distance_ly": 50.0,
                "institutional_readiness": 0.6,
            },
            SourceRef(5, "3"),
        ),
        (
            "ec-baseline",
            ScenarioType.EC,
            2027003,
            {
                "time_to_impact_hours": 72,
                "population_exposure": 0.7,
                "reversibility": 0.3,
            },
            SourceRef(5, "4"),
        ),
        (
            "ctb-baseline",
            ScenarioType.CTB,
            2027004,
            {
                "adoption_rate": 0.6,
                "oversight_capacity": 0.5,
                "irreversibility": 0.5,
            },
            SourceRef(5, "5"),
        ),
    )
    for scenario_id, scenario_type, seed, parameters, source in templates:
        registry.add(
            Scenario(
                scenario_id=scenario_id,
                scenario_type=scenario_type,
                version=SemVer.parse("2.0.0"),
                seed=seed,
                parameters=parameters,
                source=source,
            )
        )
    return registry
