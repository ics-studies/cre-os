from __future__ import annotations

import argparse
from typing import Any

import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from . import __version__
from .crcsp import (
    CandidateAction,
    ConstraintOperator,
    ConstraintRule,
    ContextKind,
    Decision,
    RedlineFinding,
)
from .models import MetricResult, SourceRef, UncertaintyInterval
from .ndss import NDSS


class SourceRefRequest(BaseModel):
    volume: int = Field(ge=0)
    chapter: str = Field(min_length=1)
    section: str | None = None
    locator: str | None = None
    version: str | None = "2.0.0"
    ruling: str | None = None
    work: str = "ICS-2027"


class RedlineFindingRequest(BaseModel):
    redline_id: str
    evidence_ids: list[str] = Field(min_length=1)
    rationale: str = Field(min_length=1)
    condition_evidence: dict[str, list[str]] = Field(default_factory=dict)


class ActionRequest(BaseModel):
    action_id: str
    principle_scores: dict[str, float]
    redline_findings: list[RedlineFindingRequest] = Field(default_factory=list)
    evidence_gaps: list[str] = Field(default_factory=list)
    attributes: dict[str, Any] = Field(default_factory=dict)


class MetricRequest(BaseModel):
    metric: str
    metric_version: str
    dimensions: dict[str, float]
    score: float | None = None
    sources: list[SourceRefRequest] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    claim_boundary: str = ""
    status: str = "calculated"
    uncertainty_kind: str = "unspecified"
    interval: dict[str, float] | None = None
    possible_levels: list[int] = Field(default_factory=list)


class ConstraintRequest(BaseModel):
    constraint_id: str
    field: str
    operator: ConstraintOperator
    expected: Any = None
    effect: Decision = Decision.DEFER
    rationale: str
    sources: list[SourceRefRequest] = Field(default_factory=list)
    evidence_field: str | None = None
    required_evidence: list[str] = Field(default_factory=list)


class DecisionRequest(BaseModel):
    actions: list[ActionRequest] = Field(min_length=1)
    metrics: list[MetricRequest] = Field(min_length=1)
    context: ContextKind = ContextKind.ROUTINE
    escalate_on_evidence_gap: bool = False
    constraints: list[ConstraintRequest] = Field(default_factory=list)


app = FastAPI(
    title="CRE-OS local decision-support API",
    version=__version__,
    description=(
        "Local research API for NDSS decision-support reports. It does not "
        "replace institutional judgment."
    ),
)


def _source(source: SourceRefRequest) -> SourceRef:
    return SourceRef(**source.model_dump())


def _action(action: ActionRequest) -> CandidateAction:
    return CandidateAction(
        action_id=action.action_id,
        principle_scores=action.principle_scores,
        redline_findings=tuple(
            RedlineFinding(
                finding.redline_id,
                tuple(finding.evidence_ids),
                finding.rationale,
                {
                    key: tuple(values)
                    for key, values in finding.condition_evidence.items()
                },
            )
            for finding in action.redline_findings
        ),
        evidence_gaps=tuple(action.evidence_gaps),
        attributes=action.attributes,
    )


def _metric(metric: MetricRequest) -> MetricResult:
    interval = (
        UncertaintyInterval(
            lower=float(metric.interval["lower"]),
            upper=float(metric.interval["upper"]),
        )
        if metric.interval is not None
        else None
    )
    return MetricResult(
        metric=metric.metric,
        metric_version=metric.metric_version,
        dimensions=metric.dimensions,
        score=metric.score,
        interval=interval,
        sources=tuple(_source(source) for source in metric.sources),
        warnings=tuple(metric.warnings),
        claim_boundary=metric.claim_boundary,
        status=metric.status,
        uncertainty_kind=metric.uncertainty_kind,
        possible_levels=tuple(metric.possible_levels),
    )


def _constraint(constraint: ConstraintRequest) -> ConstraintRule:
    return ConstraintRule(
        constraint_id=constraint.constraint_id,
        field=constraint.field,
        operator=constraint.operator,
        expected=constraint.expected,
        effect=constraint.effect,
        rationale=constraint.rationale,
        sources=tuple(_source(source) for source in constraint.sources),
        evidence_field=constraint.evidence_field,
        required_evidence=tuple(constraint.required_evidence),
    )


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "version": __version__}


@app.post("/v1/decisions")
def create_decision(request: DecisionRequest) -> dict[str, Any]:
    try:
        report = NDSS().assess(
            [_action(action) for action in request.actions],
            [_metric(metric) for metric in request.metrics],
            context=request.context,
            escalate_on_evidence_gap=request.escalate_on_evidence_gap,
            constraints=[_constraint(rule) for rule in request.constraints],
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return report.to_dict()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="ics-cre-os-api")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8787)
    args = parser.parse_args(argv)
    if args.host not in {"127.0.0.1", "localhost", "::1"}:
        parser.error("local research API only supports loopback hosts")
    uvicorn.run(app, host=args.host, port=args.port)
    return 0
