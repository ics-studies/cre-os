from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from .models import SourceRef
from .registry import FRLS, principle_order
from .serialization import to_jsonable


class ContextKind(str, Enum):
    ROUTINE = "routine"
    DEEP_UNCERTAINTY = "deep_uncertainty"
    EXISTENTIAL = "existential"
    EMERGENCY = "emergency"


class Decision(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    DEFER = "defer"
    ESCALATE = "escalate"


class ConstraintKind(str, Enum):
    REDLINE = "redline"
    EVIDENCE_GAP = "evidence_gap"
    ATTRIBUTE = "attribute"


class ConstraintOperator(str, Enum):
    EXISTS = "exists"
    NOT_EXISTS = "not_exists"
    EQUALS = "equals"
    NOT_EQUALS = "not_equals"
    LESS_THAN = "less_than"
    LESS_OR_EQUAL = "less_or_equal"
    GREATER_THAN = "greater_than"
    GREATER_OR_EQUAL = "greater_or_equal"
    IN = "in"
    NOT_IN = "not_in"
    CONTAINS_ANY = "contains_any"
    CONTAINS_ALL = "contains_all"


class ConstraintOutcome(str, Enum):
    SATISFIED = "satisfied"
    VIOLATED = "violated"
    UNRESOLVED = "unresolved"


@dataclass(frozen=True)
class RedlineFinding:
    redline_id: str
    evidence_ids: tuple[str, ...]
    rationale: str
    condition_evidence: Mapping[str, tuple[str, ...]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.redline_id not in FRLS:
            raise ValueError(f"unknown redline identifier: {self.redline_id}")
        if not self.evidence_ids:
            raise ValueError("a redline finding requires evidence")
        normalized = {
            str(key): tuple(str(value) for value in values)
            for key, values in self.condition_evidence.items()
        }
        object.__setattr__(self, "condition_evidence", normalized)
        if not self.rationale.strip():
            raise ValueError("a redline finding requires a rationale")
        if self.redline_id == "FRL-5":
            required = set(FRLS["FRL-5"].subconditions)
            provided = set(normalized)
            if provided != required:
                raise ValueError(
                    f"FRL-5 requires evidence for each subcondition: {sorted(required)}"
                )
            if any(not values for values in normalized.values()):
                raise ValueError("FRL-5 subcondition evidence cannot be empty")

    @property
    def all_evidence_ids(self) -> tuple[str, ...]:
        return tuple(
            dict.fromkeys(
                (
                    *self.evidence_ids,
                    *(
                        evidence_id
                        for values in self.condition_evidence.values()
                        for evidence_id in values
                    ),
                )
            )
        )


@dataclass(frozen=True)
class ConstraintProof:
    """A machine-readable reason for an exclude, defer, or escalation step."""

    constraint_id: str
    kind: ConstraintKind
    decision: Decision
    rationale: str
    evidence_ids: tuple[str, ...] = ()
    missing_evidence: tuple[str, ...] = ()
    sources: tuple[SourceRef, ...] = ()

    def __post_init__(self) -> None:
        if not self.constraint_id.strip():
            raise ValueError("constraint_id is required")
        if not self.rationale.strip():
            raise ValueError("constraint rationale is required")
        if self.kind == ConstraintKind.REDLINE and not self.evidence_ids:
            raise ValueError("redline proofs require evidence IDs")
        if self.kind == ConstraintKind.EVIDENCE_GAP and not self.missing_evidence:
            raise ValueError("evidence-gap proofs require missing evidence")

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


@dataclass(frozen=True)
class RankingProof:
    action_id: str
    rank: int
    ordered_scores: tuple[tuple[str, float], ...]

    def __post_init__(self) -> None:
        if not self.action_id.strip():
            raise ValueError("action_id is required")
        if self.rank < 1:
            raise ValueError("rank must be positive")
        if not self.ordered_scores:
            raise ValueError("ordered_scores are required")

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


@dataclass(frozen=True)
class ConstraintEvaluation:
    action_id: str
    constraint_id: str
    field: str
    operator: ConstraintOperator
    outcome: ConstraintOutcome
    effect: Decision
    rationale: str
    evidence_ids: tuple[str, ...] = ()
    required_evidence: tuple[str, ...] = ()
    sources: tuple[SourceRef, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)

    def to_proof(self) -> ConstraintProof | None:
        if self.outcome == ConstraintOutcome.SATISFIED:
            return None
        missing = (
            (f"field unavailable: {self.field}",)
            if self.outcome == ConstraintOutcome.UNRESOLVED
            else self.required_evidence
        )
        return ConstraintProof(
            constraint_id=self.constraint_id,
            kind=ConstraintKind.ATTRIBUTE,
            decision=self.effect,
            rationale=f"{self.outcome.value}: {self.rationale}",
            evidence_ids=self.evidence_ids,
            missing_evidence=missing,
            sources=self.sources,
        )


@dataclass(frozen=True)
class ConstraintRule:
    constraint_id: str
    field: str
    operator: ConstraintOperator
    expected: Any
    effect: Decision
    rationale: str
    sources: tuple[SourceRef, ...]
    evidence_field: str | None = None
    required_evidence: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.constraint_id.strip():
            raise ValueError("constraint_id is required")
        if not self.field.strip():
            raise ValueError("constraint field is required")
        if self.effect == Decision.ALLOW:
            raise ValueError("constraint effect cannot be allow")
        if not self.rationale.strip():
            raise ValueError("constraint rationale is required")
        if not self.sources:
            raise ValueError("constraint rules require at least one source")
        if (
            self.operator
            not in {
                ConstraintOperator.EXISTS,
                ConstraintOperator.NOT_EXISTS,
            }
            and self.expected is None
        ):
            raise ValueError(f"{self.operator.value} requires an expected value")

    def evaluate(self, action: CandidateAction) -> ConstraintEvaluation:
        value, present = _resolve_action_field(action, self.field)
        outcome = self._compare(value, present)
        evidence_ids = (
            _resolve_evidence_ids(action, self.evidence_field)
            if self.evidence_field
            else ()
        )
        return ConstraintEvaluation(
            action_id=action.action_id,
            constraint_id=self.constraint_id,
            field=self.field,
            operator=self.operator,
            outcome=outcome,
            effect=self.effect,
            rationale=self.rationale,
            evidence_ids=evidence_ids,
            required_evidence=self.required_evidence,
            sources=self.sources,
        )

    def _compare(self, value: Any, present: bool) -> ConstraintOutcome:
        if self.operator == ConstraintOperator.EXISTS:
            return (
                ConstraintOutcome.SATISFIED
                if present and value is not None
                else ConstraintOutcome.VIOLATED
            )
        if self.operator == ConstraintOperator.NOT_EXISTS:
            return (
                ConstraintOutcome.VIOLATED
                if present and value is not None
                else ConstraintOutcome.SATISFIED
            )
        if not present:
            return ConstraintOutcome.UNRESOLVED
        try:
            if self.operator == ConstraintOperator.EQUALS:
                matched = value == self.expected
            elif self.operator == ConstraintOperator.NOT_EQUALS:
                matched = value != self.expected
            elif self.operator == ConstraintOperator.LESS_THAN:
                matched = float(value) < float(self.expected)
            elif self.operator == ConstraintOperator.LESS_OR_EQUAL:
                matched = float(value) <= float(self.expected)
            elif self.operator == ConstraintOperator.GREATER_THAN:
                matched = float(value) > float(self.expected)
            elif self.operator == ConstraintOperator.GREATER_OR_EQUAL:
                matched = float(value) >= float(self.expected)
            elif self.operator == ConstraintOperator.IN:
                matched = value in _iterable_expected(self.expected)
            elif self.operator == ConstraintOperator.NOT_IN:
                matched = value not in _iterable_expected(self.expected)
            elif self.operator == ConstraintOperator.CONTAINS_ANY:
                actual = set(_iterable_actual(value))
                matched = bool(actual.intersection(_iterable_expected(self.expected)))
            elif self.operator == ConstraintOperator.CONTAINS_ALL:
                actual = set(_iterable_actual(value))
                matched = set(_iterable_expected(self.expected)).issubset(actual)
            else:  # pragma: no cover - enum validation prevents this
                return ConstraintOutcome.UNRESOLVED
        except (TypeError, ValueError):
            return ConstraintOutcome.UNRESOLVED
        return ConstraintOutcome.SATISFIED if matched else ConstraintOutcome.VIOLATED


def _resolve_action_field(
    action: CandidateAction,
    path: str,
) -> tuple[Any, bool]:
    if path == "action_id":
        return action.action_id, True
    if path == "redline_ids":
        return tuple(finding.redline_id for finding in action.redline_findings), True
    if path == "evidence_gap_count":
        return len(action.evidence_gaps), True
    if path.startswith("principle_scores."):
        key = path.removeprefix("principle_scores.")
        return action.principle_scores.get(key), key in action.principle_scores
    if path.startswith("attributes."):
        key = path.removeprefix("attributes.")
        return action.attributes.get(key), key in action.attributes
    return None, False


def _resolve_evidence_ids(
    action: CandidateAction,
    field: str | None,
) -> tuple[str, ...]:
    if not field:
        return ()
    value, present = _resolve_action_field(action, field)
    if not present or value is None:
        return ()
    if isinstance(value, str):
        return (value,)
    if isinstance(value, Iterable):
        return tuple(str(item) for item in value)
    raise TypeError(f"evidence field must resolve to a string or iterable: {field}")


def _iterable_expected(value: Any) -> tuple[Any, ...]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
        raise TypeError("expected value must be an iterable")
    return tuple(value)


def _iterable_actual(value: Any) -> tuple[Any, ...]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
        raise TypeError("actual value must be an iterable")
    return tuple(value)


def _decision_from_proofs(proofs: list[ConstraintProof]) -> Decision:
    decisions = {proof.decision for proof in proofs}
    if Decision.DENY in decisions:
        return Decision.DENY
    if Decision.ESCALATE in decisions:
        return Decision.ESCALATE
    return Decision.DEFER


@dataclass(frozen=True)
class CandidateAction:
    action_id: str
    principle_scores: dict[str, float]
    redline_findings: tuple[RedlineFinding, ...] = ()
    evidence_gaps: tuple[str, ...] = ()
    attributes: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.action_id.strip():
            raise ValueError("action_id is required")
        if set(self.principle_scores) != {"RFP", "NRP", "REV"}:
            raise ValueError("principle_scores must contain RFP, NRP and REV")
        for name, value in self.principle_scores.items():
            if not 0.0 <= float(value) <= 1.0:
                raise ValueError(f"{name} score must be in [0,1]")
        object.__setattr__(self, "attributes", dict(self.attributes))


@dataclass(frozen=True)
class ExcludedAction:
    action_id: str
    decision: Decision
    reasons: tuple[str, ...]
    proof: tuple[ConstraintProof, ...] = ()

    def __post_init__(self) -> None:
        if self.decision == Decision.ALLOW:
            raise ValueError("an excluded action cannot be allowed")
        if not self.reasons:
            raise ValueError("an excluded action requires reasons")
        if not self.proof:
            raise ValueError("an excluded action requires machine-readable proof")


@dataclass(frozen=True)
class CRCSPSolution:
    decision: Decision
    selected: str | None
    ranking: tuple[str, ...]
    priority: tuple[str, ...]
    excluded: tuple[ExcludedAction, ...]
    explanations: tuple[str, ...]
    ranking_proof: tuple[RankingProof, ...] = ()
    constraint_evaluations: tuple[ConstraintEvaluation, ...] = ()
    sources: tuple[SourceRef, ...] = (
        SourceRef(1, "9", "9.8"),
        SourceRef(1, "10", "10.5"),
        SourceRef(2, "21"),
    )

    def __post_init__(self) -> None:
        if len(self.excluded) != len({item.action_id for item in self.excluded}):
            raise ValueError("excluded action IDs must be unique")
        if len(self.ranking) != len(set(self.ranking)):
            raise ValueError("ranking action IDs must be unique")
        proof_order = tuple(item.action_id for item in self.ranking_proof)
        if proof_order != self.ranking:
            raise ValueError("ranking_proof must match ranking")
        if self.decision == Decision.ALLOW:
            if self.selected is None or self.ranking[0] != self.selected:
                raise ValueError(
                    "an allowed decision must select the top-ranked action"
                )
        elif self.selected is not None:
            raise ValueError("only an allowed decision may select an action")

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


class CRCSPSolver:
    """Finite-action reference solver for the lexical CRE decision rule."""

    def solve(
        self,
        actions: list[CandidateAction],
        context: ContextKind = ContextKind.ROUTINE,
        *,
        escalate_on_evidence_gap: bool = False,
        constraints: list[ConstraintRule] | None = None,
    ) -> CRCSPSolution:
        if not actions:
            raise ValueError("at least one candidate action is required")
        ids = [action.action_id for action in actions]
        if len(ids) != len(set(ids)):
            raise ValueError("action_id values must be unique")
        active_constraints = list(constraints or ())
        constraint_ids = [rule.constraint_id for rule in active_constraints]
        if len(constraint_ids) != len(set(constraint_ids)):
            raise ValueError("constraint_id values must be unique")

        priority = principle_order(
            deep_uncertainty=context == ContextKind.DEEP_UNCERTAINTY,
            emergency=context in {ContextKind.EXISTENTIAL, ContextKind.EMERGENCY},
        )
        excluded: list[ExcludedAction] = []
        feasible: list[CandidateAction] = []
        constraint_evaluations: list[ConstraintEvaluation] = []
        for action in actions:
            proofs: list[ConstraintProof] = []
            reasons: list[str] = []
            if action.redline_findings:
                redline_proofs = [
                    ConstraintProof(
                        constraint_id=finding.redline_id,
                        kind=ConstraintKind.REDLINE,
                        decision=Decision.DENY,
                        rationale=(
                            f"{FRLS[finding.redline_id].statement}; {finding.rationale}"
                        ),
                        evidence_ids=finding.all_evidence_ids,
                        sources=(FRLS[finding.redline_id].source,),
                    )
                    for finding in action.redline_findings
                ]
                proofs.extend(redline_proofs)
                reasons.extend(
                    (
                        f"hard redline {finding.redline_id}: "
                        f"{FRLS[finding.redline_id].statement}; "
                        f"{finding.rationale}; "
                        f"evidence_ids={','.join(finding.all_evidence_ids)}"
                    )
                    for finding in action.redline_findings
                )
            if action.evidence_gaps:
                decision = (
                    Decision.ESCALATE if escalate_on_evidence_gap else Decision.DEFER
                )
                gap_proofs = [
                    ConstraintProof(
                        constraint_id="EVIDENCE_GAP",
                        kind=ConstraintKind.EVIDENCE_GAP,
                        decision=decision,
                        rationale="Required discharging evidence was not supplied.",
                        missing_evidence=(gap,),
                        sources=(SourceRef(2, "21"),),
                    )
                    for gap in action.evidence_gaps
                ]
                proofs.extend(gap_proofs)
                reasons.extend(f"evidence gap: {gap}" for gap in action.evidence_gaps)
            for rule in active_constraints:
                evaluation = rule.evaluate(action)
                constraint_evaluations.append(evaluation)
                proof = evaluation.to_proof()
                if proof is not None:
                    proofs.append(proof)
                    reasons.append(
                        f"{rule.constraint_id} {proof.decision.value}: {proof.rationale}"
                    )
            if proofs:
                excluded.append(
                    ExcludedAction(
                        action.action_id,
                        _decision_from_proofs(proofs),
                        tuple(reasons),
                        tuple(proofs),
                    )
                )
                continue
            feasible.append(action)

        ranked = sorted(
            feasible,
            key=lambda action: tuple(
                -action.principle_scores[name] for name in priority
            ),
        )
        ranking = tuple(action.action_id for action in ranked)
        ranking_proof = tuple(
            RankingProof(
                action_id=action.action_id,
                rank=index,
                ordered_scores=tuple(
                    (name, float(action.principle_scores[name])) for name in priority
                ),
            )
            for index, action in enumerate(ranked, start=1)
        )
        if not ranked:
            decisions = {item.decision for item in excluded}
            if Decision.ESCALATE in decisions:
                decision = Decision.ESCALATE
            elif Decision.DEFER in decisions:
                decision = Decision.DEFER
            else:
                decision = Decision.DENY
            return CRCSPSolution(
                decision=decision,
                selected=None,
                ranking=(),
                priority=priority,
                excluded=tuple(excluded),
                explanations=("No candidate remains after hard constraints.",),
                ranking_proof=(),
                constraint_evaluations=tuple(constraint_evaluations),
            )

        selected = ranked[0]
        return CRCSPSolution(
            decision=Decision.ALLOW,
            selected=selected.action_id,
            ranking=ranking,
            priority=priority,
            excluded=tuple(excluded),
            explanations=(
                f"Context={context.value}",
                "Priority order=" + " > ".join(priority),
                "Selected action=" + selected.action_id,
            ),
            ranking_proof=ranking_proof,
            constraint_evaluations=tuple(constraint_evaluations),
        )
