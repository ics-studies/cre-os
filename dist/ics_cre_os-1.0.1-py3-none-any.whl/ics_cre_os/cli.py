from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from . import __version__
from .calibration import (
    CalibrationCase,
    CalibrationOrigin,
    CalibrationPolicy,
    evaluate_calibration,
)
from .crcsp import (
    CandidateAction,
    ConstraintOperator,
    ConstraintRule,
    ContextKind,
    Decision,
    RedlineFinding,
)
from .evidence_assessment import DimensionAssessment, MetricEvidenceAssessment
from .measurement import MeasurementRequest, measure
from .metrics import (
    MBCLAssessment,
    evaluate_cdi,
    evaluate_crv,
    evaluate_csia,
    evaluate_mbcl,
    evaluate_rfd_capacity,
    evaluate_ucs_research_score,
    evaluate_ucs_structured,
    rfd_delta,
)
from .models import (
    EvidenceGrade,
    EvidenceRecord,
    EvidenceSpan,
    MetricResult,
    SourceRef,
    UncertaintyInterval,
)
from .ndss import NDSS
from .platform import evaluate_platform_status
from .serialization import to_json
from .uncertainty import (
    ScenarioValue,
    UncertaintyEnvelope,
    UncertaintyKind,
)
from .version import SemVer


def _load_json(path: str) -> dict[str, Any]:
    raw = sys.stdin.read() if path == "-" else Path(path).read_text(encoding="utf-8")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise TypeError("input JSON must be an object")
    return value


def _evaluate(metric: str, payload: dict[str, Any]) -> Any:
    if metric == "ucs":
        if payload.get("research", False):
            return evaluate_ucs_research_score(
                payload["dimensions"],
                payload.get("weights"),
            )
        return evaluate_ucs_structured(payload["dimensions"])
    if metric == "rfd":
        if "before" in payload or "after" in payload:
            return {"delta_rfd": rfd_delta(payload["before"], payload["after"])}
        return evaluate_rfd_capacity(payload["dimensions"], payload["operators"])
    if metric == "crv":
        return evaluate_crv(
            payload["observability"],
            payload["enforceability"],
            payload["reversibility"],
            payload.get("observability_weights"),
            payload.get("reversibility_weights"),
        )
    if metric == "cdi":
        return evaluate_cdi(payload["dimensions"], payload.get("weights"))
    if metric == "mbcl":
        return evaluate_mbcl(MBCLAssessment(**payload))
    if metric == "csia":
        return evaluate_csia(payload["dimensions"], payload.get("weights"))
    raise ValueError(f"unknown metric: {metric}")


def _interval(payload: dict[str, Any]) -> UncertaintyInterval:
    return UncertaintyInterval(
        lower=float(payload["lower"]),
        upper=float(payload["upper"]),
    )


def _uncertainty(payload: dict[str, Any]) -> UncertaintyEnvelope:
    raw_interval = payload.get("interval")
    return UncertaintyEnvelope(
        kind=UncertaintyKind(str(payload["kind"])),
        point=(float(payload["point"]) if payload.get("point") is not None else None),
        interval=(_interval(raw_interval) if isinstance(raw_interval, dict) else None),
        samples=tuple(float(value) for value in payload.get("samples", ())),
        ambiguity=float(payload.get("ambiguity", 0.0)),
        scenarios=tuple(
            ScenarioValue(
                scenario_id=str(item["scenario_id"]),
                value=float(item["value"]),
                description=str(item.get("description", "")),
            )
            for item in payload.get("scenarios", ())
        ),
        unidentified_possibility=bool(payload.get("unidentified_possibility", False)),
        rationale=str(payload["rationale"]),
        sources=tuple(SourceRef(**source) for source in payload.get("sources", ())),
    )


def _measurement_request(payload: dict[str, Any]) -> MeasurementRequest:
    items = {}
    for key, raw in dict(payload["items"]).items():
        raw_uncertainty = raw.get("uncertainty")
        items[str(key)] = DimensionAssessment(
            key=str(key),
            value=raw.get("value"),
            evidence_ids=tuple(str(value) for value in raw.get("evidence_ids", ())),
            rubric_id=str(raw.get("rubric_id", "")),
            rationale=str(raw.get("rationale", "")),
            missing_evidence=tuple(
                str(value) for value in raw.get("missing_evidence", ())
            ),
            uncertainty=(
                _interval(raw_uncertainty)
                if isinstance(raw_uncertainty, dict)
                else None
            ),
        )
    evidence = tuple(
        EvidenceRecord(
            claim=str(raw["claim"]),
            grade=EvidenceGrade(str(raw.get("grade", "documented"))),
            spans=tuple(
                EvidenceSpan(
                    evidence_id=str(span["evidence_id"]),
                    source=SourceRef(**span["source"]),
                    locator=str(span["locator"]),
                    quote=(
                        str(span["quote"]) if span.get("quote") is not None else None
                    ),
                    sha256=(
                        str(span["sha256"]) if span.get("sha256") is not None else None
                    ),
                )
                for span in raw.get("spans", ())
            ),
            human_confirmed=bool(raw.get("human_confirmed", False)),
            notes=tuple(str(value) for value in raw.get("notes", ())),
        )
        for raw in payload.get("evidence", ())
    )
    assessment = MetricEvidenceAssessment(
        metric=str(payload["metric"]),
        items=items,
        reviewer_id=str(payload["reviewer_id"]),
        reviewed_at=datetime.fromisoformat(str(payload["reviewed_at"])),
        confirmed=bool(payload.get("confirmed", False)),
        metric_version=str(payload.get("metric_version", "2.0.0")),
    )
    return MeasurementRequest(
        assessment=assessment,
        evidence=evidence,
        dimension_uncertainty={
            str(key): _uncertainty(raw)
            for key, raw in dict(payload["uncertainty"]).items()
        },
        weights=dict(payload.get("weights", {})),
        research_mode=bool(payload.get("research_mode", False)),
    )


def _decision_brief(payload: dict[str, Any]) -> Any:
    actions = []
    for raw in payload.get("actions", ()):
        actions.append(
            CandidateAction(
                action_id=str(raw["action_id"]),
                principle_scores={
                    str(key): float(value)
                    for key, value in dict(raw["principle_scores"]).items()
                },
                redline_findings=tuple(
                    RedlineFinding(
                        redline_id=str(item["redline_id"]),
                        evidence_ids=tuple(
                            str(value) for value in item.get("evidence_ids", ())
                        ),
                        rationale=str(item["rationale"]),
                        condition_evidence={
                            str(key): tuple(str(value) for value in values)
                            for key, values in dict(
                                item.get("condition_evidence", {})
                            ).items()
                        },
                    )
                    for item in raw.get("redline_findings", ())
                ),
                evidence_gaps=tuple(
                    str(value) for value in raw.get("evidence_gaps", ())
                ),
                attributes=dict(raw.get("attributes", {})),
            )
        )
    constraints = [
        ConstraintRule(
            constraint_id=str(raw["constraint_id"]),
            field=str(raw["field"]),
            operator=ConstraintOperator(str(raw["operator"])),
            expected=raw.get("expected"),
            effect=Decision(str(raw.get("effect", Decision.DEFER.value))),
            rationale=str(raw["rationale"]),
            sources=tuple(SourceRef(**source) for source in raw.get("sources", ())),
            evidence_field=(
                str(raw["evidence_field"]) if raw.get("evidence_field") else None
            ),
            required_evidence=tuple(
                str(value) for value in raw.get("required_evidence", ())
            ),
        )
        for raw in payload.get("constraints", ())
    ]
    metrics = []
    for raw in payload.get("metrics", ()):
        raw_interval = raw.get("interval")
        metrics.append(
            MetricResult(
                metric=str(raw["metric"]),
                metric_version=str(raw["metric_version"]),
                dimensions={
                    str(key): float(value)
                    for key, value in dict(raw["dimensions"]).items()
                },
                score=float(raw["score"]) if raw.get("score") is not None else None,
                interval=(
                    UncertaintyInterval(
                        lower=float(raw_interval["lower"]),
                        upper=float(raw_interval["upper"]),
                    )
                    if isinstance(raw_interval, dict)
                    else None
                ),
                sources=tuple(SourceRef(**source) for source in raw.get("sources", ())),
                warnings=tuple(str(value) for value in raw.get("warnings", ())),
                claim_boundary=str(raw.get("claim_boundary", "")),
                status=str(raw.get("status", "calculated")),
                uncertainty_kind=str(raw.get("uncertainty_kind", "unspecified")),
                possible_levels=tuple(
                    int(value) for value in raw.get("possible_levels", ())
                ),
            )
        )
    return NDSS().assess(
        actions,
        metrics,
        context=ContextKind(str(payload.get("context", ContextKind.ROUTINE.value))),
        escalate_on_evidence_gap=bool(payload.get("escalate_on_evidence_gap", False)),
        constraints=constraints,
    )


def _calibration_report(payload: dict[str, Any]) -> Any:
    cases = []
    for raw in payload.get("cases", ()):
        cases.append(
            CalibrationCase(
                case_id=str(raw["case_id"]),
                metric=str(raw["metric"]),
                metric_version=str(raw["metric_version"]),
                input_sha256=str(raw["input_sha256"]),
                expected={
                    str(key): float(value)
                    for key, value in dict(raw["expected"]).items()
                },
                observed={
                    str(key): float(value)
                    for key, value in dict(raw["observed"]).items()
                },
                expected_status=str(raw.get("expected_status", "calculated")),
                observed_status=str(raw.get("observed_status", "calculated")),
                origin=CalibrationOrigin(
                    str(raw.get("origin", CalibrationOrigin.REAL_PUBLIC.value))
                ),
                reviewer_id=str(raw["reviewer_id"]),
                reviewed_at=datetime.fromisoformat(str(raw["reviewed_at"])),
                adjudication_ref=str(raw["adjudication_ref"]),
                source_refs=tuple(
                    SourceRef(**source) for source in raw.get("source_refs", ())
                ),
                human_overturned=bool(raw.get("human_overturned", False)),
            )
        )
    policy = CalibrationPolicy(**dict(payload.get("policy", {})))
    return evaluate_calibration(cases, policy)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="ics-cre-os")
    parser.add_argument("--version", action="version", version=__version__)
    commands = parser.add_subparsers(dest="command", required=True)

    check = commands.add_parser("check-version")
    check.add_argument("version")

    metric = commands.add_parser("metric")
    metric.add_argument("name", choices=["ucs", "rfd", "crv", "cdi", "mbcl", "csia"])
    metric.add_argument("--input", required=True, help="JSON file or '-' for stdin")

    measurement = commands.add_parser("measure")
    measurement.add_argument(
        "--input",
        required=True,
        help="Evidence-gated measurement JSON file or '-' for stdin",
    )

    decision = commands.add_parser("decide")
    decision.add_argument("--input", required=True, help="JSON file or '-' for stdin")

    calibration = commands.add_parser("calibration")
    calibration.add_argument(
        "--input",
        required=True,
        help="JSON file or '-' for stdin",
    )
    commands.add_parser("status")

    args = parser.parse_args(argv)
    try:
        if args.command == "check-version":
            parsed = SemVer.parse(args.version)
            print(parsed)
            return 0
        if args.command == "calibration":
            report = _calibration_report(_load_json(args.input))
            print(to_json(report.to_dict(), pretty=True))
            return 0 if report.passed else 1
        if args.command == "status":
            status = evaluate_platform_status()
            print(to_json(status.to_dict(), pretty=True))
            return 0 if status.structural_complete else 1
        if args.command == "decide":
            result = _decision_brief(_load_json(args.input))
        elif args.command == "measure":
            result = measure(_measurement_request(_load_json(args.input)))
        else:
            result = _evaluate(args.name, _load_json(args.input))
        print(to_json(result, pretty=True))
        return 0
    except (KeyError, TypeError, ValueError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
        return 2
