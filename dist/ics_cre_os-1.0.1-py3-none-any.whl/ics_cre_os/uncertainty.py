from __future__ import annotations

import math
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from enum import Enum
from itertools import pairwise, product
from typing import Any

from .models import SourceRef, UncertaintyInterval
from .serialization import to_jsonable


class UncertaintyKind(str, Enum):
    """The three uncertainty classes used by the fourth-volume UQ engine."""

    RISK = "risk"
    KNIGHTIAN = "knightian"
    DEEP = "deep"


@dataclass(frozen=True)
class ScenarioValue:
    scenario_id: str
    value: float
    description: str = ""

    def __post_init__(self) -> None:
        if not self.scenario_id.strip():
            raise ValueError("scenario_id is required")
        value = float(self.value)
        if not math.isfinite(value):
            raise ValueError("scenario value must be finite")
        object.__setattr__(self, "value", value)


@dataclass(frozen=True)
class UncertaintyEnvelope:
    """A source-linked uncertainty statement for one metric dimension.

    Risk envelopes may include samples or a confidence interval. Knightian
    envelopes require an interval and an ambiguity measure. Deep uncertainty
    requires an unknown-scenario flag or an explicit scenario set; it must not
    be silently converted into a probability distribution.
    """

    kind: UncertaintyKind
    point: float | None = None
    interval: UncertaintyInterval | None = None
    samples: tuple[float, ...] = ()
    ambiguity: float = 0.0
    scenarios: tuple[ScenarioValue, ...] = ()
    unidentified_possibility: bool = False
    rationale: str = ""
    sources: tuple[SourceRef, ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.kind, UncertaintyKind):
            object.__setattr__(self, "kind", UncertaintyKind(self.kind))
        object.__setattr__(
            self,
            "samples",
            tuple(float(value) for value in self.samples),
        )
        object.__setattr__(self, "scenarios", tuple(self.scenarios))
        object.__setattr__(self, "sources", tuple(self.sources))
        scenario_ids = [scenario.scenario_id for scenario in self.scenarios]
        if len(scenario_ids) != len(set(scenario_ids)):
            raise ValueError("scenario_id values must be unique")

        values = tuple(
            value
            for value in (
                self.point,
                *(value for value in self.samples),
                *(scenario.value for scenario in self.scenarios),
                *(
                    ()
                    if self.interval is None
                    else (self.interval.lower, self.interval.upper)
                ),
            )
            if value is not None
        )
        if any(not math.isfinite(float(value)) for value in values):
            raise ValueError("all uncertainty values must be finite")
        if not 0.0 <= self.ambiguity <= 1.0:
            raise ValueError("ambiguity must be in [0, 1]")
        if (
            self.point is not None
            and self.interval is not None
            and not self.interval.contains(self.point)
        ):
            raise ValueError("point estimate must lie inside its interval")
        if self.interval is not None and any(
            not self.interval.contains(value)
            for value in (
                *self.samples,
                *(scenario.value for scenario in self.scenarios),
            )
        ):
            raise ValueError("all samples and scenarios must lie inside the interval")
        if self.kind == UncertaintyKind.RISK:
            if self.interval is None and not self.samples:
                raise ValueError("risk uncertainty requires samples or an interval")
            if self.scenarios or self.unidentified_possibility:
                raise ValueError("risk uncertainty cannot carry deep scenarios")
        if self.kind == UncertaintyKind.KNIGHTIAN:
            if self.interval is None:
                raise ValueError(
                    "Knightian uncertainty requires a probability interval"
                )
            if self.samples:
                raise ValueError(
                    "Knightian uncertainty must not be represented by model samples"
                )
            if self.scenarios or self.unidentified_possibility:
                raise ValueError(
                    "Knightian uncertainty cannot carry deep-uncertainty scenarios"
                )
        if self.kind == UncertaintyKind.DEEP:
            if not self.scenarios and not self.unidentified_possibility:
                raise ValueError(
                    "deep uncertainty requires scenarios or an unidentified "
                    "possibility flag"
                )
            if self.samples:
                raise ValueError(
                    "deep uncertainty must not be reduced to probability samples"
                )
        if not self.rationale.strip():
            raise ValueError("uncertainty rationale is required")
        if not self.sources:
            raise ValueError("uncertainty statements require at least one source")

    def projected_interval(self) -> UncertaintyInterval:
        if self.interval is not None:
            return self.interval
        values = tuple(
            value
            for value in (
                *(value for value in self.samples),
                *(scenario.value for scenario in self.scenarios),
            )
        )
        if not values:
            raise ValueError("cannot project an interval from an empty uncertainty set")
        return UncertaintyInterval(min(values), max(values))

    def representative_value(self) -> float:
        if self.point is not None:
            return self.point
        interval = self.projected_interval()
        return interval.lower + (interval.upper - interval.lower) / 2.0

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


@dataclass(frozen=True)
class UncertaintyComponent:
    component_id: str
    label: str
    envelope: UncertaintyEnvelope

    def __post_init__(self) -> None:
        if not self.component_id.strip() or not self.label.strip():
            raise ValueError("uncertainty component id and label are required")


@dataclass(frozen=True)
class UncertaintyBudget:
    """An explicit and reviewable budget of uncertainty contributions."""

    components: tuple[UncertaintyComponent, ...] = field(default_factory=tuple)
    notes: tuple[str, ...] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        object.__setattr__(self, "components", tuple(self.components))
        object.__setattr__(self, "notes", tuple(self.notes))
        ids = [component.component_id for component in self.components]
        if len(ids) != len(set(ids)):
            raise ValueError("uncertainty component ids must be unique")

    @property
    def kind(self) -> UncertaintyKind:
        if any(
            component.envelope.kind == UncertaintyKind.DEEP
            for component in self.components
        ):
            return UncertaintyKind.DEEP
        if any(
            component.envelope.kind == UncertaintyKind.KNIGHTIAN
            for component in self.components
        ):
            return UncertaintyKind.KNIGHTIAN
        return UncertaintyKind.RISK

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


def _union_sources(
    envelopes: Sequence[UncertaintyEnvelope],
) -> tuple[SourceRef, ...]:
    unique: dict[tuple[Any, ...], SourceRef] = {}
    for envelope in envelopes:
        for source in envelope.sources:
            key = (
                source.work,
                source.volume,
                source.chapter,
                source.section,
                source.locator,
                source.version,
                source.ruling,
            )
            unique[key] = source
    return tuple(unique.values())


def _strongest_kind(kinds: Sequence[UncertaintyKind]) -> UncertaintyKind:
    if UncertaintyKind.DEEP in kinds:
        return UncertaintyKind.DEEP
    if UncertaintyKind.KNIGHTIAN in kinds:
        return UncertaintyKind.KNIGHTIAN
    return UncertaintyKind.RISK


def weighted_sum_envelope(
    terms: Mapping[str, UncertaintyEnvelope],
    weights: Mapping[str, float],
    *,
    rationale: str,
    sources: Sequence[SourceRef] = (),
) -> UncertaintyEnvelope:
    """Propagate a bounded weighted sum without inventing probability.

    The interval calculation is exact for a monotone weighted sum. Risk
    samples are projected to their observed range, Knightian values retain
    their interval, and deep uncertainty retains scenario boundaries.
    """

    missing = set(weights) - set(terms)
    extra = set(terms) - set(weights)
    if missing or extra:
        raise ValueError(
            f"uncertainty terms mismatch; missing={sorted(missing)}, "
            f"extra={sorted(extra)}"
        )
    normalized: dict[str, float] = {}
    for key, weight in weights.items():
        number = float(weight)
        if not math.isfinite(number) or number < 0.0:
            raise ValueError("uncertainty weights must be finite and non-negative")
        normalized[key] = number
    if not math.isclose(sum(normalized.values()), 1.0, abs_tol=1e-9):
        raise ValueError("uncertainty weights must sum to 1")

    envelopes = [terms[key] for key in weights]
    kind = _strongest_kind([envelope.kind for envelope in envelopes])
    intervals = {key: terms[key].projected_interval() for key in weights}
    lower = round(
        sum(normalized[key] * intervals[key].lower for key in weights),
        12,
    )
    upper = round(
        sum(normalized[key] * intervals[key].upper for key in weights),
        12,
    )
    representative = round(
        sum(normalized[key] * terms[key].representative_value() for key in weights),
        12,
    )
    combined_sources = _union_sources(envelopes)
    if sources:
        combined_sources = (*combined_sources, *tuple(sources))

    if kind == UncertaintyKind.DEEP:
        scenario_ids = [
            tuple(item.scenario_id for item in env.scenarios) for env in envelopes
        ]
        can_align = all(ids == scenario_ids[0] for ids in scenario_ids) and bool(
            scenario_ids[0]
        )
        scenario_values: tuple[ScenarioValue, ...] = ()
        if can_align:
            scenario_values = tuple(
                ScenarioValue(
                    scenario_id=scenario_id,
                    value=sum(
                        normalized[key]
                        * next(
                            item.value
                            for item in terms[key].scenarios
                            if item.scenario_id == scenario_id
                        )
                        for key in weights
                    ),
                    description="Propagated aligned scenario",
                )
                for scenario_id in scenario_ids[0]
            )
        return UncertaintyEnvelope(
            kind=kind,
            point=representative,
            interval=UncertaintyInterval(lower, upper),
            scenarios=scenario_values,
            unidentified_possibility=(
                any(envelope.unidentified_possibility for envelope in envelopes)
                or not can_align
            ),
            rationale=rationale,
            sources=combined_sources,
        )
    if kind == UncertaintyKind.KNIGHTIAN:
        return UncertaintyEnvelope(
            kind=kind,
            point=representative,
            interval=UncertaintyInterval(lower, upper),
            ambiguity=max(envelope.ambiguity for envelope in envelopes),
            rationale=rationale,
            sources=combined_sources,
        )
    return UncertaintyEnvelope(
        kind=kind,
        point=representative,
        interval=UncertaintyInterval(lower, upper),
        rationale=rationale,
        sources=combined_sources,
    )


def product_envelope(
    terms: Mapping[str, UncertaintyEnvelope],
    *,
    rationale: str,
) -> UncertaintyEnvelope:
    """Propagate a product when every bounded input is in [0, 1]."""

    if not terms:
        raise ValueError("at least one product term is required")
    envelopes = list(terms.values())
    intervals = [envelope.projected_interval() for envelope in envelopes]
    if any(interval.lower < 0.0 or interval.upper > 1.0 for interval in intervals):
        raise ValueError("product uncertainty inputs must lie in [0, 1]")
    lower = round(math.prod(interval.lower for interval in intervals), 12)
    upper = round(math.prod(interval.upper for interval in intervals), 12)
    representative = round(
        math.prod(envelope.representative_value() for envelope in envelopes),
        12,
    )
    kind = _strongest_kind([envelope.kind for envelope in envelopes])
    if kind == UncertaintyKind.DEEP:
        scenario_ids = [
            tuple(item.scenario_id for item in env.scenarios) for env in envelopes
        ]
        can_align = all(ids == scenario_ids[0] for ids in scenario_ids) and bool(
            scenario_ids[0]
        )
        scenario_values: tuple[ScenarioValue, ...] = ()
        if can_align:
            scenario_values = tuple(
                ScenarioValue(
                    scenario_id=scenario_id,
                    value=math.prod(
                        next(
                            item.value
                            for item in terms[key].scenarios
                            if item.scenario_id == scenario_id
                        )
                        for key in terms
                    ),
                    description="Propagated aligned scenario",
                )
                for scenario_id in scenario_ids[0]
            )
        return UncertaintyEnvelope(
            kind=kind,
            point=representative,
            interval=UncertaintyInterval(lower, upper),
            scenarios=scenario_values,
            unidentified_possibility=(
                any(envelope.unidentified_possibility for envelope in envelopes)
                or not can_align
            ),
            rationale=rationale,
            sources=_union_sources(envelopes),
        )
    if kind == UncertaintyKind.KNIGHTIAN:
        return UncertaintyEnvelope(
            kind=kind,
            point=representative,
            interval=UncertaintyInterval(lower, upper),
            ambiguity=max(envelope.ambiguity for envelope in envelopes),
            rationale=rationale,
            sources=_union_sources(envelopes),
        )
    return UncertaintyEnvelope(
        kind=kind,
        point=representative,
        interval=UncertaintyInterval(lower, upper),
        rationale=rationale,
        sources=_union_sources(envelopes),
    )


def enumerate_bounded_cases(
    inputs: Mapping[str, tuple[tuple[float, ...], UncertaintyEnvelope]],
    *,
    maximum_cases: int = 4096,
) -> tuple[dict[str, float], ...]:
    """Enumerate bounded cases for discrete metric gates.

    Each input supplies the values to evaluate. For risk and Knightian inputs
    the caller typically supplies lower, point and upper values. Deep
    uncertainty must supply explicit scenario values.
    """

    if maximum_cases < 1:
        raise ValueError("maximum_cases must be positive")
    names = tuple(inputs)
    counts = math.prod(len(inputs[name][0]) for name in names)
    if counts > maximum_cases:
        raise ValueError(
            f"bounded case set contains {counts} cases; limit is {maximum_cases}"
        )
    cases: list[dict[str, float]] = []
    for combination in product(*(inputs[name][0] for name in names)):
        cases.append(
            {name: float(value) for name, value in zip(names, combination, strict=True)}
        )
    return tuple(cases)


def levels_for_interval(
    interval: UncertaintyInterval,
    *,
    boundaries: Sequence[float] = (25.0, 50.0, 75.0),
) -> tuple[int, ...]:
    """Return every CSIA level touched by a 0-100 interval."""

    if not boundaries:
        raise ValueError("at least one level boundary is required")
    if any(left >= right for left, right in pairwise(boundaries)):
        raise ValueError("level boundaries must be strictly increasing")
    if interval.lower < 0.0 or interval.upper > 100.0:
        raise ValueError("CSIA level intervals must lie in [0, 100]")

    def level(value: float) -> int:
        result = 1
        for boundary in boundaries:
            if value < boundary:
                break
            result += 1
        return result

    first = level(interval.lower)
    last = level(interval.upper)
    return tuple(range(first, last + 1))


def combine_uncertainty_budget(
    budget: UncertaintyBudget,
) -> UncertaintyEnvelope | None:
    """Combine a budget into a conservative envelope.

    This function intentionally uses a union interval rather than a root-sum-
    square calculation unless every component is explicitly probabilistic.
    """

    if not budget.components:
        return None
    envelopes = tuple(component.envelope for component in budget.components)
    kind = _strongest_kind([envelope.kind for envelope in envelopes])
    lower = round(
        min(envelope.projected_interval().lower for envelope in envelopes),
        12,
    )
    upper = round(
        max(envelope.projected_interval().upper for envelope in envelopes),
        12,
    )
    point = round(lower + (upper - lower) / 2.0, 12)
    if kind == UncertaintyKind.DEEP:
        return UncertaintyEnvelope(
            kind=kind,
            point=point,
            interval=UncertaintyInterval(lower, upper),
            unidentified_possibility=True,
            rationale="Conservative union of the declared uncertainty budget.",
            sources=_union_sources(envelopes),
        )
    if kind == UncertaintyKind.KNIGHTIAN:
        return UncertaintyEnvelope(
            kind=kind,
            point=point,
            interval=UncertaintyInterval(lower, upper),
            ambiguity=max(envelope.ambiguity for envelope in envelopes),
            rationale="Conservative union of the declared uncertainty budget.",
            sources=_union_sources(envelopes),
        )
    return UncertaintyEnvelope(
        kind=kind,
        point=point,
        interval=UncertaintyInterval(lower, upper),
        rationale="Conservative union of the declared uncertainty budget.",
        sources=_union_sources(envelopes),
    )
