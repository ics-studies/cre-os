from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import Any

from .models import SourceRef
from .serialization import to_jsonable
from .version import SemVer


class CalibrationOrigin(str, Enum):
    REAL_PUBLIC = "real_public"
    REAL_PRIVATE = "real_private"
    SYNTHETIC = "synthetic"


@dataclass(frozen=True)
class CalibrationCase:
    case_id: str
    metric: str
    metric_version: str
    input_sha256: str
    expected: dict[str, float]
    observed: dict[str, float]
    expected_status: str
    observed_status: str
    origin: CalibrationOrigin
    reviewer_id: str
    reviewed_at: datetime
    adjudication_ref: str
    source_refs: tuple[SourceRef, ...] = ()
    human_overturned: bool = False

    def __post_init__(self) -> None:
        expected = {str(key): float(value) for key, value in self.expected.items()}
        observed = {str(key): float(value) for key, value in self.observed.items()}
        object.__setattr__(self, "expected", expected)
        object.__setattr__(self, "observed", observed)
        object.__setattr__(self, "source_refs", tuple(self.source_refs))
        if not self.case_id.strip():
            raise ValueError("calibration case_id is required")
        if not self.metric.strip() or not self.metric_version.strip():
            raise ValueError("calibration metric and version are required")
        SemVer.parse(self.metric_version)
        if not self.input_sha256.strip():
            raise ValueError("calibration input_sha256 is required")
        if not expected and not observed:
            raise ValueError(
                "calibration case requires expected or observed dimensions"
            )
        for label, values in (("expected", expected), ("observed", observed)):
            for key, value in values.items():
                if not str(key).strip() or not math.isfinite(float(value)):
                    raise ValueError(f"{label} dimensions must be finite and named")
        if not self.expected_status.strip() or not self.observed_status.strip():
            raise ValueError("expected and observed statuses are required")
        if self.origin != CalibrationOrigin.SYNTHETIC and not self.source_refs:
            raise ValueError("real calibration cases require source references")
        if not self.reviewer_id.strip() or not self.adjudication_ref.strip():
            raise ValueError("reviewer_id and adjudication_ref are required")
        if self.reviewed_at.tzinfo is None:
            raise ValueError("reviewed_at must include a timezone")

    @property
    def dimension_gap(self) -> tuple[str, ...]:
        return tuple(sorted(set(self.expected) ^ set(self.observed)))

    @property
    def common_errors(self) -> tuple[float, ...]:
        return tuple(
            abs(float(self.observed[key]) - float(self.expected[key]))
            for key in sorted(set(self.expected) & set(self.observed))
        )


@dataclass(frozen=True)
class CalibrationPolicy:
    minimum_cases: int = 20
    maximum_mae: float = 0.15
    maximum_abs_error: float = 0.30
    maximum_dimension_gap_rate: float = 0.0
    maximum_status_mismatch_rate: float = 0.05
    minimum_overturn_records: int = 1
    allow_synthetic: bool = False

    def __post_init__(self) -> None:
        if self.minimum_cases < 1:
            raise ValueError("minimum_cases must be positive")
        for label, value in {
            "maximum_mae": self.maximum_mae,
            "maximum_abs_error": self.maximum_abs_error,
            "maximum_dimension_gap_rate": self.maximum_dimension_gap_rate,
            "maximum_status_mismatch_rate": self.maximum_status_mismatch_rate,
        }.items():
            if not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError(f"{label} must be in [0, 1]")
        if self.minimum_overturn_records < 0:
            raise ValueError("minimum_overturn_records must be non-negative")


@dataclass(frozen=True)
class CalibrationReport:
    metric: str
    metric_version: str
    case_count: int
    dimension_comparisons: int
    mean_absolute_error: float | None
    maximum_absolute_error: float | None
    dimension_gap_cases: int
    status_mismatch_cases: int
    synthetic_cases: int
    overturned_cases: int
    source_coverage: float
    gate_checks: dict[str, bool]

    @property
    def passed(self) -> bool:
        return bool(self.gate_checks) and all(self.gate_checks.values())

    def to_dict(self) -> dict[str, Any]:
        return {
            **to_jsonable(self),
            "passed": self.passed,
        }


def evaluate_calibration(
    cases: list[CalibrationCase],
    policy: CalibrationPolicy,
) -> CalibrationReport:
    if not cases:
        return CalibrationReport(
            metric="",
            metric_version="",
            case_count=0,
            dimension_comparisons=0,
            mean_absolute_error=None,
            maximum_absolute_error=None,
            dimension_gap_cases=0,
            status_mismatch_cases=0,
            synthetic_cases=0,
            overturned_cases=0,
            source_coverage=0.0,
            gate_checks={"minimum_cases": False},
        )
    metric = cases[0].metric
    metric_version = cases[0].metric_version
    ids = [case.case_id for case in cases]
    if len(ids) != len(set(ids)):
        raise ValueError("calibration case IDs must be unique")
    if any(
        case.metric != metric or case.metric_version != metric_version for case in cases
    ):
        raise ValueError("all calibration cases must use the same metric version")

    errors = [error for case in cases for error in case.common_errors]
    dimension_gap_cases = sum(bool(case.dimension_gap) for case in cases)
    status_mismatch_cases = sum(
        case.expected_status != case.observed_status for case in cases
    )
    synthetic_cases = sum(case.origin == CalibrationOrigin.SYNTHETIC for case in cases)
    overturned_cases = sum(case.human_overturned for case in cases)
    source_coverage = sum(bool(case.source_refs) for case in cases) / len(cases)
    mae = sum(errors) / len(errors) if errors else None
    maximum_error = max(errors) if errors else None
    dimension_gap_rate = dimension_gap_cases / len(cases)
    status_mismatch_rate = status_mismatch_cases / len(cases)

    checks = {
        "minimum_cases": len(cases) >= policy.minimum_cases,
        "mean_absolute_error": (mae is not None and mae <= policy.maximum_mae),
        "maximum_absolute_error": (
            maximum_error is not None and maximum_error <= policy.maximum_abs_error
        ),
        "dimension_coverage": (dimension_gap_rate <= policy.maximum_dimension_gap_rate),
        "status_agreement": (
            status_mismatch_rate <= policy.maximum_status_mismatch_rate
        ),
        "source_coverage": source_coverage == 1.0,
        "synthetic_data_excluded": (policy.allow_synthetic or synthetic_cases == 0),
        "overturn_records": (overturned_cases >= policy.minimum_overturn_records),
    }
    return CalibrationReport(
        metric=metric,
        metric_version=metric_version,
        case_count=len(cases),
        dimension_comparisons=len(errors),
        mean_absolute_error=round(mae, 6) if mae is not None else None,
        maximum_absolute_error=(
            round(maximum_error, 6) if maximum_error is not None else None
        ),
        dimension_gap_cases=dimension_gap_cases,
        status_mismatch_cases=status_mismatch_cases,
        synthetic_cases=synthetic_cases,
        overturned_cases=overturned_cases,
        source_coverage=round(source_coverage, 6),
        gate_checks=checks,
    )
