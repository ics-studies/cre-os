from __future__ import annotations

from collections import deque
from collections.abc import Iterable
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any

from .models import SourceRef
from .serialization import to_jsonable
from .version import SemVer


class ChangeKind(str, Enum):
    MAJOR = "major"
    MINOR = "minor"
    PATCH = "patch"
    PRERELEASE = "prerelease"
    RELEASE = "release"


class DependencyRelation(str, Enum):
    REQUIRES = "requires"
    IMPLEMENTS = "implements"
    REFERENCES = "references"
    DERIVES = "derives"


@dataclass(frozen=True)
class ArtifactDependency:
    consumer_id: str
    provider_id: str
    relation: DependencyRelation

    def __post_init__(self) -> None:
        if not self.consumer_id.strip() or not self.provider_id.strip():
            raise ValueError("dependency artifact IDs are required")
        if self.consumer_id == self.provider_id:
            raise ValueError("self-dependencies are not allowed")


@dataclass(frozen=True)
class ImpactPath:
    artifact_id: str
    path: tuple[str, ...]
    relations: tuple[DependencyRelation, ...]
    depth: int

    def __post_init__(self) -> None:
        if self.depth < 1:
            raise ValueError("impact depth must be positive")
        if len(self.path) != self.depth + 1:
            raise ValueError("impact path length must equal depth plus one")
        if len(self.relations) != self.depth:
            raise ValueError("impact relations must match impact depth")

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> ImpactPath:
        return cls(
            artifact_id=str(payload["artifact_id"]),
            path=tuple(str(item) for item in payload["path"]),
            relations=tuple(
                DependencyRelation(str(item)) for item in payload["relations"]
            ),
            depth=int(payload["depth"]),
        )


@dataclass(frozen=True)
class ImpactReport:
    changed_artifacts: tuple[str, ...]
    impacted: tuple[ImpactPath, ...]
    unresolved_artifacts: tuple[str, ...] = ()
    cycles: tuple[tuple[str, ...], ...] = ()

    @property
    def impacted_artifacts(self) -> tuple[str, ...]:
        return tuple(item.artifact_id for item in self.impacted)

    @property
    def status(self) -> str:
        if self.cycles:
            return "cycle_detected"
        if self.unresolved_artifacts:
            return "incomplete"
        return "complete"

    @property
    def requires_review(self) -> bool:
        return bool(self.impacted or self.unresolved_artifacts or self.cycles)

    def to_dict(self) -> dict[str, Any]:
        return {
            **to_jsonable(asdict(self)),
            "status": self.status,
            "requires_review": self.requires_review,
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> ImpactReport:
        return cls(
            changed_artifacts=tuple(
                str(item) for item in payload.get("changed_artifacts", ())
            ),
            impacted=tuple(
                ImpactPath.from_dict(item) for item in payload.get("impacted", ())
            ),
            unresolved_artifacts=tuple(
                str(item) for item in payload.get("unresolved_artifacts", ())
            ),
            cycles=tuple(
                tuple(str(item) for item in cycle)
                for cycle in payload.get("cycles", ())
            ),
        )


class VersionDependencyGraph:
    """Directed provider-to-consumer graph used for version impact analysis."""

    def __init__(self) -> None:
        self._outgoing: dict[str, list[ArtifactDependency]] = {}
        self._artifacts: set[str] = set()

    def add_dependency(self, dependency: ArtifactDependency) -> None:
        existing = self._outgoing.setdefault(dependency.provider_id, [])
        if dependency in existing:
            raise ValueError(
                f"duplicate dependency: {dependency.provider_id} -> "
                f"{dependency.consumer_id}"
            )
        existing.append(dependency)
        existing.sort(key=lambda item: (item.consumer_id, item.relation.value))
        self._artifacts.update((dependency.provider_id, dependency.consumer_id))

    def dependencies_of(self, provider_id: str) -> tuple[ArtifactDependency, ...]:
        return tuple(self._outgoing.get(provider_id, ()))

    def analyze(self, changed_artifacts: Iterable[str]) -> ImpactReport:
        changed = tuple(
            dict.fromkeys(
                item.strip()
                for item in changed_artifacts
                if isinstance(item, str) and item.strip()
            )
        )
        if not changed:
            raise ValueError("at least one changed artifact is required")

        unresolved = tuple(item for item in changed if item not in self._artifacts)
        known_changed = tuple(item for item in changed if item in self._artifacts)
        queue: deque[tuple[str, tuple[str, ...], tuple[DependencyRelation, ...]]] = (
            deque((item, (item,), ()) for item in known_changed)
        )
        best_depth = {item: 0 for item in known_changed}
        impacted: list[ImpactPath] = []
        while queue:
            provider_id, path, relations = queue.popleft()
            for dependency in self._outgoing.get(provider_id, ()):
                depth = len(relations) + 1
                previous_depth = best_depth.get(dependency.consumer_id)
                if previous_depth is not None and previous_depth < depth:
                    continue
                if previous_depth == depth:
                    continue
                best_depth[dependency.consumer_id] = depth
                next_path = (*path, dependency.consumer_id)
                next_relations = (*relations, dependency.relation)
                impacted.append(
                    ImpactPath(
                        artifact_id=dependency.consumer_id,
                        path=next_path,
                        relations=next_relations,
                        depth=depth,
                    )
                )
                queue.append((dependency.consumer_id, next_path, next_relations))

        impacted.sort(key=lambda item: (item.depth, item.artifact_id, item.path))
        cycles = self._find_cycles(known_changed)
        return ImpactReport(
            changed_artifacts=changed,
            impacted=tuple(impacted),
            unresolved_artifacts=unresolved,
            cycles=cycles,
        )

    def _find_cycles(self, starts: tuple[str, ...]) -> tuple[tuple[str, ...], ...]:
        state: dict[str, int] = {}
        stack: list[str] = []
        cycles: list[tuple[str, ...]] = []
        seen_cycles: set[tuple[str, ...]] = set()

        def visit(artifact_id: str) -> None:
            state[artifact_id] = 1
            stack.append(artifact_id)
            for dependency in self._outgoing.get(artifact_id, ()):
                consumer_id = dependency.consumer_id
                if state.get(consumer_id, 0) == 0:
                    visit(consumer_id)
                elif state.get(consumer_id) == 1:
                    start = stack.index(consumer_id)
                    cycle = (*stack[start:], consumer_id)
                    canonical = min(
                        cycle[index:-1] + cycle[:index]
                        for index in range(len(cycle) - 1)
                    )
                    if canonical not in seen_cycles:
                        seen_cycles.add(canonical)
                        cycles.append(cycle)
            stack.pop()
            state[artifact_id] = 2

        for start in starts:
            if state.get(start, 0) == 0:
                visit(start)
        return tuple(cycles)

    def to_dict(self) -> dict[str, Any]:
        dependencies = [
            dependency for values in self._outgoing.values() for dependency in values
        ]
        dependencies.sort(
            key=lambda item: (
                item.provider_id,
                item.consumer_id,
                item.relation.value,
            )
        )
        return {
            "schema_version": "1.0.0",
            "dependencies": [to_jsonable(item) for item in dependencies],
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> VersionDependencyGraph:
        if payload.get("schema_version") != "1.0.0":
            raise ValueError("unsupported dependency-graph schema")
        graph = cls()
        for raw in payload.get("dependencies", ()):
            graph.add_dependency(
                ArtifactDependency(
                    consumer_id=str(raw["consumer_id"]),
                    provider_id=str(raw["provider_id"]),
                    relation=DependencyRelation(str(raw["relation"])),
                )
            )
        return graph


@dataclass(frozen=True)
class ApprovalRecord:
    approved_by: str
    approval_ref: str
    approved_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def __post_init__(self) -> None:
        if not self.approved_by.strip():
            raise ValueError("approved_by is required")
        if not self.approval_ref.strip():
            raise ValueError("approval_ref is required")
        if self.approved_at.tzinfo is None:
            raise ValueError("approved_at must include a timezone")


@dataclass(frozen=True)
class VersionEntry:
    version: SemVer
    snapshot_hash: str
    change_kind: ChangeKind
    rationale: str
    actor: str
    approved_by: str
    sources: tuple[SourceRef, ...] = ()
    parents: tuple[SemVer, ...] = ()
    rollback_of: SemVer | None = None
    merge_sources: tuple[SemVer, ...] = ()
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    metadata: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["version"] = str(self.version)
        payload["parents"] = [str(parent) for parent in self.parents]
        payload["rollback_of"] = str(self.rollback_of) if self.rollback_of else None
        payload["merge_sources"] = [str(source) for source in self.merge_sources]
        return to_jsonable(payload)


@dataclass(frozen=True)
class RollbackResult:
    entry: VersionEntry
    restored_snapshot_hash: str
    superseded_version: SemVer

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["entry"]["version"] = str(self.entry.version)
        payload["entry"]["parents"] = [str(parent) for parent in self.entry.parents]
        payload["entry"]["rollback_of"] = (
            str(self.entry.rollback_of) if self.entry.rollback_of else None
        )
        payload["superseded_version"] = str(self.superseded_version)
        return to_jsonable(payload)


@dataclass(frozen=True)
class MergeResult:
    entry: VersionEntry
    source_branch: str
    source_entry: VersionEntry
    impact: ImpactReport

    def to_dict(self) -> dict[str, Any]:
        return {
            "entry": self.entry.to_dict(),
            "source_branch": self.source_branch,
            "source_entry": self.source_entry.to_dict(),
            "impact": self.impact.to_dict(),
        }


class VersionRegistry:
    """Append-only governance ledger for a versioned normative object."""

    def __init__(self) -> None:
        self._entries: list[VersionEntry] = []
        self._by_version: dict[tuple[int, int, int, str | None], VersionEntry] = {}
        self._impacts: dict[
            tuple[int, int, int, str | None],
            ImpactReport,
        ] = {}

    @staticmethod
    def _key(version: SemVer) -> tuple[int, int, int, str | None]:
        return (*version.core, version.prerelease)

    def add(self, entry: VersionEntry) -> None:
        if not entry.snapshot_hash.strip():
            raise ValueError("snapshot_hash is required")
        if not entry.rationale.strip():
            raise ValueError("rationale is required")
        if not entry.actor.strip() or not entry.approved_by.strip():
            raise ValueError("actor and approved_by are required")
        key = self._key(entry.version)
        if key in self._by_version:
            raise ValueError(f"version already exists: {entry.version}")

        if self._entries:
            previous = self._entries[-1].version
            if entry.version <= previous:
                raise ValueError(
                    f"new version {entry.version} must be greater than {previous}"
                )
            expected_kind = _required_change_kind(previous, entry.version)
            if entry.change_kind != expected_kind:
                raise ValueError(
                    f"{entry.version} requires change_kind={expected_kind.value}"
                )
            if previous not in entry.parents:
                raise ValueError("new entry must name the current version as a parent")
            if entry.merge_sources and not set(entry.merge_sources).issubset(
                entry.parents
            ):
                raise ValueError("merge_sources must also be declared as parents")
        elif entry.parents:
            raise ValueError("first version must not declare parents")

        self._entries.append(entry)
        self._by_version[key] = entry

    def get(self, version: SemVer | str) -> VersionEntry:
        parsed = version if isinstance(version, SemVer) else SemVer.parse(version)
        try:
            return self._by_version[self._key(parsed)]
        except KeyError as exc:
            raise KeyError(f"unknown version: {parsed}") from exc

    @property
    def latest(self) -> VersionEntry:
        if not self._entries:
            raise ValueError("registry is empty")
        return self._entries[-1]

    def history(self) -> tuple[VersionEntry, ...]:
        return tuple(self._entries)

    def record_impact(
        self,
        version: SemVer | str,
        report: ImpactReport,
    ) -> None:
        entry = self.get(version)
        key = self._key(entry.version)
        if key in self._impacts:
            raise ValueError(f"impact report already exists: {entry.version}")
        if not report.changed_artifacts:
            raise ValueError("impact report must name changed artifacts")
        self._impacts[key] = report

    def impact_for(self, version: SemVer | str) -> ImpactReport:
        entry = self.get(version)
        try:
            return self._impacts[self._key(entry.version)]
        except KeyError as exc:
            raise KeyError(f"no impact report for version: {entry.version}") from exc

    def to_dict(self) -> dict[str, Any]:
        impacts = [
            {
                "version": str(entry.version),
                "impact": self._impacts[self._key(entry.version)].to_dict(),
            }
            for entry in self._entries
            if self._key(entry.version) in self._impacts
        ]
        return {
            "schema_version": "1.1.0",
            "entries": [entry.to_dict() for entry in self._entries],
            "impacts": impacts,
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> VersionRegistry:
        if payload.get("schema_version") not in {"1.0.0", "1.1.0"}:
            raise ValueError("unsupported version-ledger schema")
        registry = cls()
        for raw in payload.get("entries", []):
            created_at = raw.get("created_at")
            registry.add(
                VersionEntry(
                    version=SemVer.parse(raw["version"]),
                    snapshot_hash=raw["snapshot_hash"],
                    change_kind=ChangeKind(raw["change_kind"]),
                    rationale=raw["rationale"],
                    actor=raw["actor"],
                    approved_by=raw["approved_by"],
                    sources=tuple(
                        SourceRef(**source) for source in raw.get("sources", [])
                    ),
                    parents=tuple(
                        SemVer.parse(version) for version in raw.get("parents", [])
                    ),
                    rollback_of=(
                        SemVer.parse(raw["rollback_of"])
                        if raw.get("rollback_of")
                        else None
                    ),
                    merge_sources=tuple(
                        SemVer.parse(version)
                        for version in raw.get("merge_sources", ())
                    ),
                    created_at=datetime.fromisoformat(created_at)
                    if created_at
                    else datetime.now(UTC),
                    metadata=dict(raw.get("metadata", {})),
                )
            )
        for raw in payload.get("impacts", ()):
            registry.record_impact(
                str(raw["version"]),
                ImpactReport.from_dict(raw["impact"]),
            )
        return registry

    def branch_from(self, version: SemVer | str) -> VersionRegistry:
        entry = self.get(version)
        key = self._key(entry.version)
        branch = VersionRegistry()
        for historical in self._entries:
            branch.add(historical)
            if self._key(historical.version) in self._impacts:
                branch.record_impact(
                    historical.version,
                    self._impacts[self._key(historical.version)],
                )
            if self._key(historical.version) == key:
                break
        return branch

    def merge(
        self,
        source_entry: VersionEntry,
        *,
        source_branch: str,
        snapshot_hash: str,
        rationale: str,
        actor: str,
        change_kind: ChangeKind,
        approval: ApprovalRecord,
        impact: ImpactReport,
    ) -> MergeResult:
        if not source_branch.strip():
            raise ValueError("source_branch is required")
        if any(
            self._key(entry.version) == self._key(source_entry.version)
            for entry in self._entries
        ):
            raise ValueError("source version already exists in the target registry")
        if any(source_entry.version in entry.merge_sources for entry in self._entries):
            raise ValueError("source version has already been merged")
        if change_kind not in {ChangeKind.MAJOR, ChangeKind.MINOR, ChangeKind.PATCH}:
            raise ValueError("merge change_kind must be major, minor or patch")
        if not impact.changed_artifacts:
            raise ValueError("merge requires an impact report with changed artifacts")

        current = self.latest
        if (
            source_entry.version.major > current.version.major
            and change_kind != ChangeKind.MAJOR
        ):
            raise ValueError("merging a higher major branch requires a major release")
        if (
            source_entry.version.major == current.version.major
            and source_entry.version.minor > current.version.minor
            and change_kind == ChangeKind.PATCH
        ):
            raise ValueError("merging a higher minor branch requires at least minor")
        if change_kind == ChangeKind.PATCH:
            next_version = current.version.bump_patch()
        elif change_kind == ChangeKind.MINOR:
            next_version = current.version.bump_minor()
        else:
            next_version = current.version.bump_major()
        entry = VersionEntry(
            version=next_version,
            snapshot_hash=snapshot_hash,
            change_kind=change_kind,
            rationale=rationale,
            actor=actor,
            approved_by=approval.approved_by,
            sources=tuple(dict.fromkeys((*current.sources, *source_entry.sources))),
            parents=tuple(dict.fromkeys((current.version, source_entry.version))),
            merge_sources=(source_entry.version,),
            metadata={
                "operation": "merge",
                "source_branch": source_branch,
                "source_snapshot_hash": source_entry.snapshot_hash,
                "approval_ref": approval.approval_ref,
                "approved_at": approval.approved_at.isoformat(),
                "impact_status": impact.status,
            },
        )
        self.add(entry)
        self.record_impact(entry.version, impact)
        return MergeResult(
            entry=entry,
            source_branch=source_branch,
            source_entry=source_entry,
            impact=impact,
        )

    def rollback(
        self,
        target: SemVer | str,
        *,
        actor: str,
        approved_by: str,
        rationale: str,
        change_kind: ChangeKind | None = None,
        metadata: dict[str, str] | None = None,
    ) -> RollbackResult:
        current = self.latest
        target_entry = self.get(target)
        kind = change_kind or ChangeKind.PATCH
        if kind == ChangeKind.PRERELEASE:
            raise ValueError("rollback cannot target an unreleased prerelease")
        if kind == ChangeKind.PATCH:
            next_version = current.version.bump_patch()
        elif kind == ChangeKind.MINOR:
            next_version = current.version.bump_minor()
        else:
            next_version = current.version.bump_major()

        entry = VersionEntry(
            version=next_version,
            snapshot_hash=target_entry.snapshot_hash,
            change_kind=kind,
            rationale=rationale,
            actor=actor,
            approved_by=approved_by,
            sources=target_entry.sources,
            parents=(current.version,),
            rollback_of=target_entry.version,
            metadata={
                "operation": "rollback",
                "restored_from": str(target_entry.version),
                **(metadata or {}),
            },
        )
        self.add(entry)
        return RollbackResult(
            entry=entry,
            restored_snapshot_hash=target_entry.snapshot_hash,
            superseded_version=current.version,
        )


def _required_change_kind(previous: SemVer, current: SemVer) -> ChangeKind:
    if current.core == previous.core:
        if previous.prerelease and current.prerelease is None:
            return ChangeKind.RELEASE
        if previous.prerelease and current.prerelease:
            return ChangeKind.PRERELEASE
        raise ValueError("same-core version transition is not a forward release")
    if current.major != previous.major:
        if (current.minor, current.patch) != (0, 0):
            raise ValueError("major version bump must reset minor and patch to zero")
        if current.prerelease:
            return ChangeKind.PRERELEASE
        return ChangeKind.MAJOR
    if current.minor != previous.minor:
        if current.patch != 0:
            raise ValueError("minor version bump must reset patch to zero")
        if current.prerelease:
            return ChangeKind.PRERELEASE
        return ChangeKind.MINOR
    if current.patch != previous.patch:
        if current.prerelease:
            return ChangeKind.PRERELEASE
        return ChangeKind.PATCH
    raise ValueError("version did not increase")
