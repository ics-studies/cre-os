from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .models import SourceRef


class GovernanceLayer(str, Enum):
    """Third-volume governance ontology; not interchangeable with runtime layers."""

    PHYSICAL_INFORMATION = "G0"
    SUBJECT_RECOGNITION = "G1"
    NORMATIVE_PRINCIPLE = "G2"
    INSTITUTION_DESIGN = "G3"
    OPERATIONAL_PROCEDURE = "G4"


class RuntimeLayer(str, Enum):
    """Fourth-volume software runtime ontology."""

    REDLINE_ENFORCEMENT = "R0"
    PRINCIPLE_REASONING = "R1"
    INDICATOR_COMPUTATION = "R2"
    INSTITUTION_RUNTIME = "R3"
    APPLICATION_INTERFACE = "R4"


@dataclass(frozen=True)
class ForbiddenRedLine:
    identifier: str
    statement: str
    source: SourceRef
    subconditions: tuple[str, ...] = ()


FRLS: dict[str, ForbiddenRedLine] = {
    "FRL-1": ForbiddenRedLine(
        "FRL-1",
        "禁止故意灭绝",
        SourceRef(1, "10", "10.5.5", "T5"),
    ),
    "FRL-2": ForbiddenRedLine(
        "FRL-2",
        "禁止不可逆的大规模环境破坏",
        SourceRef(1, "10", "10.5.5", "T5"),
    ),
    "FRL-3": ForbiddenRedLine(
        "FRL-3",
        "禁止未经同意的不可逆认知改造",
        SourceRef(1, "10", "10.5.5", "T5"),
    ),
    "FRL-4": ForbiddenRedLine(
        "FRL-4",
        "禁止跨代熵成本极端外部化",
        SourceRef(1, "10", "10.5.5", "T5"),
    ),
    "FRL-5": ForbiddenRedLine(
        "FRL-5",
        "禁止关闭回滚机制",
        SourceRef(1, "10", "10.5.5", "T5"),
        subconditions=("关闭能力", "回滚能力"),
    ),
}


def principle_order(deep_uncertainty: bool, emergency: bool = False) -> tuple[str, ...]:
    if emergency:
        return ("REV", "NRP", "RFP")
    if deep_uncertainty:
        return ("REV", "RFP", "NRP")
    return ("RFP", "NRP", "REV")
