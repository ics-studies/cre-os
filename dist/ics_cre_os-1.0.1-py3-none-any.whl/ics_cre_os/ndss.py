from __future__ import annotations

from dataclasses import dataclass

from .crcsp import (
    CandidateAction,
    ConstraintEvaluation,
    ConstraintProof,
    ConstraintRule,
    ContextKind,
    CRCSPSolver,
    Decision,
    RankingProof,
)
from .evidence_assessment import MetricComputation
from .measurement import MeasurementResult
from .models import MetricResult, SourceRef
from .serialization import to_jsonable


@dataclass(frozen=True)
class MetricDecisionSummary:
    metric: str
    metric_version: str
    status: str
    score: float | None
    dimensions: dict[str, float]
    evidence_ids: tuple[str, ...]
    missing_dimensions: tuple[str, ...]
    warnings: tuple[str, ...]
    sources: tuple[SourceRef, ...]
    uncertainty_kind: str = "unspecified"
    interval_lower: float | None = None
    interval_upper: float | None = None
    possible_levels: tuple[int, ...] = ()
    uncertainty_available: bool = False


@dataclass(frozen=True)
class DecisionBrief:
    decision: Decision
    recommended_action: str | None
    alternatives: tuple[str, ...]
    priority: tuple[str, ...]
    excluded_actions: tuple[str, ...]
    constraint_proofs: tuple[ConstraintProof, ...]
    constraint_evaluations: tuple[ConstraintEvaluation, ...]
    ranking_proof: tuple[RankingProof, ...]
    metric_summary: dict[str, float | None]
    metric_details: tuple[MetricDecisionSummary, ...]
    evidence_requests: tuple[str, ...]
    warnings: tuple[str, ...]
    human_review_required: bool
    claim_boundary: str
    sources: tuple[SourceRef, ...]
    uncertainty_requirements: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, object]:
        return to_jsonable(self)


def _metric_detail(
    metric: MetricResult | MetricComputation | MeasurementResult,
) -> MetricDecisionSummary:
    if isinstance(metric, MeasurementResult):
        interval = metric.interval.projected_interval() if metric.interval else None
        primary = dict(metric.primary)
        score_value = primary.get("score", primary.get("capacity_proxy"))
        vector_value = primary.get("vector")
        dimensions = (
            {str(key): float(value) for key, value in dict(vector_value).items()}
            if isinstance(vector_value, dict)
            else {}
        )
        if metric.interval is not None:
            kind = metric.interval.kind.value
        else:
            kinds = {
                envelope.kind.value for envelope in metric.component_intervals.values()
            }
            kind = max(
                kinds,
                key={"risk": 0, "knightian": 1, "deep": 2}.get,
                default="unspecified",
            )
        return MetricDecisionSummary(
            metric=metric.metric_id,
            metric_version=metric.method_version,
            status=metric.status,
            score=(float(score_value) if score_value is not None else None),
            dimensions=dimensions,
            evidence_ids=metric.audit.evidence_ids if metric.audit else (),
            missing_dimensions=metric.missing_dimensions,
            warnings=metric.warnings,
            sources=metric.sources,
            uncertainty_kind=kind,
            interval_lower=interval.lower if interval else None,
            interval_upper=interval.upper if interval else None,
            possible_levels=metric.possible_levels,
            uncertainty_available=bool(metric.interval or metric.component_intervals),
        )

    if isinstance(metric, MetricResult):
        return MetricDecisionSummary(
            metric=metric.metric,
            metric_version=metric.metric_version,
            status=metric.status,
            score=metric.score,
            dimensions=dict(metric.dimensions),
            evidence_ids=tuple(
                span.evidence_id for record in metric.evidence for span in record.spans
            ),
            missing_dimensions=(),
            warnings=tuple(metric.warnings),
            sources=tuple(metric.sources),
            uncertainty_kind=metric.uncertainty_kind,
            interval_lower=(
                metric.interval.lower if metric.interval is not None else None
            ),
            interval_upper=(
                metric.interval.upper if metric.interval is not None else None
            ),
            possible_levels=tuple(metric.possible_levels),
            uncertainty_available=metric.interval is not None,
        )

    result = metric.result
    dimensions: dict[str, float] = {}
    score: float | None = None
    if result is not None:
        if hasattr(result, "dimensions"):
            dimensions = {
                str(key): float(value) for key, value in dict(result.dimensions).items()
            }
        elif hasattr(result, "vector"):
            dimensions = {
                str(key): float(value) for key, value in dict(result.vector).items()
            }
        elif metric.metric == "CRV":
            dimensions = {
                "observability": float(result.observability),
                "enforceability": float(result.enforceability),
                "reversibility": float(result.reversibility),
            }
        elif metric.metric == "MBCL":
            dimensions = {"risk_norm": float(result.risk_norm)}
        if hasattr(result, "score"):
            raw_score = result.score
            score = float(raw_score) if raw_score is not None else None
    return MetricDecisionSummary(
        metric=metric.metric,
        metric_version=metric.metric_version,
        status=metric.status,
        score=score,
        dimensions=dimensions,
        evidence_ids=tuple(metric.evidence_ids),
        missing_dimensions=tuple(metric.missing_dimensions),
        warnings=tuple(metric.warnings),
        sources=tuple(metric.sources),
        uncertainty_kind="unspecified",
        interval_lower=(
            result.interval.lower
            if result is not None and getattr(result, "interval", None) is not None
            else None
        ),
        interval_upper=(
            result.interval.upper
            if result is not None and getattr(result, "interval", None) is not None
            else None
        ),
        uncertainty_available=(
            result is not None and getattr(result, "interval", None) is not None
        ),
    )


class NDSS:
    """Report builder for structured decision support."""

    def __init__(self, solver: CRCSPSolver | None = None) -> None:
        self.solver = solver or CRCSPSolver()

    def assess(
        self,
        actions: list[CandidateAction],
        metrics: list[MetricResult | MetricComputation | MeasurementResult],
        *,
        context: ContextKind = ContextKind.ROUTINE,
        escalate_on_evidence_gap: bool = False,
        constraints: list[ConstraintRule] | None = None,
    ) -> DecisionBrief:
        metric_names = [
            metric.metric_id if isinstance(metric, MeasurementResult) else metric.metric
            for metric in metrics
        ]
        if len(metric_names) != len(set(metric_names)):
            raise ValueError("metric names must be unique")
        details = tuple(_metric_detail(metric) for metric in metrics)
        if any(not detail.sources for detail in details):
            raise ValueError("every metric input must include at least one source")
        solution = self.solver.solve(
            actions,
            context=context,
            escalate_on_evidence_gap=escalate_on_evidence_gap,
            constraints=constraints,
        )
        metric_evidence_requests = tuple(
            f"{detail.metric}: missing evidence for dimension {dimension}"
            for detail in details
            for dimension in detail.missing_dimensions
        )
        evidence_requests = (
            tuple(gap for action in actions for gap in action.evidence_gaps)
            + metric_evidence_requests
        )
        uncertainty_requirements = tuple(
            requirement
            for detail in details
            for requirement in (
                (f"{detail.metric}: deep uncertainty requires scenario review",)
                if detail.uncertainty_kind == "deep"
                else ()
            )
            + (
                (
                    (
                        f"{detail.metric}: interval crosses levels "
                        f"{', '.join(str(level) for level in detail.possible_levels)}"
                    ),
                )
                if len(detail.possible_levels) > 1
                else ()
            )
            + (
                (f"{detail.metric}: no uncertainty interval was supplied",)
                if detail.status == "calculated" and not detail.uncertainty_available
                else ()
            )
        )
        warnings = tuple(warning for detail in details for warning in detail.warnings)
        human_review = bool(
            evidence_requests
            or uncertainty_requirements
            or any(detail.status == "not_assessable" for detail in details)
            or any(
                excluded.decision in {Decision.DEFER, Decision.ESCALATE}
                for excluded in solution.excluded
            )
        )
        alternatives = tuple(
            action_id
            for action_id in solution.ranking
            if action_id != solution.selected
        )
        return DecisionBrief(
            decision=solution.decision,
            recommended_action=solution.selected,
            alternatives=alternatives,
            priority=solution.priority,
            excluded_actions=tuple(
                excluded.action_id for excluded in solution.excluded
            ),
            constraint_proofs=tuple(
                proof for excluded in solution.excluded for proof in excluded.proof
            ),
            constraint_evaluations=solution.constraint_evaluations,
            ranking_proof=solution.ranking_proof,
            metric_summary={detail.metric: detail.score for detail in details},
            metric_details=details,
            evidence_requests=evidence_requests,
            warnings=warnings,
            human_review_required=human_review,
            claim_boundary=(
                "NDSS provides decision support only. It does not replace legal, "
                "ethical, political, or institutional judgment. Deep or "
                "unresolved uncertainty remains visible to the reviewer."
            ),
            sources=(
                SourceRef(4, "7"),
                SourceRef(3, "10"),
            ),
            uncertainty_requirements=uncertainty_requirements,
        )
