from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Any

from .metrics import (
    CRV_ENF_SUBDIMENSIONS,
    CRV_OBS_SUBDIMENSIONS,
    CRV_REV_SUBDIMENSIONS,
)
from .serialization import to_jsonable

CRV_ALL_SUBDIMENSIONS = (
    *CRV_OBS_SUBDIMENSIONS,
    *CRV_ENF_SUBDIMENSIONS,
    *CRV_REV_SUBDIMENSIONS,
)


@dataclass(frozen=True)
class ObservationRule:
    rule_id: str
    dimension: str
    patterns: tuple[str, ...]
    weight: float
    rationale: str

    def __post_init__(self) -> None:
        if self.dimension not in CRV_ALL_SUBDIMENSIONS:
            raise ValueError(f"unknown CRV dimension: {self.dimension}")
        if not self.patterns:
            raise ValueError(f"{self.rule_id}: patterns are required")
        if not -1.0 <= self.weight <= 1.0:
            raise ValueError(f"{self.rule_id}: weight must be in [-1, 1]")
        if not self.rationale.strip():
            raise ValueError(f"{self.rule_id}: rationale is required")


@dataclass(frozen=True)
class DimensionObservation:
    dimension: str
    score: float
    matched_rule_ids: tuple[str, ...]
    matched_terms: tuple[str, ...]
    rationale: str


@dataclass(frozen=True)
class CRVObservation:
    case_id: str
    domain: str
    status: str
    dimensions: dict[str, float]
    evidence: tuple[DimensionObservation, ...]
    text_sha256: str
    method_version: str = "crv-observation-rules-0.3.0"
    warnings: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.case_id.strip():
            raise ValueError("case_id is required")
        if self.domain not in {"AI", "ESG"}:
            raise ValueError("domain must be AI or ESG")
        if self.status not in {"calculated", "not_assessable"}:
            raise ValueError("unknown observation status")
        object.__setattr__(self, "dimensions", dict(self.dimensions))
        object.__setattr__(self, "evidence", tuple(self.evidence))
        object.__setattr__(self, "warnings", tuple(self.warnings))

    def to_dict(self) -> dict[str, Any]:
        return to_jsonable(self)


_RULES = (
    ObservationRule(
        "SIG-ACTOR",
        "signal_clarity",
        (
            "provider",
            "company",
            "openai",
            "anthropic",
            "microsoft",
            "controller",
            "data subject",
            "宁德时代",
            "本公司",
        ),
        0.15,
        "A responsible actor is identifiable.",
    ),
    ObservationRule(
        "SIG-FIRST-PERSON",
        "signal_clarity",
        (
            " our ",
            " we ",
            " you ",
            "本公司",
            "公司",
        ),
        0.10,
        "A first-person actor or organisation is identifiable.",
    ),
    ObservationRule(
        "SIG-OBLIGATION",
        "signal_clarity",
        (
            " shall ",
            " must ",
            " commit",
            " will ",
            " cannot ",
            " may not ",
            " prohibited ",
            " do not ",
            "承诺",
            "应",
            "不得",
            "必须",
        ),
        0.20,
        "The text states an obligation or prohibition.",
    ),
    ObservationRule(
        "SIG-TIME",
        "signal_clarity",
        (
            " by 20",
            " by 203",
            " by 204",
            " by 205",
            "年实现",
            "年度",
            "lifetime",
            "ongoing",
        ),
        0.15,
        "A timeframe or lifecycle boundary is stated.",
    ),
    ObservationRule(
        "SIG-METRIC",
        "signal_clarity",
        (
            "%",
            "net zero",
            "carbon negative",
            "carbon neutral",
            "zero waste",
            "reduce",
            "减少",
            "碳中和",
            "净零",
        ),
        0.20,
        "A measurable target or outcome is stated.",
    ),
    ObservationRule(
        "SIG-SCOPE",
        "signal_clarity",
        (
            "across our operations",
            "value chain",
            "throughout",
            "high-risk ai",
            "system lifetime",
            "核心运营",
            "价值链",
            "范围1",
            "范围2",
        ),
        0.15,
        "The applicable scope or boundary is stated.",
    ),
    ObservationRule(
        "SIG-CONDITION",
        "signal_clarity",
        (
            " if ",
            " when ",
            " where ",
            "subject to",
            "conditions",
            "条件",
            "情形",
        ),
        0.15,
        "A condition or trigger is stated.",
    ),
    ObservationRule(
        "SIG-DOCUMENT",
        "signal_clarity",
        (
            "document",
            "maintain records",
            "established",
            "documented",
            "编制",
            "记录",
        ),
        0.15,
        "A documented procedure or record requirement is stated.",
    ),
    ObservationRule(
        "SIG-SYSTEM",
        "signal_clarity",
        (
            "system",
            "framework",
            "policy",
            "机制",
            "体系",
            "制度",
        ),
        0.15,
        "The commitment identifies an implementing system or policy.",
    ),
    ObservationRule(
        "VC-PUBLIC",
        "verification_cost",
        (
            "public report",
            "publicly available",
            "published on",
            "publish",
            "publicly disclose",
            "disclose",
            "transparent",
            "公开披露",
            "公开发布",
        ),
        0.20,
        "Public or periodic disclosure lowers verification cost.",
    ),
    ObservationRule(
        "VC-DATA",
        "verification_cost",
        (
            "data",
            "record",
            "document",
            "evidence",
            "技术文档",
            "数据",
            "记录",
            "文件",
        ),
        0.20,
        "Records or data make verification easier.",
    ),
    ObservationRule(
        "VC-METHOD",
        "verification_cost",
        (
            "standard",
            "methodology",
            "measurement method",
            "assessment",
            "审计",
            "核算",
            "评估",
            "标准",
        ),
        0.20,
        "A measurement method or standard is identifiable.",
    ),
    ObservationRule(
        "VC-INDEPENDENT",
        "verification_cost",
        (
            "independent audit",
            "independent review",
            "independent verification",
            "third-party audit",
            "third-party review",
            "external review",
            "independent reviewer",
            "第三方",
            "独立",
        ),
        0.20,
        "Independent review can reduce verification effort.",
    ),
    ObservationRule(
        "VC-CONTINUOUS",
        "verification_cost",
        (
            "monitor",
            "continuous",
            "systematically",
            "持续",
            "监测",
        ),
        0.15,
        "Continuous monitoring provides readily available evidence.",
    ),
    ObservationRule(
        "VC-BARRIER",
        "verification_cost",
        (
            "redacted",
            "confidential records",
            "restricted information",
            "without access",
            "敏感数据",
            "保密限制",
        ),
        -0.20,
        "Access restrictions increase verification cost.",
    ),
    ObservationRule(
        "TD-CONTINUOUS",
        "time_delay",
        (
            "continuous monitoring",
            "real-time monitoring",
            "monitoring throughout",
            "systematically",
            "持续监测",
            "实时监测",
        ),
        0.20,
        "Continuous evidence shortens verification delay.",
    ),
    ObservationRule(
        "TD-ANNUAL",
        "time_delay",
        (
            "annual",
            "annually",
            "yearly",
            "每年",
            "年度",
        ),
        -0.10,
        "Annual-only evidence leaves a longer verification delay.",
    ),
    ObservationRule(
        "TD-TIMELY",
        "time_delay",
        (
            "immediately",
            "without undue delay",
            "real-time",
            "timely",
            "立即",
            "不迟于",
            "及时报告",
            "及时受理",
            "及时处理",
            "及时采取",
        ),
        0.20,
        "A short reporting or response delay is stated.",
    ),
    ObservationRule(
        "CAP-OPERATIONS",
        "capability_match",
        (
            "operations",
            "operates",
            "infrastructure",
            "facilities",
            "system",
            "运营",
            "基地",
            "系统",
        ),
        0.20,
        "The text identifies operational capability relevant to delivery.",
    ),
    ObservationRule(
        "CAP-PROGRESS",
        "capability_match",
        (
            "achieved",
            "reduced",
            "replenished",
            "progress",
            "完成",
            "降低",
            "实现",
            "推进",
        ),
        0.25,
        "Reported progress supports capability to perform.",
    ),
    ObservationRule(
        "CAP-PLAN",
        "capability_match",
        (
            "strategy",
            "program",
            "investment",
            "plan",
            "战略",
            "计划",
            "投入",
        ),
        0.15,
        "A strategy or implementation route is stated.",
    ),
    ObservationRule(
        "CAP-MODERATION",
        "capability_match",
        (
            "moderation",
            "enforcement team",
            "review team",
            "审核团队",
            "处置工具",
        ),
        0.20,
        "Operational moderation or review capability is stated.",
    ),
    ObservationRule(
        "INC-LEGAL",
        "incentive_alignment",
        (
            "legal obligation",
            "required by law",
            "required or authorised by law",
            "required by applicable law",
            "must ensure safeguards",
            "must comply with",
            "shall comply with",
            "法定",
            "法定义务",
            "法律要求",
        ),
        0.25,
        "A binding obligation aligns incentives.",
    ),
    ObservationRule(
        "INC-PENALTY",
        "incentive_alignment",
        (
            "penalt",
            "lose access",
            "enforce",
            "corrective",
            "disciplinary",
            "termination of employment",
            "suspend access",
            "suspension of system",
            "处罚",
            "失去访问",
            "纠正",
            "纪律处分",
            "终止雇佣",
            "暂停权限",
        ),
        0.25,
        "Consequences for non-performance align incentives.",
    ),
    ObservationRule(
        "INC-ACCOUNTABLE",
        "incentive_alignment",
        (
            "accountab",
            "responsible",
            "appeal",
            "负责",
            "问责",
            "申诉",
        ),
        0.15,
        "Accountability or appeal structures align incentives.",
    ),
    ObservationRule(
        "INC-PERFORMANCE",
        "incentive_alignment",
        (
            "performance indicator",
            "performance target",
            "performance assessment",
            "executive compensation",
            "performance-based compensation",
            "remuneration",
            "compensation linkage",
            "compensation scheme",
            "绩效考核",
            "绩效指标",
            "薪酬体系",
            "薪酬方案",
            "薪酬挂钩",
            "激励机制",
            "科学碳目标达成情况",
        ),
        0.20,
        "Performance or compensation linkage aligns implementation incentives.",
    ),
    ObservationRule(
        "INC-STATUTORY",
        "incentive_alignment",
        (
            "regulation (eu)",
            "market surveillance authority",
            "member states shall",
            "statutory obligation",
            "法定义务",
        ),
        0.20,
        "A statutory framework aligns incentives through public enforcement.",
    ),
    ObservationRule(
        "INC-ENFORCEMENT",
        "incentive_alignment",
        (
            "market surveillance authority",
            "statutory penalties",
            "enforcement action",
            "监管机构",
            "主管部门",
            "行政处罚",
            "警告",
            "责令限期改正",
            "责令暂停",
        ),
        0.15,
        "A public enforcement route aligns incentives with compliance.",
    ),
    ObservationRule(
        "INC-REPUTATION",
        "incentive_alignment",
        (
            "public report",
            "transparency",
            "disclose",
            "publicly",
            "公开报告",
            "透明度",
        ),
        0.15,
        "Public reporting creates a reputational incentive.",
    ),
    ObservationRule(
        "EXT-LAW",
        "external_constraints",
        (
            "regulation (eu)",
            "legislation",
            "applicable law",
            "required by law",
            "required or authorised by law",
            "authorised by law",
            "market surveillance",
            "法律要求",
            "法律法规要求",
            "市场监管",
        ),
        0.35,
        "Legal or regulatory constraints are present.",
    ),
    ObservationRule(
        "EXT-BINDING",
        "external_constraints",
        (
            "binding",
            "required by this agreement",
            "required by law",
            "governed by these terms",
            "terms of use",
            "customer will not",
            "policy violation",
            "法定义务",
            "必须遵守",
        ),
        0.20,
        "Binding language creates an external commitment constraint.",
    ),
    ObservationRule(
        "EXT-CERT",
        "external_constraints",
        (
            "iso 14001",
            "iso 14064",
            "iso 50001",
            "pas 2060",
            "certification",
            "audit",
            "assurance",
            "认证",
            "审计",
        ),
        0.15,
        "Certification or assurance creates an external check.",
    ),
    ObservationRule(
        "EXT-AUTHORITY",
        "external_constraints",
        (
            "market surveillance authority",
            "market surveillance authorities",
            "competent authority",
            "competent authorities",
            "supervisory authority",
            "supervisory authorities",
            "regulator",
            "court order",
            "attorney general",
            "监管机构",
            "主管部门",
            "ofcom",
            "行政处罚",
            "责令",
            "暂停提供相关服务",
            "市场监督机构",
            "法院",
        ),
        0.20,
        "A named external authority can review or enforce the obligation.",
    ),
    ObservationRule(
        "EXT-STATUTORY",
        "external_constraints",
        (
            "regulation (eu)",
            "legislation",
            "this act",
            "duties of care",
            "regulatory framework",
            "member states shall",
            "penalties",
            "penalty notice",
            "civil penalty",
            "offence",
            "statutory obligation",
            "attorney general",
            "行政处罚",
            "主管部门责令",
            "暂停提供相关服务",
            "法定要求",
            "法定处罚",
        ),
        0.25,
        "Statutory language and penalties create an external legal constraint.",
    ),
    ObservationRule(
        "EXT-STATUTORY-FRAMEWORK",
        "external_constraints",
        (
            "this act",
            "duties of care",
            "regulatory framework",
            "legislation",
            "法定框架",
        ),
        0.20,
        "A statutory framework creates a distinct external structural constraint.",
    ),
    ObservationRule(
        "EXT-PENALTY",
        "external_constraints",
        (
            "penalty notice",
            "civil penalty",
            "statutory penalties",
            "行政处罚",
            "责令限期改正",
            "责令暂停",
            "暂停提供相关服务",
        ),
        0.20,
        "A stated penalty or corrective order strengthens enforcement.",
    ),
    ObservationRule(
        "EXT-ENFORCEMENT",
        "external_constraints",
        (
            "market surveillance authority",
            "market surveillance authorities",
            "corrective action",
            "withdraw the system",
            "recall the system",
            "行政强制执行",
            "召回系统",
            "撤回系统",
        ),
        0.15,
        "A named enforcement route strengthens the external constraint.",
    ),
    ObservationRule(
        "EXT-REPORTING-FRAMEWORK",
        "external_constraints",
        (
            "ghg protocol",
            "gri standards",
            "ifrs s2",
            "cdp",
            "aa1000as",
            "iso 14064",
            "iso 50001",
            "pas 2060",
            "sustainability reporting standard",
            "可持续发展报告标准",
        ),
        0.15,
        "An external reporting framework creates a limited verification constraint.",
    ),
    ObservationRule(
        "EXT-SUPPLY-CHAIN",
        "external_constraints",
        (
            "supplier code",
            "supplier audit",
            "third-party audit",
            "supplier requirement",
            "供应商行为准则",
            "供应链审核",
            "供应商审核",
            "可持续影响评估",
        ),
        0.15,
        "Contractual supplier controls create a limited external constraint.",
    ),
    ObservationRule(
        "MON-MONITOR",
        "monitoring_intensity",
        (
            "monitor",
            "track",
            "measure",
            "监督",
            "监测",
            "跟踪",
        ),
        0.20,
        "Monitoring is explicitly stated.",
    ),
    ObservationRule(
        "MON-REPORT",
        "monitoring_intensity",
        (
            "report",
            "disclose",
            "publish",
            "报告",
            "披露",
            "公开",
        ),
        0.20,
        "Reporting or disclosure is stated.",
    ),
    ObservationRule(
        "MON-RECORD",
        "monitoring_intensity",
        (
            "record",
            "document",
            "data",
            "technical documentation",
            "记录",
            "文件",
            "数据",
        ),
        0.15,
        "Monitoring leaves retained records or data.",
    ),
    ObservationRule(
        "MON-INDEPENDENT",
        "monitoring_intensity",
        (
            "independent",
            "third-party",
            "external review",
            "审计",
            "第三方",
            "独立",
        ),
        0.15,
        "Independent review increases monitoring intensity.",
    ),
    ObservationRule(
        "MON-ANALYZE",
        "monitoring_intensity",
        (
            "analyse",
            "analyze",
            "evaluate",
            "assessment",
            "分析",
            "评估",
        ),
        0.15,
        "Monitoring includes analysis or evaluation.",
    ),
    ObservationRule(
        "MON-REVIEW",
        "monitoring_intensity",
        (
            "review process",
            "review processes",
            "external review",
            "audit",
            "审查",
            "复核",
        ),
        0.15,
        "A review or audit process is explicitly stated.",
    ),
    ObservationRule(
        "MON-OVERSIGHT",
        "monitoring_intensity",
        (
            "board committee",
            "board of directors provides oversight",
            "oversight and guidance",
            "董事会委员会",
            "董事会监督",
        ),
        0.15,
        "Named governance oversight increases monitoring intensity.",
    ),
    ObservationRule(
        "MON-CORRECT",
        "monitoring_intensity",
        (
            "corrective",
            "incident",
            "escalat",
            "纠正",
            "事件",
            "升级",
        ),
        0.15,
        "Monitoring is linked to correction or escalation.",
    ),
    ObservationRule(
        "PHY-RESTORE",
        "physical_reversibility",
        (
            "restore the affected",
            "restore the system",
            "physical restoration",
            "reverse the deployed",
            "return the system to",
            "修复受损",
            "恢复原状",
        ),
        0.20,
        "A restoration or reversal route is stated.",
    ),
    ObservationRule(
        "PHY-OFFSET",
        "physical_reversibility",
        (
            "remove carbon",
            "carbon removal",
            "carbon offset",
            "compensate for emissions",
            "environmental compensation",
            "移除碳",
            "抵消排放",
        ),
        0.10,
        "Removal or offset provides limited reversibility.",
    ),
    ObservationRule(
        "PHY-CONTROL",
        "physical_reversibility",
        (
            "rollback",
            "kill switch",
            "shut down the system",
            "disable the system",
            "deactivate the system",
            "recall the system",
            "withdraw the system",
            "disable it",
            "recall it",
            "withdraw it",
            "take down content",
            "taken down content",
            "restrict access",
            "restrict users' access",
            "restrict users’ access",
            "swiftly reinstated",
            "reverse the action",
            "回滚",
            "关闭系统",
            "停用系统",
            "召回系统",
        ),
        0.20,
        "A physical or technical reversal control is stated.",
    ),
    ObservationRule(
        "INST-REVIEW",
        "institutional_reversibility",
        (
            "review",
            "revise",
            "amend",
            "update",
            "审议",
            "审查",
            "修订",
            "更新",
        ),
        0.20,
        "A review or amendment route is stated.",
    ),
    ObservationRule(
        "INST-EXIT",
        "institutional_reversibility",
        (
            "appeal",
            "withdraw the ai system",
            "withdraw the model",
            "exit route",
            "rollback",
            "reverse the decision",
            "申诉",
            "回滚",
            "退出机制",
            "撤回目标",
        ),
        0.20,
        "An appeal, exit or reversal route is stated.",
    ),
    ObservationRule(
        "INST-VERSION",
        "institutional_reversibility",
        (
            "version",
            "changelog",
            "prior version",
            "previous version",
            "版本",
            "变更记录",
        ),
        0.20,
        "Versioning preserves an institutional reversal route.",
    ),
    ObservationRule(
        "INST-STOP",
        "institutional_reversibility",
        (
            "stop condition",
            "suspend",
            "corrective action",
            "corrective-action loop",
            "closed-loop corrective",
            "中止",
            "暂停",
            "纠正措施",
            "整改闭环",
        ),
        0.15,
        "A stop or correction mechanism is stated.",
    ),
    ObservationRule(
        "INST-COMPLAINT",
        "institutional_reversibility",
        (
            "complaints procedure",
            "complaint procedure",
            "appeal to the upper tribunal",
            "user reporting",
            "投诉、举报机制",
            "投诉处理",
            "申诉",
        ),
        0.15,
        "A complaint or appeal route creates an institutional correction path.",
    ),
    ObservationRule(
        "INST-NO-UPDATE",
        "institutional_reversibility",
        (
            "no obligation to update or revise",
            "undertakes no obligation to update",
            "not obligated to update",
            "不承担更新或修订义务",
            "没有更新或修订义务",
        ),
        -0.20,
        "The source expressly disclaims an update or revision obligation.",
    ),
    ObservationRule(
        "INST-ENFORCEMENT",
        "institutional_reversibility",
        (
            "market surveillance authority",
            "competent authority",
            "corrective action",
            "withdraw the system",
            "recall the system",
            "监管机构要求纠正",
            "召回系统",
            "撤回系统",
        ),
        0.20,
        "An external authority can require institutional correction or reversal.",
    ),
    ObservationRule(
        "INST-EXTERNAL",
        "institutional_reversibility",
        (
            "external review",
            "independent review",
            "third-party review",
            "外部审查",
            "独立审查",
        ),
        0.20,
        "External review creates an institutional correction route.",
    ),
    ObservationRule(
        "INST-CONTEST",
        "institutional_reversibility",
        (
            "contest such decisions",
            "contest the decision",
            "representations about such decisions",
            "obtain human intervention",
            "申诉",
            "质疑决定",
        ),
        0.20,
        "A contestation or representation route creates institutional correction.",
    ),
    ObservationRule(
        "INST-HUMAN-INTERVENTION",
        "institutional_reversibility",
        (
            "meaningful human involvement",
            "human intervention",
            "human review",
            "make representations",
            "contest the decision",
            "人工干预",
            "人工复核",
        ),
        0.20,
        "Human intervention and contestability create a correction route.",
    ),
    ObservationRule(
        "COG-EXPLAIN",
        "cognitive_reversibility",
        (
            "explain",
            "plain-language",
            "transparent",
            "public explanation",
            "说明",
            "解释决定",
            "透明",
        ),
        0.20,
        "An explanation route supports belief correction.",
    ),
    ObservationRule(
        "COG-PUBLIC",
        "cognitive_reversibility",
        (
            "public report",
            "publicly publish",
            "public disclosure",
            "publish",
            "disclose",
            "公开披露",
            "公开发布",
        ),
        0.15,
        "Public disclosure supports correction of shared beliefs.",
    ),
    ObservationRule(
        "COG-APPEAL",
        "cognitive_reversibility",
        (
            "appeal",
            "human review",
            "consultation process",
            "public consultation",
            "contest the decision",
            "complaint",
            "投诉",
            "举报",
            "申诉",
            "人工复核",
            "公众咨询",
        ),
        0.20,
        "Appeal or consultation allows correction of understanding.",
    ),
    ObservationRule(
        "COG-NOTIFY",
        "cognitive_reversibility",
        (
            "inform the distributors",
            "inform the deployers",
            "inform the market surveillance",
            "notify the market surveillance",
            "notify affected",
            "告知部署者",
            "通知受影响",
        ),
        0.15,
        "A duty to inform named parties supports correction of understanding.",
    ),
    ObservationRule(
        "COG-HUMAN-INTERVENTION",
        "cognitive_reversibility",
        (
            "meaningful human involvement",
            "human intervention",
            "human review",
            "representations",
            "contest the decision",
            "人工干预",
            "人工复核",
            "投诉",
        ),
        0.20,
        "Human intervention and contestability support belief correction.",
    ),
    ObservationRule(
        "COG-CONTEST",
        "cognitive_reversibility",
        (
            "contest such decisions",
            "contest the decision",
            "representations about such decisions",
            "make representations",
            "质疑决定",
        ),
        0.20,
        "A right to contest decisions supports correction of understanding.",
    ),
    ObservationRule(
        "COG-LEARN",
        "cognitive_reversibility",
        (
            "learn from",
            "reflect on",
            "improve based on",
            "shared learning",
            "经验教训",
            "反思",
            "持续改进",
        ),
        0.15,
        "Learning language supports belief revision.",
    ),
    ObservationRule(
        "COG-NO-UPDATE",
        "cognitive_reversibility",
        (
            "no obligation to update or revise",
            "undertakes no obligation to update",
            "not obligated to update",
            "不承担更新或修订义务",
            "没有更新或修订义务",
        ),
        -0.10,
        "An express no-update statement weakens belief-revision support.",
    ),
    ObservationRule(
        "COG-ARCHIVE",
        "cognitive_reversibility",
        (
            "archive",
            "retain records",
            "decision history",
            "version history",
            "决策记录",
            "版本历史",
            "保留记录",
        ),
        0.10,
        "Archives preserve the basis for later correction.",
    ),
    ObservationRule(
        "COG-VERSION",
        "cognitive_reversibility",
        (
            "changelog",
            "version",
            "prior version",
            "previous version",
            "变更记录",
            "版本",
        ),
        0.15,
        "Version history makes belief correction traceable.",
    ),
    ObservationRule(
        "COG-REVIEW",
        "cognitive_reversibility",
        (
            "external review",
            "independent review",
            "human review",
            "外部审查",
            "独立审查",
        ),
        0.15,
        "External review provides a route to revise understanding.",
    ),
)


def _quantize(value: float) -> float:
    return round(round(value * 20) / 20, 2)


def _year_signals(text: str) -> tuple[int, ...]:
    return tuple(
        sorted(
            {
                int(match)
                for match in re.findall(r"\b(20\d{2})\b", text)
                if 2025 <= int(match) <= 2100
            }
        )
    )


def _domain_physical_base(domain: str, text: str) -> float:
    if domain == "ESG":
        if any(
            token in text
            for token in (
                "carbon",
                "emission",
                "water",
                "waste",
                "climate",
                "碳",
                "排放",
                "水",
                "废弃物",
                "气候",
            )
        ):
            return 0.15
        return 0.25
    if any(
        token in text
        for token in (
            "physical",
            "infrastructure",
            "deployed",
            "harm",
            "critical infrastructure",
        )
    ):
        return 0.30
    return 0.40


def observe_crv(case_id: str, text: str, *, domain: str) -> CRVObservation:
    """Score CRV from text-only rules without reading expected labels."""

    if domain not in {"AI", "ESG"}:
        raise ValueError("domain must be AI or ESG")
    normalized = re.sub(r"\s+", " ", text.casefold()).strip()
    minimum_length = 40 if re.search(r"[\u4e00-\u9fff]", normalized) else 120
    if len(normalized) < minimum_length:
        return CRVObservation(
            case_id=case_id,
            domain=domain,
            status="not_assessable",
            dimensions={},
            evidence=(),
            text_sha256=hashlib.sha256(text.encode("utf-8")).hexdigest(),
            warnings=("source text is too short for a complete CRV observation",),
        )

    baseline = {
        "signal_clarity": 0.0,
        "verification_cost": 0.10,
        "time_delay": 0.35,
        "capability_match": 0.10,
        "incentive_alignment": 0.05,
        "external_constraints": 0.05,
        "monitoring_intensity": 0.05,
        "physical_reversibility": _domain_physical_base(domain, normalized),
        "institutional_reversibility": 0.05,
        "cognitive_reversibility": 0.05,
    }
    scores = dict(baseline)
    matched_by_dimension: dict[str, list[tuple[str, str, str]]] = {
        dimension: [] for dimension in CRV_ALL_SUBDIMENSIONS
    }
    for rule in _RULES:
        matched = next(
            (pattern.strip() for pattern in rule.patterns if pattern in normalized),
            None,
        )
        if matched is None:
            continue
        scores[rule.dimension] += rule.weight
        matched_by_dimension[rule.dimension].append(
            (rule.rule_id, matched, rule.rationale)
        )

    years = _year_signals(normalized)
    if years:
        scores["signal_clarity"] += 0.10
        if min(years) > 2030:
            scores["time_delay"] -= 0.10
    dimensions = {
        dimension: _quantize(min(1.0, max(0.0, scores[dimension])))
        for dimension in CRV_ALL_SUBDIMENSIONS
    }
    evidence = tuple(
        DimensionObservation(
            dimension=dimension,
            score=dimensions[dimension],
            matched_rule_ids=tuple(item[0] for item in matches),
            matched_terms=tuple(item[1] for item in matches),
            rationale=(
                "; ".join(item[2] for item in matches)
                if matches
                else "No positive or negative text rule matched."
            ),
        )
        for dimension, matches in matched_by_dimension.items()
    )
    return CRVObservation(
        case_id=case_id,
        domain=domain,
        status="calculated",
        dimensions=dimensions,
        evidence=evidence,
        text_sha256=hashlib.sha256(text.encode("utf-8")).hexdigest(),
        warnings=(
            "Text-only structural observation; it does not prove delivery or operation.",
        ),
    )
